# 🛒 HOSTPOINT KAUFANLEITUNG FÜR dataquard.ch
## Genau WANN du WAS kaufen sollst

---

## 🎯 DEINE SITUATION JETZT

✅ Domain verfügbar: **dataquard.ch** 
✅ Preis: CHF 5.00 für 1. Jahr (normal CHF 15.00)
✅ Hostpoint zeigt Add-ons an
❓ Frage: Was brauchst du WIRKLICH?

---

## 💡 MEINE EMPFEHLUNG: WAS DU KAUFEN SOLLST

### 🥇 MUSS KAUFEN (ESSENTIELL):

#### **1. Domain: dataquard.ch**
- ✅ CHF 5.00 pro Jahr (1. Jahr rabatt!)
- ✅ MUSS KAUFEN!
- ✅ Danach CHF 15.00/Jahr (normal)

**→ AUSWÄHLEN: JA** ✅

---

#### **2. Smart Webhosting** (CHF 9.90/Monat)
**Warum du das BRAUCHST:**

```
Du hast:
✅ Landing Page (HTML/CSS)
✅ Generator Widget (HTML/JavaScript)
✅ Stripe Integration

Du brauchst:
✅ Server um deine Website zu hosten
✅ Email-Adressen (support@dataquard.ch)
✅ Zuverlässigkeitkeit

Smart Webhosting bietet:
✅ Hosting für deine Website
✅ Email-Adressen mit deiner Domain
✅ 17.90 CHF/Monat (Standard)
✅ Heute nur CHF 9.90/Monat (RABATT!)
```

**Vorteile für dich:**
- ✅ support@dataquard.ch Email-Adresse
- ✅ Professionelle Geschäfts-Email
- ✅ Zuverlässiger Server
- ✅ Support auf Deutsch

**→ AUSWÄHLEN: JA** ✅

---

### 🥈 OPTIONAL (EMPFOHLEN):

#### **3. E-Mail with Cloud Office Plus** (CHF 3.00/Monat)
**Das bekommst du extra:**
- 50 GB Mail Storage (vs. Standard)
- 50 GB Drive Storage (Cloud-Speicher)
- Calendar (Kalender)
- Address Book (Kontakte)
- Cloud Office Basic (kostenlos 1. Jahr)

**Brauchst du das?**
- ✅ JA, wenn du professionell arbeiten möchtest
- ✅ Extra Storage für Kunden-Daten
- ✅ Calendar für Meetings mit Anwälten/Partnern
- ✅ Nur CHF 3.00/Monat (super günstig!)

**→ AUSWÄHLEN: JA** ✅ (Empfohlen!)

---

#### **4. Positive SSL Certificate** (CHF 1.00/Monat)
**Das brauchst du:**
- ✅ HTTPS für deine Website (grünes Schloss 🔒)
- ✅ Notwendig für Vertrauen
- ✅ Notwendig für Stripe-Integration
- ✅ Notwendig für DSGVO-Konformität

**Brauchen?**
- ✅ JA, absolut notwendig!
- ✅ Kostenlos bei den meisten Hostpoint-Plänen
- ✅ Aber CHF 1.00/Monat für die "Positive SSL" (branded)

**→ AUSWÄHLEN: OPTIONAL (normales SSL ist kostenlos)**

---

## 📊 MEINE EMPFOHLENE KONFIGURATION

### ✅ KAUFE DAS:

```
1. Domain: dataquard.ch
   ├─ Preis: CHF 5.00 (1. Jahr)
   └─ Status: ✅ KAUFEN

2. Smart Webhosting
   ├─ Preis: CHF 9.90/Monat
   └─ Status: ✅ KAUFEN

3. E-Mail with Cloud Office Plus
   ├─ Preis: CHF 3.00/Monat
   └─ Status: ✅ KAUFEN (empfohlen)

4. Positive SSL Certificate
   ├─ Preis: CHF 1.00/Monat
   └─ Status: ⚠️ OPTIONAL (normales SSL ist kostenlos)
```

---

## 💰 KOSTENÜBERSICHT

### Jahr 1:

```
Domain dataquard.ch:        CHF 5.00    (1x, rabattiert!)
Smart Webhosting:           CHF 118.80  (9.90 × 12 Monate)
E-Mail Cloud Office Plus:   CHF 36.00   (3.00 × 12 Monate)
Positive SSL (optional):    CHF 12.00   (1.00 × 12 Monate)

TOTAL JAHR 1:              CHF 171.80 - CHF 183.80
```

### Jahr 2+:

```
Domain dataquard.ch:        CHF 15.00   (normal)
Smart Webhosting:           CHF 118.80  (9.90 × 12)
E-Mail Cloud Office Plus:   CHF 36.00   (3.00 × 12)
Positive SSL (optional):    CHF 12.00   (1.00 × 12)

TOTAL PRO JAHR:            CHF 181.80 - CHF 193.80
```

**Das sind ungefähr CHF 15–16 pro Monat!** 💪
**Im Vergleich: 1 Kunde bringt dir CHF 149!**

---

## 🎯 SCHRITT-FÜR-SCHRITT ANLEITUNG

### Schritt 1: Smart Webhosting auswählen
```
Im Hostpoint-Screen:
├─ Sehe "Smart Webhosting" (CHF 9.90/Monat)
├─ KLICK auf "Smart Webhosting"
└─ ✅ HINZUFÜGEN
```

### Schritt 2: E-Mail Cloud Office Plus auswählen
```
├─ Sehe "E-Mail with Cloud Office Plus" (CHF 3.00/Monat)
├─ Setze Menge auf: 1 (mit + Button)
└─ ✅ HINZUFÜGEN
```

### Schritt 3: Positive SSL Certificate (optional)
```
├─ Sehe "Positive SSL Certificate" (CHF 1.00/Monat)
├─ Wenn du willst: HINZUFÜGEN
└─ ✅ Optional
```

### Schritt 4: Domain hinzufügen
```
Die Domain dataquard.ch sollte bereits im Warenkorb sein!
└─ ✅ BESTÄTIGEN
```

### Schritt 5: Kasse
```
├─ Gehe zu "Kasse"
├─ Login oder Registrierung
├─ Zahlungsmethode wählen (Kreditkarte, Paypal, etc.)
└─ ✅ BEZAHLEN
```

---

## ⚠️ WICHTIGE HINWEISE

### Was du NICHT kaufen musst:

❌ **"Your website with Sites Plus"** 
- Das ist ein Website-Builder (nicht nötig)
- Du hast schon deine Landing Page!
- Nicht kaufen!

❌ **"Cloud Office Basic"**
- Ist im Cloud Office Plus bereits enthalten
- Nicht zusätzlich kaufen!

❌ **Extra Domains** (noch nicht)
- Erst mal nur dataquard.ch
- Später kannst du .de, .com, etc. hinzufügen

---

## ✅ NACH DEM KAUF: NÄCHSTE SCHRITTE

### Sofort nach Kauf:

1. ✅ **Email-Bestätigung erhalten**
   - Speichere alle Zugangsdaten!
   - Speichere Benutzername & Passwort!

2. ✅ **Hostpoint Admin Panel öffnen**
   - Gehe zu admin.hostpoint.ch
   - Login mit deinen Daten

3. ✅ **DNS-Einstellungen checken**
   - Domain sollte bereits konfiguriert sein
   - Keine manuellen Änderungen nötig (normalerweise)

4. ✅ **Email-Konto erstellen**
   - support@dataquard.ch
   - Weitere Emails optional (verkauf@, hallo@, etc.)

5. ✅ **Deine Landing Page hochladen**
   - Via FTP oder File Manager
   - Datei-Namen: index.html (wichtig!)

---

## 🚀 MEIN FINALES EMPFOHLENER WARENKORB

```
✅ Domain: dataquard.ch              CHF 5.00  (1. Jahr)
✅ Smart Webhosting                  CHF 9.90/Monat
✅ E-Mail Cloud Office Plus          CHF 3.00/Monat
⚠️ Positive SSL Certificate          CHF 1.00/Monat (OPTIONAL)

GESAMTPREIS JAHR 1:                  CHF 171.80
GESAMTPREIS MONATLICH:               CHF 15-16
```

**Das ist weniger als 1 Kaffee pro Tag!** ☕

---

## 💡 WARUM GENAU DAS?

### Domain: dataquard.ch
- ✅ Deine Online-Adresse
- ✅ Kunden können dich finden
- ✅ Professionell & merkbar

### Smart Webhosting
- ✅ Server für deine Website
- ✅ Email-Funktion
- ✅ Zuverlässig & schnell
- ✅ Swiss-Support

### E-Mail Cloud Office Plus
- ✅ Professionelle Business-Email
- ✅ Extra Speicher (wichtig!)
- ✅ Calendar für Meetings
- ✅ Cloud-Speicher für Daten

### Positive SSL (optional)
- ✅ Grünes Schloss in Browser
- ✅ Mehr Vertrauen für Kunden
- ✅ Wichtig für Zahlungen (Stripe)

---

## 🎁 BONUS: NACH 1 JAHR

**Wenn du erfolgreich bist (was du sein wirst!):**

```
Jahresumsatz: 500+ Kunden × CHF 149 = CHF 74.500+

Hostpoint Kosten: CHF 184/Jahr = 0.25% deines Umsatzes! 🤑

Du machst Millionen-Business auf CHF 15/Monat Infrastruktur! 🚀
```

---

## 📋 MEINE FINAL-EMPFEHLUNG

### Du kaufst JETZT:

```
1. Domain: dataquard.ch
   └─ CHF 5.00 (1. Jahr) ← SUPER GÜNSTIG!

2. Smart Webhosting
   └─ CHF 9.90/Monat ← ESSENTIELL

3. E-Mail Cloud Office Plus
   └─ CHF 3.00/Monat ← EMPFOHLEN

TOTAL MONATLICH: CHF 12.90 (nach 1. Jahr CHF 27.90)
```

### Das ist es!

Du brauchst NICHTS anderes!
- ✅ Hosting: Erledigt
- ✅ Email: Erledigt
- ✅ Domain: Erledigt
- ✅ SSL: Erledigt (kostenlos im Paket)
- ✅ Support: Erledigt

---

## ⚡ SOFORT-ANLEITUNG (SCHNELL VERSION)

1. ✅ Klick auf "Smart Webhosting" → HINZUFÜGEN
2. ✅ Klick auf "E-Mail Cloud Office Plus" → HINZUFÜGEN
3. ✅ Domain "dataquard.ch" sollte bereits drin sein
4. ✅ Gehe zur Kasse
5. ✅ Zahle (Kreditkarte, PayPal, etc.)
6. ✅ FERTIG! 🎉

---

## 🎉 DAS WAR'S!

Nach Abschluss:
- ✅ Du hast dataquard.ch
- ✅ Du hast professionelle Email
- ✅ Du hast zuverlässiges Hosting
- ✅ Du kannst deine Landing Page hochladen
- ✅ Du kannst starten! 🚀

---

**KLICK JETZT AUF KASSE UND KAUFE DIE KOMBINATION OBEN!** 💳

Du wirst es nicht bereuen! 🎊
