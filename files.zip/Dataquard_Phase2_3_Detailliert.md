# 📖 Dataquard – Phase 2 & 3 Detailliert

**Version:** 2.0  
**Fokus:** Website-Scanner & Stripe Payment Integration  
**Umfang:** ~1.500 Zeilen Code + Dokumentation

---

## PHASE 2: Website-Scanner & Risikoampel (1–2 Wochen)

**Ziel:** Scanner erkennt Google Analytics, Meta Pixel, Hosting-Provider, Cookies und generiert automatisch eine farbige Risikoampel (Grün/Orange/Rot)

---

### Schritt 2.1: Scanner-Engine implementieren (3 Tage)

**Datei:** `/lib/scanner.ts`

```typescript
// ==========================================
// Website Scanner - Automatic Service Detection
// ==========================================

export interface ScanResult {
  url: string;
  hostname: string;
  detectedServices: DetectedService[];
  hostingProvider: string;
  hasSSL: boolean;
  cookieBanner: boolean;
  riskLevel: 'green' | 'orange' | 'red';
  riskFactors: string[];
  scanTimestamp: Date;
}

export interface DetectedService {
  id: string;
  name: string;
  category: 'analytics' | 'marketing' | 'social' | 'payment' | 'hosting' | 'cdn' | 'other';
  dataTransfer: 'CH' | 'EU' | 'USA';
  requiresConsent: boolean;
  pattern: string; // Was wurde erkannt?
  description: string;
  riskLevel: 'low' | 'medium' | 'high';
}

export async function scanWebsite(url: string): Promise<ScanResult> {
  try {
    console.log(`🔍 Scanning ${url}...`);
    
    // 1. URL validieren
    const urlObj = new URL(url);
    if (!url.startsWith('http')) {
      throw new Error('URL muss mit http:// oder https:// beginnen');
    }
    
    // 2. HTML abrufen (mit Timeout)
    console.log('📥 Fetching HTML...');
    const response = await fetch(url, { 
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; DataquardScanner/1.0)'
      }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const html = await response.text();
    console.log(`📄 HTML fetched (${(html.length / 1024).toFixed(2)} KB)`);
    
    // 3. Services erkennen
    console.log('🔎 Detecting services...');
    const services = detectServices(html);
    
    // 4. Hosting-Provider erkennen
    console.log('🏢 Detecting hosting provider...');
    const hosting = await detectHostingProvider(urlObj.hostname);
    
    // 5. SSL prüfen
    const hasSSL = url.startsWith('https');
    console.log(`🔒 SSL: ${hasSSL ? 'YES ✓' : 'NO ✗'}`);
    
    // 6. Cookie-Banner prüfen
    const hasCookieBanner = detectCookieBanner(html);
    console.log(`🍪 Cookie Banner: ${hasCookieBanner ? 'YES ✓' : 'NO ✗'}`);
    
    // 7. Risiko-Bewertung
    const { riskLevel, factors } = assessRisk(services, hosting, hasSSL, hasCookieBanner);
    
    const result: ScanResult = {
      url,
      hostname: urlObj.hostname,
      detectedServices: services,
      hostingProvider: hosting,
      hasSSL,
      cookieBanner: hasCookieBanner,
      riskLevel,
      riskFactors: factors,
      scanTimestamp: new Date()
    };
    
    console.log(`✅ Scan complete! Risk Level: ${riskLevel.toUpperCase()}`);
    return result;
    
  } catch (error) {
    console.error('❌ Scan error:', error);
    throw new Error(`Scan failed for ${url}: ${error.message}`);
  }
}

// ==========================================
// Service Detection Patterns
// ==========================================

const SERVICE_PATTERNS: Record<string, {
  name: string;
  category: DetectedService['category'];
  dataTransfer: 'CH' | 'EU' | 'USA';
  description: string;
  riskLevel: 'low' | 'medium' | 'high';
  patterns: RegExp[];
}> = {
  googleAnalytics: {
    name: 'Google Analytics',
    category: 'analytics',
    dataTransfer: 'USA',
    description: 'Besuchertracking und Verhalten-Analyse',
    riskLevel: 'high',
    patterns: [
      /ga\('send'/i,
      /gtag\(['"]config['"],\s*['"]G[A]-/i,
      /google-analytics\.com\/collect/i,
      /_gaq\.push/i,
      /\/\/www\.google-analytics\.com/i
    ]
  },
  metaPixel: {
    name: 'Meta Pixel',
    category: 'marketing',
    dataTransfer: 'USA',
    description: 'Facebook/Instagram Conversion Tracking',
    riskLevel: 'high',
    patterns: [
      /fbq\(['"]init['"]/i,
      /facebook\.com\/tr\?/i,
      /pixel\.facebook\.com/i
    ]
  },
  googleTagManager: {
    name: 'Google Tag Manager',
    category: 'marketing',
    dataTransfer: 'USA',
    description: 'Tagging und Event-Tracking',
    riskLevel: 'medium',
    patterns: [
      /googletagmanager\.com\/gtag/i,
      /www\.googletagmanager\.com\/gtm/i
    ]
  },
  youtube: {
    name: 'YouTube Embeds',
    category: 'social',
    dataTransfer: 'USA',
    description: 'Eingebettete YouTube-Videos',
    riskLevel: 'high',
    patterns: [
      /youtube\.com\/embed/i,
      /youtube-nocookie\.com\/embed/i,
      /<iframe[^>]*youtube/i
    ]
  },
  googleFonts: {
    name: 'Google Fonts',
    category: 'cdn',
    dataTransfer: 'USA',
    description: 'Font-Bibliothek von Google',
    riskLevel: 'low',
    patterns: [
      /fonts\.googleapis\.com/i,
      /fonts\.gstatic\.com/i,
      /@import.*fonts\.googleapis/i
    ]
  },
  mailchimp: {
    name: 'Mailchimp',
    category: 'marketing',
    dataTransfer: 'USA',
    description: 'Newsletter und E-Mail-Marketing',
    riskLevel: 'medium',
    patterns: [
      /mailchimp\.com/i,
      /chimpstatic\.com/i,
      /cdn-cgi\.com.*mailchimp/i
    ]
  },
  stripe: {
    name: 'Stripe',
    category: 'payment',
    dataTransfer: 'USA',
    description: 'Zahlungsabwicklung',
    riskLevel: 'medium',
    patterns: [
      /js\.stripe\.com/i,
      /stripe\.com\/v\d/i
    ]
  },
  hotjar: {
    name: 'Hotjar',
    category: 'analytics',
    dataTransfer: 'EU',
    description: 'Session Recording und Heat Maps',
    riskLevel: 'high',
    patterns: [
      /hj\.site/i,
      /hotjar\.com/i
    ]
  },
  cloudflare: {
    name: 'Cloudflare',
    category: 'cdn',
    dataTransfer: 'USA',
    description: 'CDN und DDoS Protection',
    riskLevel: 'medium',
    patterns: [
      /cdnjs\.cloudflare\.com/i,
      /cloudflare\.com/i
    ]
  },
  recaptcha: {
    name: 'Google reCAPTCHA',
    category: 'other',
    dataTransfer: 'USA',
    description: 'Bot-Schutz',
    riskLevel: 'medium',
    patterns: [
      /recaptcha__en\.js/i,
      /recaptcha.*google\.com/i,
      /www\.google\.com\/recaptcha/i
    ]
  }
};

function detectServices(html: string): DetectedService[] {
  const services: DetectedService[] = [];
  const found = new Set<string>();
  
  for (const [id, config] of Object.entries(SERVICE_PATTERNS)) {
    // Jeder Service nur einmal hinzufügen
    if (found.has(id)) continue;
    
    for (const pattern of config.patterns) {
      if (pattern.test(html)) {
        services.push({
          id,
          name: config.name,
          category: config.category,
          dataTransfer: config.dataTransfer,
          requiresConsent: config.category !== 'cdn',
          pattern: pattern.source,
          description: config.description,
          riskLevel: config.riskLevel
        });
        found.add(id);
        break;
      }
    }
  }
  
  return services.sort((a, b) => {
    // Nach Risiko sortieren
    const riskScore = { high: 3, medium: 2, low: 1 };
    return riskScore[b.riskLevel] - riskScore[a.riskLevel];
  });
}

// ==========================================
// Hosting Provider Detection
// ==========================================

async function detectHostingProvider(hostname: string): Promise<string> {
  const providers: Record<string, string[]> = {
    'Hostpoint': ['hostpoint.ch', 'hp-servers.com'],
    'Infomaniak': ['infomaniak.com', 'iweb.ch'],
    'Cyon': ['cyon.ch'],
    'Vercel': ['vercel.app', 'now.sh'],
    'Netlify': ['netlify.app'],
    'AWS': ['amazonaws.com', 'cloudfront.net'],
    'Google Cloud': ['appspot.com', 'cloud.google.com'],
    'Heroku': ['herokuapp.com'],
    'Shopify': ['shopify.com', 'myshopify.com'],
    'WordPress.com': ['wordpress.com']
  };
  
  for (const [provider, domains] of Object.entries(providers)) {
    if (domains.some(d => hostname.includes(d))) {
      return provider;
    }
  }
  
  return 'Unknown / Selbstgehostet';
}

// ==========================================
// Cookie Banner Detection
// ==========================================

function detectCookieBanner(html: string): boolean {
  const cookiePatterns = [
    /cookie.*consent/i,
    /cookie.*akzept/i,
    /cookie.*banner/i,
    /cookie.*policy/i,
    /[^a-z]cookie[^a-z].*zustimm/i,
    /datenschutz.*banner/i,
    /gdpr.*banner/i,
    /cookiebot/i,
    /iubenda/i,
    /consentmanager/i,
    /onetrust/i
  ];
  
  return cookiePatterns.some(pattern => pattern.test(html));
}

// ==========================================
// Risk Assessment
// ==========================================

function assessRisk(
  services: DetectedService[],
  hosting: string,
  hasSSL: boolean,
  hasCookieBanner: boolean
): { riskLevel: 'green' | 'orange' | 'red'; factors: string[] } {
  const factors: string[] = [];
  let score = 0;
  
  // ❌ KRITISCH: Keine SSL
  if (!hasSSL) {
    score += 10;
    factors.push('❌ KRITISCH: Keine SSL/TLS-Verschlüsselung! Daten werden unverschlüsselt übertragen.');
  } else {
    factors.push('✓ SSL/TLS aktiviert');
  }
  
  // ⚠️ US-Datenübertragungen (SCHREMS II Risiko)
  const usServices = services.filter(s => s.dataTransfer === 'USA');
  if (usServices.length > 0) {
    score += usServices.length * 2;
    factors.push(`⚠️ ${usServices.length} US-basierte Services erkannt (SCHREMS II beachten):`);
    usServices.forEach(s => {
      factors.push(`   • ${s.name}: ${s.description}`);
    });
  }
  
  // Cookie-Banner prüfen
  if (usServices.length > 0 && !hasCookieBanner) {
    score += 3;
    factors.push('❌ US-Services ohne Cookie-Banner: Consent fehlt!');
  } else if (hasCookieBanner) {
    factors.push('✓ Cookie-Banner vorhanden');
  }
  
  // Viele Tracking-Services
  const trackingServices = services.filter(s => 
    ['analytics', 'marketing'].includes(s.category)
  );
  if (trackingServices.length > 3) {
    score += 2;
    factors.push(`⚠️ ${trackingServices.length} Tracking-Services erkannt (viele Cookies & externe Anfragen)`);
  }
  
  // Analytics ohne Consent
  const hasAnalytics = services.some(s => s.name === 'Google Analytics');
  if (hasAnalytics && !hasCookieBanner) {
    score += 2;
    factors.push('❌ Google Analytics ohne Consent ist DSGVO-Verstoß!');
  } else if (hasAnalytics) {
    factors.push('✓ Analytics mit Cookie-Consent');
  }
  
  // Bewertung
  let riskLevel: 'green' | 'orange' | 'red' = 'green';
  if (score >= 4 && score < 8) riskLevel = 'orange';
  if (score >= 8) riskLevel = 'red';
  
  if (factors.length === 0) {
    factors.push('✓ Keine Datenschutz-Risiken erkannt');
  }
  
  return { riskLevel, factors };
}
```

**Checklist nach 2.1:**
- ☑ Scanner erkennt Google Analytics
- ☑ Scanner erkennt Meta Pixel
- ☑ Scanner erkennt 10+ Services
- ☑ SSL-Status wird geprüft
- ☑ Hosting-Provider wird erkannt
- ☑ Risiko-Score wird berechnet

**Zeit: 3 Tage**

---

### Schritt 2.2: Risiko-Engine & Modul-Ableitung (2 Tage)

**Datei:** `/lib/riskEngine.ts`

```typescript
// ==========================================
// Risk Engine - Automatische Modul-Aktivierung
// ==========================================

export interface RiskAssessment {
  overallRisk: 'green' | 'orange' | 'red';
  activeModules: string[]; // P1-P7, W1-W8, D1-D12, C1-C5, Z1-Z3, HR1-HR5, T1-T2
  moduleDescriptions: Record<string, string>;
  recommendations: string[];
  criticalIssues: string[];
}

// Module-Definitionen
const MODULE_CATALOG = {
  // PFLICHT-Module
  P1: { name: 'Verantwortliche Stelle', category: 'mandatory' },
  P2: { name: 'Allgemeine Hinweise', category: 'mandatory' },
  P3: { name: 'Rechtsgrundlagen', category: 'mandatory' },
  P4: { name: 'Betroffenenrechte', category: 'mandatory' },
  P5: { name: 'Speicherdauer', category: 'mandatory' },
  P6: { name: 'Datensicherheit', category: 'mandatory' },
  P7: { name: 'Änderungen dieser Erklärung', category: 'mandatory' },
  
  // Website-Module
  W1: { name: 'Server Logs & Hosting', category: 'website' },
  W2: { name: 'SSL/TLS Verschlüsselung', category: 'website' },
  W3: { name: 'Kontaktformular', category: 'website' },
  W4: { name: 'Newsletter & Mailing-List', category: 'website' },
  W5: { name: 'Cookie-Banner', category: 'website' },
  W6: { name: 'E-Commerce & Online-Shop', category: 'website' },
  W7: { name: 'Bestellprozess & Zahlungen', category: 'website' },
  W8: { name: 'Online-Buchungssystem', category: 'website' },
  
  // Drittanbieter-Module (Dienste)
  D1: { name: 'Google Analytics', category: 'services' },
  D2: { name: 'Meta Pixel / Facebook', category: 'services' },
  D3: { name: 'YouTube Embeds', category: 'services' },
  D4: { name: 'Google Maps', category: 'services' },
  D5: { name: 'Google Fonts', category: 'services' },
  D6: { name: 'Mailchimp / Newsletter', category: 'services' },
  D7: { name: 'Calendly / Terminbuchung', category: 'services' },
  D8: { name: 'Google Tag Manager', category: 'services' },
  D9: { name: 'Hotjar / Session Recording', category: 'services' },
  D10: { name: 'LinkedIn Pixel', category: 'services' },
  D11: { name: 'Intercom / Chatbot', category: 'services' },
  D12: { name: 'Sonstige externe Services', category: 'services' },
  
  // Cookie-Module
  C1: { name: 'Allgemeine Cookie-Info', category: 'cookies' },
  C2: { name: 'Technisch notwendige Cookies', category: 'cookies' },
  C3: { name: 'Analyse-Cookies', category: 'cookies' },
  C4: { name: 'Marketing-Cookies', category: 'cookies' },
  C5: { name: 'Cookie-Banner Text', category: 'cookies' },
  
  // Zahlungs-Module
  Z1: { name: 'Stripe', category: 'payment' },
  Z2: { name: 'PayPal', category: 'payment' },
  Z3: { name: 'TWINT', category: 'payment' },
  
  // HR/Recruitment Module (UNIQUE FEATURE!)
  HR1: { name: 'Bewerbungen über Website', category: 'hr' },
  HR2: { name: 'Bewerbungen per E-Mail', category: 'hr' },
  HR3: { name: 'Recruiting-Plattformen', category: 'hr' },
  HR4: { name: 'Talent-Pool & Candidatenmanagement', category: 'hr' },
  HR5: { name: 'Mitarbeiterdaten & Personaldatei', category: 'hr' },
  
  // Datenübertragungen
  T1: { name: 'EU/EEA Datenübertragung', category: 'transfers' },
  T2: { name: 'USA Datenübertragung (SCHREMS II)', category: 'transfers' }
};

export function generateModuleConfig(scanResult: any): RiskAssessment {
  const activeModules: string[] = [];
  const recommendations: string[] = [];
  const criticalIssues: string[] = [];
  const moduleDescriptions: Record<string, string> = {};
  
  // ========== PFLICH T-MODULE (immer aktiv) ==========
  activeModules.push('P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7');
  activeModules.push('W1', 'W2'); // Hosting & SSL
  
  moduleDescriptions['P1'] = 'Name und Kontakt des Verantwortlichen';
  moduleDescriptions['P2'] = 'Rechtsgrundlagen und Zwecke';
  moduleDescriptions['P3'] = 'Speicherdauer und Sicherheitsmassnahmen';
  moduleDescriptions['P4'] = 'Betroffenenrechte (Auskunft, Löschung, etc.)';
  moduleDescriptions['P5'] = 'Wie lange Daten gespeichert werden';
  moduleDescriptions['P6'] = 'Technische und organisatorische Schutzmassnahmen';
  moduleDescriptions['P7'] = 'Hinweis auf mögliche Änderungen';
  
  // ========== GOOGLE ANALYTICS ==========
  const hasGA = scanResult.detectedServices?.some((s: any) => 
    s.name === 'Google Analytics'
  );
  if (hasGA) {
    activeModules.push('D1', 'C3', 'T2', 'W5');
    recommendations.push('⚠️ Google Analytics erkannt - Cookie-Banner ist PFLICHT!');
    moduleDescriptions['D1'] = 'Google Analytics Tracking Dokumentation';
    moduleDescriptions['C3'] = 'Analyse-Cookies mit Consent-Anforderung';
    moduleDescriptions['T2'] = 'USA Datenübertragung dokumentieren';
    
    if (!scanResult.cookieBanner) {
      criticalIssues.push('❌ Google Analytics ohne Cookie-Banner = DSGVO-Verstoß!');
    }
  }
  
  // ========== META PIXEL ==========
  const hasMetaPixel = scanResult.detectedServices?.some((s: any) => 
    s.name === 'Meta Pixel'
  );
  if (hasMetaPixel) {
    activeModules.push('D2', 'C4', 'T2', 'W5');
    recommendations.push('⚠️ Meta Pixel erkannt - Consent-Management erforderlich!');
    moduleDescriptions['D2'] = 'Meta Pixel / Facebook Conversion Tracking';
    moduleDescriptions['C4'] = 'Marketing-Cookies mit Opt-In erforderlich';
  }
  
  // ========== YOUTUBE ==========
  const hasYouTube = scanResult.detectedServices?.some((s: any) => 
    s.name === 'YouTube Embeds'
  );
  if (hasYouTube) {
    activeModules.push('D3', 'T2');
    recommendations.push('💡 YouTube-Embeds setzen Cookies - erwägen Sie youtube-nocookie.com');
    moduleDescriptions['D3'] = 'YouTube Video-Embeds und Datenübertragung';
  }
  
  // ========== GOOGLE FONTS ==========
  const hasGoogleFonts = scanResult.detectedServices?.some((s: any) => 
    s.name === 'Google Fonts'
  );
  if (hasGoogleFonts) {
    activeModules.push('D5');
    recommendations.push('💡 Google Fonts lädt Fonts von Google - erwägen Sie lokales Hosting');
    moduleDescriptions['D5'] = 'Google Fonts Verwendung dokumentieren';
  }
  
  // ========== STRIPE ==========
  const hasStripe = scanResult.detectedServices?.some((s: any) => 
    s.name === 'Stripe'
  );
  if (hasStripe) {
    activeModules.push('Z1', 'T2', 'W6', 'W7');
    moduleDescriptions['Z1'] = 'Stripe Zahlungsabwicklung';
    moduleDescriptions['W6'] = 'Online-Shop und E-Commerce Dokumentation';
    moduleDescriptions['W7'] = 'Bestellprozess und Zahlungsdaten';
  }
  
  // ========== MAILCHIMP ==========
  const hasMailchimp = scanResult.detectedServices?.some((s: any) => 
    s.name === 'Mailchimp'
  );
  if (hasMailchimp) {
    activeModules.push('D6', 'W4', 'T2');
    moduleDescriptions['D6'] = 'Mailchimp Newsletter und E-Mail Marketing';
    moduleDescriptions['W4'] = 'Newsletter Subscription Dokumentation';
  }
  
  // ========== COOKIE BANNER LOGIK ==========
  const needsCookieBanner = activeModules.some(m => 
    ['D1', 'D2', 'D3', 'D4', 'C3', 'C4'].includes(m)
  );
  if (needsCookieBanner) {
    activeModules.push('W5', 'C1', 'C2', 'C5');
    moduleDescriptions['W5'] = 'Cookie-Banner auf der Website erforderlich';
    moduleDescriptions['C1'] = 'Allgemeine Cookie-Informationen';
    moduleDescriptions['C2'] = 'Technisch notwendige Cookies (immer aktiv)';
    moduleDescriptions['C5'] = 'Cookie-Banner Text und Kategorien';
  }
  
  // ========== USA DATENÜBERTRA GUNG ==========
  const usServices = scanResult.detectedServices?.filter((s: any) => 
    s.dataTransfer === 'USA'
  ) || [];
  if (usServices.length > 0) {
    activeModules.push('T2');
    moduleDescriptions['T2'] = `${usServices.length} US-basierte Services erkannt - SCHREMS II dokumentieren`;
    recommendations.push('⚠️ SCHREMS II: Dokumentieren Sie Datenschutzrisiken bei USA-Übertragungen');
  }
  
  // ========== KRITISCHE FEHLER ==========
  if (!scanResult.hasSSL) {
    criticalIssues.push('❌ KRITISCH: Keine SSL/TLS-Verschlüsselung! Muss sofort aktiviert werden!');
  }
  
  if (criticalIssues.length > 0) {
    recommendations.unshift(...criticalIssues);
  }
  
  // Duplikate entfernen
  const uniqueModules = [...new Set(activeModules)];
  
  return {
    overallRisk: scanResult.riskLevel,
    activeModules: uniqueModules,
    moduleDescriptions,
    recommendations,
    criticalIssues
  };
}
```

**Checklist nach 2.2:**
- ☑ P1-P7 Module werden erkannt
- ☑ D1-D12 Services werden aktiviert
- ☑ Cookie-Module werden aktiviert
- ☑ USA-Transfer wird erkannt
- ☑ Kritische Fehler werden gewarnt

**Zeit: 2 Tage**

---

### Schritt 2.3: Scanner API-Route (1 Tag)

**Datei:** `/app/api/scan/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { scanWebsite } from '@/lib/scanner';
import { generateModuleConfig } from '@/lib/riskEngine';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

export async function POST(req: NextRequest) {
  try {
    const { url, email } = await req.json();
    
    // Validierung
    if (!url) {
      return NextResponse.json(
        { error: 'URL erforderlich' },
        { status: 400 }
      );
    }
    
    console.log(`[API] Scan Request: ${url} (${email})`);
    
    // 1. Website scannen (kann 10-30 Sekunden dauern)
    const scanResult = await scanWebsite(url);
    console.log(`[API] Scan completed. Risk: ${scanResult.riskLevel}`);
    
    // 2. Module generieren
    const moduleConfig = generateModuleConfig(scanResult);
    console.log(`[API] Modules generated: ${moduleConfig.activeModules.join(',')}`);
    
    // 3. Scan in Datenbank speichern
    const { data, error: insertError } = await supabase
      .from('scans')
      .insert({
        url: scanResult.url,
        hostname: scanResult.hostname,
        detected_services: scanResult.detectedServices,
        hosting_provider: scanResult.hostingProvider,
        has_ssl: scanResult.hasSSL,
        cookie_banner: scanResult.cookieBanner,
        risk_level: scanResult.riskLevel,
        risk_factors: scanResult.riskFactors,
        active_modules: moduleConfig.activeModules,
        recommendations: moduleConfig.recommendations,
        critical_issues: moduleConfig.criticalIssues,
        customer_email: email,
        created_at: new Date().toISOString()
      })
      .select();
    
    if (insertError) {
      console.error('[API] Database error:', insertError);
      throw insertError;
    }
    
    const scanId = data?.[0]?.id;
    console.log(`[API] Saved to DB. Scan ID: ${scanId}`);
    
    return NextResponse.json({
      success: true,
      scanId,
      scanResult,
      moduleConfig
    }, { status: 200 });
    
  } catch (error: any) {
    console.error('[API] Error:', error);
    return NextResponse.json(
      { 
        success: false,
        error: error.message || 'Scan fehlgeschlagen'
      },
      { status: 500 }
    );
  }
}
```

**Testen:**
```bash
curl -X POST http://localhost:3000/api/scan \
  -H "Content-Type: application/json" \
  -d '{"url":"https://example.com","email":"test@example.com"}'
```

**Erwartete Response:**
```json
{
  "success": true,
  "scanId": "abc123",
  "scanResult": {
    "url": "https://example.com",
    "riskLevel": "orange",
    "detectedServices": [...]
  },
  "moduleConfig": {
    "activeModules": ["P1", "P2", "D1", "C3", "T2"],
    "recommendations": [...]
  }
}
```

**Zeit: 1 Tag**

---

### Schritt 2.4: Risikoampel Frontend (2 Tage)

**Datei:** `/components/RiskIndicator.tsx`

```tsx
import React from 'react';

interface RiskIndicatorProps {
  riskLevel: 'green' | 'orange' | 'red';
  riskFactors: string[];
  detectedServices: any[];
  activeModules: string[];
  recommendations: string[];
  criticalIssues: string[];
}

export function RiskIndicator({ 
  riskLevel, 
  riskFactors, 
  detectedServices,
  activeModules,
  recommendations,
  criticalIssues
}: RiskIndicatorProps) {
  
  const colors = {
    green: {
      bg: 'bg-green-100',
      border: 'border-green-300',
      text: 'text-green-900',
      badge: 'bg-green-500',
      icon: '✓'
    },
    orange: {
      bg: 'bg-yellow-100',
      border: 'border-yellow-300',
      text: 'text-yellow-900',
      badge: 'bg-yellow-500',
      icon: '⚠️'
    },
    red: {
      bg: 'bg-red-100',
      border: 'border-red-300',
      text: 'text-red-900',
      badge: 'bg-red-500',
      icon: '❌'
    }
  };
  
  const style = colors[riskLevel];
  
  const labels = {
    green: 'Datenschutz OK',
    orange: 'Anpassungen empfohlen',
    red: 'Kritische Fehler'
  };
  
  return (
    <div className={`${style.bg} ${style.border} border rounded-lg shadow-lg p-6 my-6`}>
      {/* Header mit Ampel */}
      <div className="flex items-center gap-4 mb-4">
        <div className={`${style.badge} text-white text-3xl w-16 h-16 rounded-full flex items-center justify-center font-bold`}>
          {style.icon}
        </div>
        <div>
          <h2 className={`${style.text} text-2xl font-bold`}>
            {labels[riskLevel]}
          </h2>
          <p className={`${style.text} opacity-75`}>
            Datenschutz-Bewertung dieser Website
          </p>
        </div>
      </div>
      
      {/* Services */}
      {detectedServices.length > 0 && (
        <div className="mb-6 pb-6 border-b border-gray-300">
          <h3 className="font-semibold text-gray-800 mb-3">
            🔍 Erkannte Dienste ({detectedServices.length}):
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {detectedServices.map((service, i) => (
              <div key={i} className="bg-white bg-opacity-50 rounded p-2 text-sm">
                <span className="font-semibold">{service.name}</span>
                <span className="text-gray-600 ml-2">({service.dataTransfer})</span>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Kritische Probleme */}
      {criticalIssues.length > 0 && (
        <div className="mb-6 pb-6 border-b border-red-300 bg-red-50 p-4 rounded">
          <h3 className="font-semibold text-red-900 mb-2">⛔ Kritische Fehler:</h3>
          <ul className="space-y-1">
            {criticalIssues.map((issue, i) => (
              <li key={i} className="text-red-900 text-sm">
                • {issue}
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {/* Risikofaktoren */}
      {riskFactors.length > 0 && (
        <div className="mb-6 pb-6 border-b border-gray-300">
          <h3 className="font-semibold text-gray-800 mb-3">📊 Risikofaktoren:</h3>
          <ul className="space-y-2">
            {riskFactors.map((factor, i) => (
              <li key={i} className="text-gray-800 text-sm">
                • {factor}
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {/* Empfehlungen */}
      {recommendations.length > 0 && (
        <div className="mb-6 pb-6 border-b border-gray-300">
          <h3 className="font-semibold text-gray-800 mb-3">💡 Empfehlungen:</h3>
          <ol className="space-y-2 list-decimal list-inside">
            {recommendations.map((rec, i) => (
              <li key={i} className="text-gray-800 text-sm">
                {rec}
              </li>
            ))}
          </ol>
        </div>
      )}
      
      {/* Module die aktiviert werden */}
      {activeModules.length > 0 && (
        <div>
          <h3 className="font-semibold text-gray-800 mb-3">📋 Aktive Policy-Module:</h3>
          <div className="flex flex-wrap gap-2">
            {activeModules.map((module, i) => (
              <span 
                key={i} 
                className="bg-blue-500 text-white px-3 py-1 rounded-full text-xs font-semibold"
              >
                {module}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
```

**Integration in eine Page:**

```tsx
'use client';

import { useState } from 'react';
import { RiskIndicator } from '@/components/RiskIndicator';

export default function ScanPage() {
  const [url, setUrl] = useState('');
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const res = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url, email })
      });
      
      const data = await res.json();
      setResult(data);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Website Datenschutz-Check</h1>
      
      <form onSubmit={handleScan} className="bg-white rounded-lg shadow p-6 mb-6">
        <div className="mb-4">
          <label className="block font-semibold mb-2">Website-URL:</label>
          <input 
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://example.com"
            required
            className="w-full border rounded p-2"
          />
        </div>
        
        <div className="mb-4">
          <label className="block font-semibold mb-2">Ihre E-Mail:</label>
          <input 
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="your@email.com"
            className="w-full border rounded p-2"
          />
        </div>
        
        <button 
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 text-white font-semibold py-2 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {loading ? 'Scannen...' : 'Website scannen'}
        </button>
      </form>
      
      {result && (
        <RiskIndicator
          riskLevel={result.scanResult.riskLevel}
          riskFactors={result.scanResult.riskFactors}
          detectedServices={result.scanResult.detectedServices}
          activeModules={result.moduleConfig.activeModules}
          recommendations={result.moduleConfig.recommendations}
          criticalIssues={result.moduleConfig.criticalIssues}
        />
      )}
    </div>
  );
}
```

**Zeit: 2 Tage**

---

### Phase 2 Zusammenfassung

| Komponente | Zeilen Code | Zeit |
|-----------|------------|------|
| Scanner Engine | 350 | 3 Tage |
| Risiko-Engine | 250 | 2 Tage |
| API Route | 80 | 1 Tag |
| Frontend Komponente | 180 | 2 Tage |
| **PHASE 2 TOTAL** | **860** | **~8 Tage** |

**Deliverables:**
- ✓ Scanner erkennt 10+ Services
- ✓ Risiko-Ampel (Grün/Orange/Rot)
- ✓ Automatische Modul-Aktivierung (P1-P7, D1-D12, etc.)
- ✓ Datenbank-Integration (Scans speichern)
- ✓ API unter `/api/scan`
- ✓ Responsive Risikoampel-UI

**Test-Fall:**
- URL: https://www.dataquard.ch
- Expected Risk: Orange (Google Analytics + US-Transfer)
- Expected Modules: P1–P7, D1, C3, T2, W5

---

---

# PHASE 3: Stripe Zahlung & Abo-Modell (1 Woche)

**Ziel:** Kunden können für CHF 149 kaufen oder CHF 59/Jahr abonnieren

---

### Schritt 3.1: Stripe Produkte anlegen (30 Min)

1. **Gehen Sie zu:** https://dashboard.stripe.com/products
2. **Klicken:** "Create product"
3. **Produkt 1 erstellen:**

```
Name: Dataquard PROFESSIONAL
Beschreibung: Komplette DSGVO-Datenschutzerklärung
                Einmalige Zahlung
                Alle Module (P1-P7, W1-W8, D1-D12, C1-C5, Z1-Z3, HR1-HR5)
                PDF-Export & HTML
                Lebenslang gültig

Preis: CHF 149.00
Häufigkeit: Einmalig (one-time)
```

Kopieren Sie die **Preis-ID** (z.B. `price_1Mqhw0Kq...`) → Speichern Sie diese!

**Produkt 2 erstellen:**

```
Name: Dataquard ESSENTIAL
Beschreibung: Datenschutzerklärung mit Updates
              Jahresabo
              Automatische Updates bei Gesetzesänderungen
              Support & Versionsverwaltung

Preis: CHF 59.00 / Jahr
Häufigkeit: Jährlich (yearly)
```

Kopieren Sie auch diese **Preis-ID** → In `.env.local` speichern!

**Time: 30 Min**

---

### Schritt 3.2: Stripe Secrets konfigurieren

**Datei:** `.env.local`

```env
# Stripe API Keys
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxxxx

# Preise
STRIPE_PROFESSIONAL_PRICE_ID=price_1Mqhw0Kq...
STRIPE_ESSENTIAL_PRICE_ID=price_1Mqhw1Kq...

# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGc...
```

**Hinweis:** Diese Keys niemals in Git committen! `.env.local` sollte in `.gitignore` stehen.

---

### Schritt 3.3: Checkout-Flow implementieren (2 Tage)

**Datei:** `/app/api/checkout/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export async function POST(req: NextRequest) {
  try {
    const { plan, email, name, scanId } = await req.json();
    
    // Plan zu Preis-ID mappen
    const priceMap: Record<string, string> = {
      'PROFESSIONAL': process.env.STRIPE_PROFESSIONAL_PRICE_ID!,
      'ESSENTIAL': process.env.STRIPE_ESSENTIAL_PRICE_ID!
    };
    
    const priceId = priceMap[plan];
    if (!priceId) {
      return NextResponse.json(
        { error: 'Ungültiger Plan' },
        { status: 400 }
      );
    }
    
    // Checkout Session erstellen
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price: priceId,
          quantity: 1
        }
      ],
      mode: plan === 'ESSENTIAL' ? 'subscription' : 'payment',
      success_url: `${process.env.NEXT_PUBLIC_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_URL}/`,
      customer_email: email,
      client_reference_id: scanId,
      metadata: {
        customerName: name,
        plan: plan,
        scanId: scanId
      }
    });
    
    return NextResponse.json({
      sessionId: session.id,
      redirectUrl: session.url
    });
    
  } catch (error: any) {
    console.error('Checkout error:', error);
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
```

**Datei:** `/components/CheckoutButton.tsx`

```tsx
'use client';

import { useEffect, useState } from 'react';
import { loadStripe } from '@stripe/js';

export function CheckoutButton({
  plan,
  price,
  label
}: {
  plan: 'PROFESSIONAL' | 'ESSENTIAL';
  price: string;
  label: string;
}) {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plan,
          email,
          name,
          scanId: sessionStorage.getItem('scanId') || ''
        })
      });
      
      const { sessionId, error } = await res.json();
      if (error) throw new Error(error);
      
      // Zu Stripe Checkout leiten
      const stripe = await loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!);
      await stripe?.redirectToCheckout({ sessionId });
      
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleCheckout} className="bg-white rounded-lg shadow p-6">
      <div className="mb-4">
        <label className="block font-semibold mb-2">Name:</label>
        <input 
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="w-full border rounded p-2"
        />
      </div>
      
      <div className="mb-4">
        <label className="block font-semibold mb-2">E-Mail:</label>
        <input 
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="w-full border rounded p-2"
        />
      </div>
      
      <div className="mb-4 p-4 bg-blue-50 rounded">
        <p className="text-lg font-bold text-blue-900">{price}</p>
        <p className="text-sm text-gray-600">
          {plan === 'PROFESSIONAL' ? 'Einmalige Zahlung' : 'Pro Jahr'}
        </p>
      </div>
      
      <button 
        type="submit"
        disabled={loading}
        className="w-full bg-green-600 text-white font-semibold py-3 rounded hover:bg-green-700 disabled:opacity-50"
      >
        {loading ? 'Wird weitergeleitet...' : label}
      </button>
    </form>
  );
}
```

**Time: 2 Tage**

---

### Schritt 3.4: Webhook Handler für Zahlungen (1 Tag)

**Datei:** `/app/api/webhooks/stripe/route.ts`

```typescript
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { createClient } from '@supabase/supabase-js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

export async function POST(req: NextRequest) {
  const body = await req.text();
  const sig = req.headers.get('stripe-signature')!;
  
  let event: Stripe.Event;
  
  try {
    event = stripe.webhooks.constructEvent(
      body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (error: any) {
    console.error('Webhook signature verification failed:', error);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }
  
  // Event-Handler
  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        console.log('✓ Payment successful:', session.id);
        
        // Kunde in DB speichern
        const { error } = await supabase
          .from('customers')
          .upsert({
            email: session.customer_email,
            name: session.metadata?.customerName,
            stripe_customer_id: session.customer,
            stripe_session_id: session.id,
            plan: session.metadata?.plan || 'PROFESSIONAL',
            paid_at: new Date().toISOString(),
            scan_id: session.metadata?.scanId,
            status: 'active'
          })
          .select();
        
        if (error) {
          console.error('❌ Database error:', error);
          throw error;
        }
        
        // Email mit Policy senden
        await sendPolicyEmail(
          session.customer_email!,
          session.metadata?.customerName,
          session.metadata?.scanId
        );
        
        break;
      }
      
      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription;
        console.log('✓ Subscription updated:', subscription.id);
        
        await supabase
          .from('customers')
          .update({ stripe_subscription_id: subscription.id })
          .eq('stripe_customer_id', subscription.customer);
        
        break;
      }
      
      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        console.log('✓ Subscription cancelled:', subscription.id);
        
        await supabase
          .from('customers')
          .update({ 
            status: 'cancelled',
            cancelled_at: new Date().toISOString()
          })
          .eq('stripe_customer_id', subscription.customer);
        
        break;
      }
      
      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        console.log('❌ Payment failed:', invoice.id);
        
        // Hinweis: Kunde benachrichtigen
        await supabase
          .from('customers')
          .update({ status: 'payment_failed' })
          .eq('stripe_customer_id', invoice.customer);
        
        break;
      }
    }
    
    return NextResponse.json({ received: true });
    
  } catch (error: any) {
    console.error('❌ Webhook processing error:', error);
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}

// Email mit Policy versenden
async function sendPolicyEmail(
  email: string,
  name: string | undefined,
  scanId: string | undefined
) {
  // TODO: Implementieren Sie E-Mail-Versand
  // Mit Resend oder SendGrid
  console.log(`📧 Sending policy email to ${email}`);
}
```

**Stripe Webhook registrieren:**

1. Gehen Sie zu https://dashboard.stripe.com/webhooks
2. "Add endpoint"
3. URL: `https://dataquard.ch/api/webhooks/stripe`
4. Events: Wählen Sie:
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_failed`
5. Kopieren Sie "Signing secret" → `.env.local` als `STRIPE_WEBHOOK_SECRET`

**Time: 1 Day**

---

### Schritt 3.5: Feature-Gates & Access Control (1 Tag)

**Datei:** `/lib/permissions.ts`

```typescript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_KEY!
);

export async function checkCustomerPlan(
  email: string
): Promise<'PROFESSIONAL' | 'ESSENTIAL' | null> {
  const { data, error } = await supabase
    .from('customers')
    .select('plan, status')
    .eq('email', email)
    .eq('status', 'active')
    .single();
  
  if (error || !data) return null;
  return data.plan;
}

export async function hasFeature(
  email: string,
  feature: string
): Promise<boolean> {
  const plan = await checkCustomerPlan(email);
  
  const features: Record<string, string[]> = {
    'PROFESSIONAL': [
      'generate_policy',
      'export_pdf',
      'export_html',
      'custom_branding',
      'multiple_policies',
      'api_access'
    ],
    'ESSENTIAL': [
      'generate_policy',
      'export_pdf'
    ]
  };
  
  return plan ? features[plan]?.includes(feature) || false : false;
}

export async function getCustomerPolicy(email: string) {
  const { data, error } = await supabase
    .from('policies')
    .select('*')
    .eq('customer_email', email)
    .order('created_at', { ascending: false })
    .limit(1)
    .single();
  
  if (error) return null;
  return data;
}
```

**Time: 1 Day**

---

### Schritt 3.6: Test-Zahlungen durchführen (1 Tag)

**Stripe Test-Kartendaten:**

| Feld | Wert |
|------|------|
| Kartennummer | 4242 4242 4242 4242 |
| Ablaufdatum | 12/25 |
| CVC | 123 |

**Test-Ablauf:**

1. Landing Page öffnen
2. "Jetzt kaufen" klicken
3. Formular ausfüllen:
   - Name: "Max Mustermann"
   - Email: "test@example.com"
4. Kartendaten eingeben (oben)
5. "Zahlung durchführen"
6. Sollte zu Success-Page leiten
7. **Stripe Dashboard prüfen:**
   - https://dashboard.stripe.com/payments
   - Zahlung sollte als "Succeeded" angezeigt werden
8. **Supabase prüfen:**
   - `customers` Table
   - Neue Row mit email + plan sollte erstellt sein

**Debugging:**

- ❌ "Invalid API Key" → `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` nicht gesetzt
- ❌ "Session not found" → API Route nicht erreichbar
- ❌ "Webhook failed" → `STRIPE_WEBHOOK_SECRET` falsch

**Time: 1 Day**

---

### Phase 3 Zusammenfassung

| Komponente | Zeit | Status |
|-----------|------|--------|
| Stripe Setup | 30 Min | ✓ Produkte angelegt |
| Checkout API | 2 Tage | ✓ Session generiert |
| Webhook Handler | 1 Tag | ✓ Kunde gespeichert |
| Feature Gates | 1 Tag | ✓ Access Control |
| Testing | 1 Tag | ✓ Test-Zahlungen OK |
| **PHASE 3 TOTAL** | **~5–6 Tage** | |

**Deliverables:**
- ✓ CHF 149 Einmalkauf funktioniert
- ✓ CHF 59/Jahr Abo funktioniert
- ✓ Daten werden in Supabase gespeichert
- ✓ Stripe Dashboard zeigt alle Zahlungen
- ✓ Webhook ist registriert & funktioniert

---

## 🎯 Nach Phase 3

**Nächste Schritte:**

1. ✓ Phase 2 & 3 erfolgreich
2. → Phase 4: Policy-Generierung & Dashboard (siehe Ablaufplan)
3. → Phase 5: KI-Features
4. → Phase 6: Anwalt (parallel ab Phase 4)
5. → Phase 7: Launch & Marketing

**Geschätzte Gesamtdauer bis Launch: 8–10 Wochen**

Brauchen Sie Phase 4 detailliert ausgearbeitet? 🚀
