# 💰 Dataquard – Detaillierte Kostenkalkulation & Finanzmodell

**Version:** 1.0  
**Datum:** Februar 2026  
**Status:** Vollständige Finanzanalyse  
**Umfang:** Einmalig + 12-Monats-Prognose + Szenarien

---

## 📑 Inhaltsverzeichnis

1. [Zusammenfassung für Entscheidungsträger](#zusammenfassung-für-entscheidungsträger)
2. [Detaillierte Kostenaufschlüsselung](#detaillierte-kostenaufschlüsselung)
3. [Einmalkosten (Setup)](#einmalkosten-setup)
4. [Laufende Kosten (monatlich)](#laufende-kosten-monatlich)
5. [Umsatz-Modelle](#umsatz-modelle)
6. [Break-Even Analyse](#break-even-analyse)
7. [12-Monats Finanzprognose (3 Szenarien)](#12-monats-finanzprognose-3-szenarien)
8. [Sensitivitätsanalyse](#sensitivitätsanalyse)
9. [Kostenoptimierung](#kostenoptimierung)
10. [Preisoptimierung](#preisoptimierung)

---

## 📊 Zusammenfassung für Entscheidungsträger

### Geschäftsmodell auf einen Blick

| Metrik | Wert | Bemerkung |
|--------|------|-----------|
| **Startkapital** | CHF 1.235 | Minimal: CHF 15 (ohne Anwalt) |
| **Break-Even** | Monat 1–2 | Nach ~1 bezahlten Kauf |
| **Gewinn pro Kauf** | CHF 131 | Nach Stripe-Gebühren (2.9% + 0.30) |
| **Gewinn pro Abo/Jahr** | CHF 46 | Nach Stripe-Gebühren |
| **Gewinn-Marge** | 85–90% | Hochgradig profitabel |
| **Monatliche Fixkosten** | CHF 3–75 | Je nach Kundenvolumen |
| **Jahr 1 Gewinn (konserv.)** | CHF 18.000 | Bei 100 Kunden |
| **Jahr 1 Gewinn (optimist.)** | CHF 65.000 | Bei 400 Kunden |

---

## 🔍 Detaillierte Kostenaufschlüsselung

### EINMALKOSTEN (Setup)

#### 1. Entwicklung & Infrastruktur-Setup

| Position | Kosten | Beschreibung |
|----------|--------|-------------|
| **Domain** | CHF 15 | dataquard.ch (1 Jahr, jährlich kündbar) |
| **Vercel Setup** | CHF 0 | Hosting, Deployment, Free Plan |
| **Supabase Setup** | CHF 0 | Datenbank (Zürich), Free Plan |
| **Stripe-Konto** | CHF 0 | Payment Gateway, keine Setup-Gebühr |
| **Anthropic API Key** | CHF 20 | Testguthaben für Scanner-Entwicklung |
| **GitHub Repository** | CHF 0 | Private Repo kostenlos |
| **Email-Service (Resend)** | CHF 0 | Free Plan (100 Emails/Tag) |
| **SSL-Zertifikat** | CHF 0 | Vercel/Supabase inklusive |
| **Monitoring (Sentry)** | CHF 0 | Free Plan für Error-Tracking |
| **Subtotal Infrastruktur** | **CHF 35** | |

#### 2. Entwicklungszeit & Beratung

| Position | Stunden | Kosten (CHF 150/Std) | Bemerkung |
|----------|---------|-------------------|----------|
| Planung & Design | 20 | CHF 3.000 | Wireframes, Architektur |
| Phase 0: Accounts | 3 | CHF 450 | Setup aller Services |
| Phase 1: Projekt-Setup | 5 | CHF 750 | Next.js + Supabase |
| Phase 2: Scanner | 40 | CHF 6.000 | Engine + Engine-Testing |
| Phase 3: Stripe | 25 | CHF 3.750 | Payment-Integration |
| Phase 4: Generator | 40 | CHF 6.000 | Policy-Generierung |
| Phase 5: KI-Features | 15 | CHF 2.250 | Claude API Integration |
| Phase 6: Testing & QA | 20 | CHF 3.000 | Bugs, Optimierung |
| **Subtotal Entwicklung** | **168 Std** | **CHF 25.200** | ~4 Wochen à 40 Std/Woche |

#### 3. Rechtliche & Administrative Kosten

| Position | Kosten | Beschreibung |
|----------|--------|-------------|
| **Anwalt: Disclaimer** | CHF 300–500 | Haftungs-Disclaimer (1–2 Std) |
| **Anwalt: AGB** | CHF 500–1.000 | Geschäftsbedingungen (2–3 Std) |
| **Anwalt: Modul-Validierung** | **CHF 3.500** | **Text-Module validieren (10–15 Std)** |
| **Auftragsverarbeitungsvertrag (AVV)** | CHF 0 | Supabase stellt aus (kostenlos) |
| **Domain-Registrar** | CHF 0 | Hostpoint kostenlos mit Domain |
| **Subtotal Rechtlich** | **CHF 4.300–5.000** | |

#### 4. Marketing & Launch

| Position | Kosten | Beschreibung |
|----------|--------|-------------|
| **Website-Design/Landingpage** | CHF 0 | Selbst erstellt (siehe HTML) |
| **Logo-Design** | CHF 0 | Professionell erstellt (Sie haben diese) |
| **LinkedIn-Post** | CHF 0 | Organisch, kein Paid Ads |
| **Email-Liste aufbau** | CHF 0 | Organisch |
| **Beta-Tester-Kompensation** | CHF 0 | Kostenlos im Tausch gegen Feedback |
| **Subtotal Marketing** | **CHF 0** | |

#### 5. Sonstiges & Puffer

| Position | Kosten | Beschreibung |
|----------|--------|-------------|
| **Unerwartete Ausgaben** | CHF 300 | 5% Puffer für Bugs, Tools, etc. |
| **Hosting-Setup (Hostpoint)** | CHF 150 | Domain + Server für Jahr 1 |
| **Subtotal Sonstiges** | **CHF 450** | |

---

### GESAMTE EINMALKOSTEN (SETUP)

| Kategorie | Kosten |
|-----------|--------|
| Infrastruktur | CHF 35 |
| Entwicklung | CHF 25.200 |
| Rechtlich & Admin | **CHF 4.300–5.000** |
| Marketing | CHF 0 |
| Sonstiges | CHF 450 |
| **GESAMTKOSTEN SETUP** | **CHF 29.985–30.685** |

**Anmerkung:** Falls Sie den Anwalt sparen möchten (nicht empfohlen): **CHF 25.685**

---

## 💸 Laufende Kosten (monatlich)

### Kostenstruktur nach Kundenvolumen

#### **SZENARIO A: 0–50 Kunden pro Monat**

| Service | Kosten | Auslöser | Erklärung |
|---------|--------|---------|-----------|
| **Vercel Hosting** | CHF 0 | <100 GB Traffic | Free Plan ausreichend |
| **Supabase Datenbank** | CHF 0 | <500 MB oder <50k rows | Free Plan ausreichend |
| **Resend Email** | CHF 0 | <100 Emails/Tag | Free Plan ausreichend |
| **Claude API (Scanner)** | ~CHF 2 | Pro Scan: CHF 0.01–0.02 | 100–200 Scans/Mt |
| **Stripe-Gebühren** | 2.9% + 0.30 | Jede Transaktion | Automatisch eingezogen |
| **Domain** | CHF 1.25 | Jährlich / 12 | CHF 15 / 12 Monate |
| **Monitoring (Sentry)** | CHF 0 | Free Plan | Error-Tracking |
| **GitHub** | CHF 0 | Free Private Repo | Unbegrenzt |
| **TOTAL FIXKOSTEN** | **CHF 3** | | |

#### **SZENARIO B: 50–200 Kunden pro Monat**

| Service | Kosten | Auslöser | Erklärung |
|---------|--------|---------|-----------|
| **Vercel Hosting** | CHF 0 | <100 GB Traffic | Free Plan noch ok |
| **Supabase Datenbank** | CHF 27 | >500 MB Speicher | Pro Plan: CHF 27/Mt |
| **Resend Email** | CHF 0–22 | <3000 oder >3000 Emails | >3000 = CHF 22 |
| **Claude API** | ~CHF 8 | 300–500 Scans/Mt | CHF 0.01–0.02 pro Scan |
| **Stripe-Gebühren** | 2.9% + 0.30 | Jede Transaktion | Automatisch |
| **Domain** | CHF 1.25 | Jährlich / 12 | CHF 15 / 12 |
| **Sentry Pro** | CHF 29 | >100k Events/Mt | Pro Plan: CHF 29/Mt |
| **GitHub** | CHF 0 | Free Private Repo | Unbegrenzt |
| **TOTAL FIXKOSTEN** | **CHF 36–58** | | (ohne Stripe %) |

#### **SZENARIO C: 200+ Kunden pro Monat**

| Service | Kosten | Auslöser | Erklärung |
|---------|--------|---------|-----------|
| **Vercel Hosting** | CHF 22 | >100 GB Traffic | Pro Plan: CHF 22/Mt |
| **Supabase Datenbank** | CHF 27 | >500 MB Speicher | Pro Plan: CHF 27/Mt |
| **Resend Email** | CHF 22 | >3000 Emails | Standard Plan: CHF 22/Mt |
| **Claude API** | ~CHF 25 | 1000+ Scans/Mt | CHF 0.01–0.02 pro Scan |
| **Stripe-Gebühren** | 2.9% + 0.30 | Jede Transaktion | Automatisch |
| **Domain** | CHF 1.25 | Jährlich / 12 | CHF 15 / 12 |
| **Sentry Pro** | CHF 29 | >100k Events/Mt | Pro Plan: CHF 29/Mt |
| **GitHub Team** | CHF 21 | Private Repos + Team | Team Plan: CHF 21/Mt |
| **TOTAL FIXKOSTEN** | **CHF 147–175** | | (ohne Stripe %) |

---

### Stripe-Gebühren (detailliert)

**Gebührenstruktur:**
- Kredit-/Debitkarte: **2.9% + CHF 0.30 pro Transaktion**
- TWINT: **1.5% + CHF 0.15**
- SEPA-Überweisung: **0.8% + CHF 0.10**

**Beispiele (Kartengebühren):**

| Transaktion | Netto-Betrag | Gebühren | Erhalten Sie |
|-------------|-------------|----------|-------------|
| CHF 149 (PROFESSIONAL) | CHF 149 | CHF 4.62 | CHF 144.38 |
| CHF 59 (ESSENTIAL Abo) | CHF 59 | CHF 2.01 | CHF 56.99 |
| 10 Käufe × CHF 149 | CHF 1.490 | CHF 43.21 | CHF 1.446.79 |

---

## 💵 Umsatz-Modelle

### Produkt-Preisgestaltung

| Plan | Preis | Häufigkeit | Zielgruppe | Geschätzte Marktgröße |
|------|-------|-----------|-----------|----------------------|
| **PROFESSIONAL** | CHF 149 | Einmalig | KMU (5–50 MA) | ~300.000 |
| **ESSENTIAL** | CHF 59 | Jährlich | Privatpersonen | ~300.000 |
| **ENTERPRISE** | CHF 499 | Jährlich | Konzerne | ~1.000 (Phase 2) |

**Hinweis:** ENTERPRISE ist Phase 2 (später). Für jetzt: PROFESSIONAL + ESSENTIAL.

---

### Umsatz-Szenarien

#### **SZENARIO 1: KONSERVATIV (30% Conv. Rate)**

Annahme: 10 Website-Scans/Mt → 3 Käufe

| Monat | Scans | Prof.-Käufe | Essential-Abos | Brutto-Umsatz | Stripe-Geb. | Netto |
|-------|-------|------------|----------------|---------------|------------|-------|
| 1 | 10 | 3 | 0 | CHF 447 | CHF 17 | CHF 430 |
| 2 | 20 | 6 | 1 | CHF 953 | CHF 36 | CHF 917 |
| 3 | 30 | 9 | 2 | CHF 1.460 | CHF 56 | CHF 1.404 |
| 4 | 40 | 12 | 4 | CHF 1.966 | CHF 76 | CHF 1.890 |
| 5 | 50 | 15 | 6 | CHF 2.472 | CHF 96 | CHF 2.376 |
| 6 | 60 | 18 | 9 | CHF 2.979 | CHF 116 | CHF 2.863 |
| 7–12 | 70+ | 21+ | 12+ | CHF 3.500+ | CHF 140+ | CHF 3.360+ |
| **JAHR 1** | **~500** | **~120** | **~80** | **CHF 25.000** | **CHF 950** | **CHF 24.050** |

**Gewinn Jahr 1:** CHF 24.050 - CHF 26.885 (Setup) = **-CHF 2.835** (break-even in Mt 2, Profit ab Mt 3)

---

#### **SZENARIO 2: REALISTISCH (50% Conv. Rate)**

Annahme: 20 Website-Scans/Mt → 10 Käufe

| Monat | Scans | Prof.-Käufe | Essential-Abos | Brutto-Umsatz | Stripe-Geb. | Netto |
|-------|-------|------------|----------------|---------------|------------|-------|
| 1 | 20 | 10 | 0 | CHF 1.490 | CHF 56 | CHF 1.434 |
| 2 | 40 | 20 | 2 | CHF 3.000 | CHF 113 | CHF 2.887 |
| 3 | 60 | 30 | 5 | CHF 4.561 | CHF 172 | CHF 4.389 |
| 4 | 80 | 40 | 8 | CHF 6.072 | CHF 230 | CHF 5.842 |
| 5 | 100 | 50 | 12 | CHF 7.583 | CHF 287 | CHF 7.296 |
| 6 | 120 | 60 | 16 | CHF 9.094 | CHF 344 | CHF 8.750 |
| 7–12 | 140+ | 70+ | 20+ | CHF 10.600+ | CHF 401+ | CHF 10.199+ |
| **JAHR 1** | **~1.000** | **~400** | **~150** | **CHF 69.000** | **CHF 2.610** | **CHF 66.390** |

**Gewinn Jahr 1:** CHF 66.390 - CHF 26.885 (Setup) = **CHF 39.505** (break-even in Mt 1, danach reines Profit!)

---

#### **SZENARIO 3: OPTIMISTISCH (80% Conv. Rate)**

Annahme: 40 Website-Scans/Mt → 32 Käufe

| Monat | Scans | Prof.-Käufe | Essential-Abos | Brutto-Umsatz | Stripe-Geb. | Netto |
|-------|-------|------------|----------------|---------------|------------|-------|
| 1 | 40 | 32 | 0 | CHF 4.768 | CHF 178 | CHF 4.590 |
| 2 | 80 | 64 | 5 | CHF 9.566 | CHF 361 | CHF 9.205 |
| 3 | 120 | 96 | 12 | CHF 14.364 | CHF 543 | CHF 13.821 |
| 4 | 160 | 128 | 20 | CHF 19.162 | CHF 725 | CHF 18.437 |
| 5 | 200 | 160 | 30 | CHF 23.960 | CHF 907 | CHF 23.053 |
| 6 | 240 | 192 | 42 | CHF 28.758 | CHF 1.089 | CHF 27.669 |
| 7–12 | 280+ | 224+ | 56+ | CHF 33.556+ | CHF 1.271+ | CHF 32.285+ |
| **JAHR 1** | **~2.000** | **~1.200** | **~350** | **CHF 195.000** | **CHF 7.410** | **CHF 187.590** |

**Gewinn Jahr 1:** CHF 187.590 - CHF 26.885 (Setup) = **CHF 160.705** (break-even in Mt 1, exponentielles Wachstum!)

---

## 📍 Break-Even Analyse

### Wann rentiert sich Dataquard?

**Berechnung:** Setup-Kosten / Gewinn pro Transaktion

#### **Szenario A (Konservativ):**

```
Setup-Kosten: CHF 26.885
Durchschnitt-Gewinn pro Monat: CHF 430 (nach Stripe-Gebühren & Fixkosten)
Break-Even Monate: 26.885 / 430 = 62,5 Monate (5+ Jahre!)
```

⚠️ **Problem:** Zu langsam! Conversion Rate zu niedrig.

#### **Szenario B (Realistisch):**

```
Setup-Kosten: CHF 26.885
Durchschnitt-Gewinn pro Monat: CHF 7.296 (nach Stripe-Gebühren & Fixkosten)
Break-Even Monate: 26.885 / 7.296 = 3,7 Monate (~4 Monate)
```

✅ **Gut:** Break-Even nach ~4 Monaten.

**Monatlicher Durchbruch:**
- Monat 1: CHF 1.434 Netto (VERLUST: –CHF 25.451)
- Monat 2: CHF 2.887 + CHF 1.434 = CHF 4.321 Netto (VERLUST: –CHF 22.564)
- Monat 3: CHF 4.389 + CHF 4.321 = CHF 8.710 Netto (VERLUST: –CHF 18.175)
- Monat 4: CHF 5.842 + CHF 8.710 = CHF 14.552 Netto (VERLUST: –CHF 12.333)
- **Monat 5: CHF 7.296 + CHF 14.552 = CHF 21.848 Netto (VERLUST: –CHF 5.037)**
- **Monat 6: CHF 8.750 + CHF 21.848 = CHF 30.598 Netto (✅ BREAK-EVEN!)**

**→ Break-Even nach ~6 Monaten (realistisches Szenario)**

#### **Szenario C (Optimistisch):**

```
Setup-Kosten: CHF 26.885
Durchschnitt-Gewinn pro Monat: CHF 23.053 (nach Stripe-Gebühren & Fixkosten)
Break-Even Monate: 26.885 / 23.053 = 1,2 Monate (~6 Wochen!)
```

✅ **Hervorragend:** Break-Even nach ~6 Wochen!

---

## 📈 12-Monats Finanzprognose (3 Szenarien)

### SZENARIO A: KONSERVATIV

**Annahmen:**
- 10 Scans/Mt → 3 Käufe/Mt
- 0,5 Abo/Mt (Wachstum von 0 auf 6 pro Mt)
- 30% Conversion Rate
- Starke Konkurrenz, langsameres Wachstum

| Mt | Käufe | Abos | Brutto | Stripe % | Fixkosten | Netto | Kum. Gewinn |
|----|-------|------|--------|---------|-----------|--------|------------|
| 1 | 3 | 0 | CHF 447 | CHF 17 | CHF 3 | CHF 427 | CHF 427 |
| 2 | 6 | 1 | CHF 953 | CHF 36 | CHF 3 | CHF 914 | CHF 1.341 |
| 3 | 9 | 2 | CHF 1.460 | CHF 56 | CHF 3 | CHF 1.401 | CHF 2.742 |
| 4 | 12 | 4 | CHF 1.966 | CHF 76 | CHF 3 | CHF 1.887 | CHF 4.629 |
| 5 | 15 | 6 | CHF 2.472 | CHF 96 | CHF 3 | CHF 2.373 | CHF 7.002 |
| 6 | 18 | 9 | CHF 2.979 | CHF 116 | CHF 3 | CHF 2.860 | CHF 9.862 |
| 7 | 21 | 12 | CHF 3.485 | CHF 136 | CHF 3 | CHF 3.346 | CHF 13.208 |
| 8 | 24 | 15 | CHF 3.991 | CHF 156 | CHF 3 | CHF 3.832 | CHF 17.040 |
| 9 | 27 | 18 | CHF 4.498 | CHF 176 | CHF 3 | CHF 4.319 | CHF 21.359 |
| 10 | 30 | 21 | CHF 5.004 | CHF 196 | CHF 3 | CHF 4.805 | CHF 26.164 |
| 11 | 33 | 24 | CHF 5.510 | CHF 216 | CHF 3 | CHF 5.291 | CHF 31.455 |
| 12 | 36 | 27 | CHF 6.017 | CHF 236 | CHF 3 | CHF 5.778 | CHF 37.233 |
| **JAHR 1** | **276** | **158** | **CHF 48.782** | **CHF 1.889** | **CHF 36** | **CHF 46.857** | **CHF 46.857** |

**Gewinn Jahr 1:** CHF 46.857 - CHF 26.885 (Setup) = **CHF 19.972 Netto-Profit**

**ROI:** (CHF 19.972 / CHF 26.885) × 100 = **74,3%** (nicht optimal)

---

### SZENARIO B: REALISTISCH

**Annahmen:**
- 20 Scans/Mt → 10 Käufe/Mt
- 1,5 Abo/Mt (Wachstum von 0 auf 20 pro Mt)
- 50% Conversion Rate
- Moderates Wachstum, solide Traction

| Mt | Käufe | Abos | Brutto | Stripe % | Fixkosten | Netto | Kum. Gewinn |
|----|-------|------|--------|---------|-----------|--------|------------|
| 1 | 10 | 0 | CHF 1.490 | CHF 56 | CHF 3 | CHF 1.431 | CHF 1.431 |
| 2 | 20 | 2 | CHF 3.000 | CHF 113 | CHF 3 | CHF 2.884 | CHF 4.315 |
| 3 | 30 | 5 | CHF 4.561 | CHF 172 | CHF 3 | CHF 4.386 | CHF 8.701 |
| 4 | 40 | 8 | CHF 6.072 | CHF 230 | CHF 3 | CHF 5.839 | CHF 14.540 |
| 5 | 50 | 12 | CHF 7.583 | CHF 287 | CHF 3 | CHF 7.293 | CHF 21.833 |
| 6 | 60 | 16 | CHF 9.094 | CHF 344 | CHF 3 | CHF 8.747 | CHF 30.580 |
| 7 | 70 | 20 | CHF 10.605 | CHF 401 | CHF 36 | CHF 10.168 | CHF 40.748 |
| 8 | 80 | 25 | CHF 12.116 | CHF 458 | CHF 36 | CHF 11.622 | CHF 52.370 |
| 9 | 90 | 30 | CHF 13.627 | CHF 515 | CHF 36 | CHF 13.076 | CHF 65.446 |
| 10 | 100 | 35 | CHF 15.138 | CHF 572 | CHF 36 | CHF 14.530 | CHF 79.976 |
| 11 | 110 | 40 | CHF 16.649 | CHF 629 | CHF 36 | CHF 15.984 | CHF 95.960 |
| 12 | 120 | 45 | CHF 18.160 | CHF 686 | CHF 58 | CHF 17.416 | CHF 113.376 |
| **JAHR 1** | **880** | **238** | **CHF 138.095** | **CHF 5.263** | **CHF 262** | **CHF 132.570** | **CHF 132.570** |

**Gewinn Jahr 1:** CHF 132.570 - CHF 26.885 (Setup) = **CHF 105.685 Netto-Profit**

**ROI:** (CHF 105.685 / CHF 26.885) × 100 = **393%** (sehr gut!)

**Gewinn pro Kunde (durchschnittlich):** CHF 132.570 / 1.118 Kunden = **CHF 118,50**

---

### SZENARIO C: OPTIMISTISCH

**Annahmen:**
- 40 Scans/Mt → 32 Käufe/Mt
- 4 Abos/Mt (Wachstum von 0 auf 50+ pro Mt)
- 80% Conversion Rate
- Starkes Viral-Wachstum, effektives Marketing

| Mt | Käufe | Abos | Brutto | Stripe % | Fixkosten | Netto | Kum. Gewinn |
|----|-------|------|--------|---------|-----------|--------|------------|
| 1 | 32 | 0 | CHF 4.768 | CHF 178 | CHF 3 | CHF 4.587 | CHF 4.587 |
| 2 | 64 | 5 | CHF 9.566 | CHF 361 | CHF 3 | CHF 9.202 | CHF 13.789 |
| 3 | 96 | 12 | CHF 14.364 | CHF 543 | CHF 3 | CHF 13.818 | CHF 27.607 |
| 4 | 128 | 20 | CHF 19.162 | CHF 725 | CHF 3 | CHF 18.434 | CHF 46.041 |
| 5 | 160 | 30 | CHF 23.960 | CHF 907 | CHF 3 | CHF 23.050 | CHF 69.091 |
| 6 | 192 | 42 | CHF 28.758 | CHF 1.089 | CHF 3 | CHF 27.666 | CHF 96.757 |
| 7 | 224 | 56 | CHF 33.556 | CHF 1.271 | CHF 58 | CHF 32.227 | CHF 128.984 |
| 8 | 256 | 72 | CHF 38.354 | CHF 1.453 | CHF 58 | CHF 36.843 | CHF 165.827 |
| 9 | 288 | 90 | CHF 43.152 | CHF 1.635 | CHF 175 | CHF 41.342 | CHF 207.169 |
| 10 | 320 | 110 | CHF 47.950 | CHF 1.817 | CHF 175 | CHF 45.958 | CHF 253.127 |
| 11 | 352 | 132 | CHF 52.748 | CHF 1.999 | CHF 175 | CHF 50.574 | CHF 303.701 |
| 12 | 384 | 156 | CHF 57.546 | CHF 2.181 | CHF 175 | CHF 55.190 | CHF 358.891 |
| **JAHR 1** | **2.976** | **725** | **CHF 373.716** | CHF 14.159 | CHF 832 | **CHF 358.725** | **CHF 358.725** |

**Gewinn Jahr 1:** CHF 358.725 - CHF 26.885 (Setup) = **CHF 331.840 Netto-Profit**

**ROI:** (CHF 331.840 / CHF 26.885) × 100 = **1.234%** (ausgezeichnet!)

**Gewinn pro Kunde:** CHF 358.725 / 3.701 Kunden = **CHF 96,95**

---

## 🔄 Sensitivitätsanalyse

### Wie sensibel ist das Modell auf Änderungen?

#### **1. Auswirkung von Conversion-Rate-Änderungen**

| Conversion | Yr 1 Käufe | Yr 1 Umsatz | Yr 1 Gewinn | Rentabilität |
|-----------|----------|----------|----------|------------|
| 20% | 176 | CHF 26.204 | CHF -632 | ❌ Verlust |
| 30% | 276 | CHF 48.782 | CHF 19.972 | ⚠️ Knapp |
| 40% | 368 | CHF 66.440 | CHF 39.605 | ✅ OK |
| 50% | 880 | CHF 138.095 | CHF 105.685 | ✅✅ Gut |
| 60% | 1.056 | CHF 175.080 | CHF 148.195 | ✅✅✅ Sehr gut |
| 70% | 1.232 | CHF 212.064 | CHF 185.179 | ✅✅✅ Hervorragend |
| 80% | 2.976 | CHF 373.716 | CHF 331.840 | 🚀 Mega! |

**Kritischer Punkt:** Mindestens **40% Conversion Rate** für profitabel sein.

---

#### **2. Auswirkung von Preis-Änderungen**

| Szenario | Prof.-Preis | Ess.-Preis | Yr 1 Umsatz | Yr 1 Gewinn | ∆ |
|---------|---------|---------|----------|----------|---|
| -20% | CHF 119 | CHF 47 | CHF 109.276 | CHF 82.391 | -22% |
| -10% | CHF 134 | CHF 53 | CHF 123.686 | CHF 96.801 | -8% |
| **AKTUELL** | **CHF 149** | **CHF 59** | **CHF 138.095** | **CHF 105.685** | |
| +10% | CHF 164 | CHF 65 | CHF 152.505 | CHF 125.620 | +19% |
| +20% | CHF 179 | CHF 71 | CHF 166.914 | CHF 140.029 | +32% |
| +30% | CHF 194 | CHF 77 | CHF 181.324 | CHF 154.439 | +46% |

**Insight:** 10% Preissteigerung = 19% Gewinn-Steigerung (gute Elastizität)

---

#### **3. Auswirkung von Kundenakquisitions-Kosten (CAC)**

Wenn Sie Geld in Marketing investieren:

| Marketing-Budget | Zus. Käufe | Break-Even | Yr 1 Profit |
|---------|---------|---------|---------|
| CHF 0 | Baseline | Mt 6 | CHF 105.685 |
| CHF 2.000 | +10% mehr | Mt 7 | CHF 111.000 |
| CHF 5.000 | +25% mehr | Mt 8 | CHF 121.000 |
| CHF 10.000 | +50% mehr | Mt 5 | CHF 135.000 |
| CHF 20.000 | +100% mehr | Mt 3 | CHF 170.000 |

**Optimal:** CHF 10.000 Marketing investieren = +50% mehr Käufe

---

#### **4. Auswirkung von Infrastructure-Skalierung**

Wenn Supabase/Vercel in Szenario C ab Mt 7 benötigt werden:

| Szenario | Fixkosten | Yr 1 Gewinn | ∆ |
|---------|---------|---------|---|
| A: Alles Free | ~CHF 50 | CHF 105.685 | Baseline |
| B: Mit Pro-Plans ab Mt 7 | ~CHF 1.000 | CHF 104.685 | -1% |
| C: Mit Pro-Plans ab Mt 4 | ~CHF 2.000 | CHF 103.685 | -2% |

**Insight:** Skalierungs-Kosten sind vernachlässigbar (< 2% Impact)

---

## 🎯 Kostenoptimierung

### Wie sparen Sie CHF 10.000+ pro Jahr?

#### **1. Cloud-Services Optimieren**

| Massnahme | Aktuell | Optimiert | Ersparnis |
|----------|---------|-----------|----------|
| **Vercel** | Pay-as-you-go | Pro Plan | CHF 0–22/Mt |
| **Supabase** | Free bis 500MB | Pro bei 500MB+ | CHF 27/Mt (unvermeidbar) |
| **Resend** | Free bis 100/Tag | Pro bei 3000+/Mt | CHF 22/Mt (unvermeidbar) |
| **Sentry** | Free bis 100k Events | Pro bei >100k | CHF 29/Mt (unvermeidbar) |
| **GitHub** | Free Private Repo | Free bleibt | CHF 0 |
| **Total Monatlich** | **CHF 0–3** | **CHF 48–79** | ❌ +CHF 50/Mt |

⚠️ **Problem:** Je mehr Kunden, desto höher die Kosten. Aber: Gewinn wächst schneller!

#### **2. Claude API Optimieren**

**Aktuell:** CHF 0.01–0.02 pro Scan = ~CHF 8–25/Mt (bei 400–1.200 Scans)

**Optimierungen:**

| Massnahme | Einsparung | Aufwand |
|----------|----------|--------|
| Caching (Duplicate Scans) | 20% | Mittel |
| Kleineres KI-Modell (Haiku statt Sonnet) | 60% | Einfach |
| Batch-Processing (Nacht-Scans) | 10% | Mittel |
| **Total möglich** | **70%** | |

**Beispiel:** Statt CHF 25/Mt auf CHF 7,50/Mt reduzieren.

---

#### **3. Entwicklungskosten Reduzieren**

**Einsparungspotenzial:**

| Posten | Original | Optimiert | Ersparnis |
|--------|---------|-----------|-----------|
| Selbst entwickeln (vs. Agentur) | CHF 25.200 | CHF 25.200 | CHF 0 |
| Open-Source nutzen | +CHF 5.000 | CHF 0 | CHF 5.000 |
| No-Code Tools teilweise | +CHF 10.000 | CHF 2.000 | CHF 8.000 |
| Automation/CI-CD | +CHF 5.000 | CHF 1.000 | CHF 4.000 |
| **Potenzielle Einsparungen** | | | **CHF 17.000** |

---

#### **4. Anwalt-Kosten Sparen**

| Option | Kosten | Risiko | Empfehlung |
|--------|--------|--------|------------|
| Kein Anwalt | CHF 0 | ⚠️ Hoch | Nicht empfohlen |
| Online-Vorlagen nutzen | CHF 500 | ⚠️ Mittel | OK für MVP |
| Anwalt beauftragen | CHF 1.200 | ✓ Niedrig | EMPFOHLEN |
| Laufende Anwalts-Abos | CHF 5.000+/Mt | ❌ Zu teuer | Nicht nötig |

---

### Optimiertes Budget (Einmalkosten)

| Posten | Original | Optimiert | Ersparnis |
|--------|---------|-----------|-----------|
| Infrastruktur | CHF 35 | CHF 35 | CHF 0 |
| Entwicklung | CHF 25.200 | CHF 20.000 | CHF 5.200 |
| Anwalt | CHF 1.200 | CHF 1.200 | CHF 0 |
| Marketing | CHF 0 | CHF 2.000 | -CHF 2.000 |
| Sonstiges | CHF 450 | CHF 250 | CHF 200 |
| **TOTAL** | **CHF 26.885** | **CHF 23.485** | **CHF 3.400 (13%)** |

---

## 💲 Preisoptimierung

### Welcher Preis ist optimal?

#### **Analyse: Price Elasticity**

| Preis | Est. Käufer | Umsatz | Ranking |
|-------|---------|--------|----------|
| CHF 99 | 150% | CHF 180.000 | ⭐⭐ |
| CHF 119 | 120% | CHF 172.000 | ⭐⭐ |
| CHF 149 | 100% | CHF 138.000 | ⭐⭐⭐ |
| CHF 179 | 80% | CHF 167.000 | ⭐⭐⭐ |
| CHF 199 | 65% | CHF 162.000 | ⭐⭐ |
| CHF 249 | 40% | CHF 150.000 | ⭐ |

**→ CHF 149 ist optimal (aktueller Preis)**

---

#### **Tiered Pricing Modell (Empfehlung ab Mt 6)**

| Plan | Preis | Features | Zielgruppe | Est. Mix |
|------|-------|---------|-----------|---------|
| **BASIC** | CHF 99 | Basis-Policy | Startups | 20% |
| **PROFESSIONAL** | CHF 149 | Alles inkl. | KMU | 60% |
| **PREMIUM** | CHF 249 | +Support+Updates | Konzerne | 20% |

**Auswirkung:** +15–20% Umsatz durch bessere Markt-Segmentierung

---

#### **Abo-Pricing Vergleich**

| Modell | Preis | Retention | Yr 1 LTV | Besser? |
|--------|-------|----------|---------|--------|
| Einmalig CHF 149 | CHF 149 | N/A | CHF 149 | Baseline |
| Abo CHF 59/Mt | CHF 708/Mt | 50% | CHF 354 | ✓ 2.4x |
| Abo CHF 49/Mt | CHF 588/Mt | 60% | CHF 353 | ✓ 2.4x |
| Abo CHF 39/Mt | CHF 468/Mt | 70% | CHF 328 | ✓ 2.2x |

**→ Abo-Modell generiert 2–2.4x mehr LTV**

---

## 📊 12-Monats Vergleich: Alle 3 Szenarien

| KPI | Konservativ | Realistisch | Optimistisch |
|-----|---------|----------|---------|
| **Scans** | 500 | 1.000 | 2.000 |
| **Einmalig-Käufe** | 276 | 880 | 2.976 |
| **Abo-Kunden** | 158 | 238 | 725 |
| **Brutto-Umsatz** | CHF 48.782 | CHF 138.095 | CHF 373.716 |
| **Stripe-Gebühren** | CHF 1.889 | CHF 5.263 | CHF 14.159 |
| **Fixkosten** | CHF 36 | CHF 262 | CHF 832 |
| **Netto-Umsatz** | CHF 46.857 | CHF 132.570 | CHF 358.725 |
| **Setup-Kosten** | CHF 26.885 | CHF 26.885 | CHF 26.885 |
| **Yr 1 Gewinn** | CHF 19.972 | **CHF 105.685** | CHF 331.840 |
| **ROI** | 74% | 393% | 1.234% |
| **Break-Even** | Mt 62 | Mt 6 | Mt 1 |
| **Gewinn/Kunde** | CHF 63 | CHF 118 | CHF 97 |
| **Monatl. Run-Rate (Mt 12)** | CHF 5.778 | CHF 17.416 | CHF 55.190 |

---

## 🎯 Rekommendationen

### **Szenario B (Realistisch) ist die beste Wahl:**

1. **Break-Even nach ~6 Monaten** (schnell, aber nicht unrealistisch)
2. **Yr 1 Profit CHF 105.685** (ausreichend für Weiterfinanzierung)
3. **ROI von 393%** (sehr solid)
4. **Gewinn/Kunde CHF 118** (nachhaltig)

### **Maßnahmen zum Break-Even in Mt 6:**

1. ✓ **Landing Page optimieren** (Conversion +5%)
2. ✓ **SEO-Marketing starten** (Mt 2, CHF 2.000 Budget)
3. ✓ **Beta-Tester akquirieren** (Mt 1, 10–15 Kunden)
4. ✓ **LinkedIn-Kampagne** (Mt 2, organisch)
5. ✓ **Content-Marketing** (Blog, Guides, kostenlos)
6. ✓ **Partnerships mit Hosting-Providern** (Hostpoint, Cyon)

### **Skalierungs-Roadmap (Jahr 2+):**

| Quartal | Ziel | Investment | Erwarteter ROI |
|---------|------|----------|--------|
| Q1 2027 | 1.000 Kunden | CHF 5.000 | CHF 200.000 |
| Q2 2027 | 2.000 Kunden | CHF 8.000 | CHF 350.000 |
| Q3 2027 | 3.500 Kunden | CHF 15.000 | CHF 550.000 |
| Q4 2027 | 5.000 Kunden | CHF 25.000 | CHF 750.000 |

---

## 💡 Fazit

**Dataquard ist ein hochgradig profitables Business mit:**

- ✅ Minimalen Einmalkosten (CHF 26.885)
- ✅ Niedrigen Fixkosten (<CHF 80/Mt)
- ✅ Hoher Gewinnmarge (85–90%)
- ✅ Schnellem Break-Even (Mt 6 realistisch)
- ✅ Grossem Skalierungs-Potenzial

**Finanzielle Prognose Jahr 1:**
- 🎯 Umsatz: CHF 138.095
- 💰 Gewinn: CHF 105.685
- 📈 ROI: 393%
- 🚀 Monatlicher Run-Rate Ende Jahr: CHF 17.416

**Status:** Grünes Licht für Launch! ✅
