# 📋 DATAQUARD – BUSINESSPLAN NACH SCHWEIZER RECHT
## Vollständig konform mit CH-Gesetzen, Steuern & Vorschriften

---

## 🎯 EXECUTIVE SUMMARY SCHWEIZ

**Gründungsort:** Kanton Basel-Landschaft (Reinach)
**Rechtsgebiet:** Schweizer Obligationenrecht (OR), Datenschutzgesetz (DSG), Steuergesetze (DBG, StHG)
**Gründungsmodell:** Starten als Einzelunternehmer, später zu GmbH

---

# 📋 TEIL 1: SCHWEIZER GEWERBEANMELDUNG

## Step 1: GEWERBEANMELDUNG (Kanton Basel-Landschaft)

### Was ist das?
Die **Gewerbeanmeldung** ist in der Schweiz die offizielle Registrierung deines Geschäftsbetriebs beim Kanton.

### Wo anmelden?
- **Kanton Basel-Landschaft**
- Amt für Wirtschaft und Arbeit
- Website: https://www.baselland.ch/
- Online-Portal: https://www.baselland.ch/gewerbe

### Formular: "Anmeldung Gewerbebetrieb"

**Erforderliche Angaben:**
```
☐ Vollständiger Name: Richard Rickli
☐ Wohnort: 4153 Reinach, Basel-Landschaft
☐ Geburtsdatum & -ort
☐ Nationalität: Schweizer
☐ Gewerbeart: "Softwareentwicklung, IT-Dienstleistungen & Online-Services"
☐ Geschäftsadresse: Deine Privatadresse (ok für Start!)
  → Beispiel: Hauptstrasse 123, 4153 Reinach
☐ Tätigkeit beschreiben: "Online-Generator für DSGVO-Compliance-Texte"
☐ Geplanter Geschäftsbeginn: 01.03.2026 (oder Datum deiner Wahl)
☐ Betriebsstätte(n): 1 (Homeoffice ok)
☐ Voraussichtlicher Jahresumsatz: CHF 0-50'000 (Schätzung für 2026)
```

### Kosten & Dauer

```
Kosten Kanton BL: CHF 0 (kostenlos!)
Kosten Gemeinde Reinach: CHF 0-50 (je nach Gemeinde)

Dauer: 
├─ Online-Einreichung: 5 Minuten
├─ Bearbeitung Kanton: 5-10 Arbeitstage
└─ Offizielle Bestätigung: Per Email

TOTAL: CHF 0-50 und 2 Wochen
```

### Was du danach bekommst

```
✅ Gewerbezertifikat (digital)
✅ Unternehmens-Identifikationsnummer (UID)
   Beispiel: CHE-123.456.789
✅ Bestätigung für Steuerbehörde
```

---

## Step 2: HANDELSREGISTER-EINTRAG (OPTIONAL aber EMPFOHLEN)

### Was ist das?
Das **Handelsregister** (HR) ist eine öffentliche Datenbank für alle Gewerbebetriebe der Schweiz.

### Wann notwendig?
```
OPTIONAL für:
├─ Einzelunternehmer
├─ Einfache Tätigkeiten
└─ Umsatz < CHF 500'000/Jahr

ZWINGEND für:
├─ GmbH (später)
├─ AG
└─ Kapitalgesellschaften
```

### MEINE EMPFEHLUNG: JA, machen!

**Gründe:**
- ✅ Professioneller Eindruck
- ✅ Kunden können dich verifizieren
- ✅ Bank verlangt es oft
- ✅ Nur CHF 200-400

### Wie eintragen?

**Online** via:
- https://www.shab.ch/ (Schweizer Handelsamtsblatt)
- Oder beim Handelsregisteramt Basel-Landschaft

**Erforderlich:**
- Unterschriebenes Anmeldeformular
- Kopie Gewerbezertifikat
- Handschrift-Unterschrift (original)

**Kosten:**
```
Eintrag: CHF 200-400 (einmalig)
Jahresgebühr: CHF 0 (kostenlos)
Publikation: CHF 0-100 (im SHAB)
```

**Dauer:**
```
Online-Antrag: 10 Minuten
Bearbeitung: 10-20 Arbeitstage
Eintrag aktiv: ~3-4 Wochen nach Antrag
```

---

## Step 3: STEUERNUMMER BEANTRAGEN

### Wann & Wo?

**Beim Kanton Basel-Landschaft (AStV = Amt für Steuern & Verrechnungen)**

- Website: https://www.baselland.ch/steuern
- Formular: "Anmeldung Steuerpflichtige natürliche Person"

### Was du brauchst

```
☐ Ausfülltes Formular (STeID-R)
☐ Kopie Personalausweis/Pass
☐ Kopie Gewerbezertifikat
☐ Geschäftsjahr: 01.01.-31.12.
☐ Geschäftsadresse
☐ Geschäftstätigkeit beschreiben
```

### Kosten & Dauer

```
Kosten: CHF 0 (kostenlos!)
Dauer: 10-20 Arbeitstage
Erhalt: Steuernummer per Post
Beispiel: 12-345.678
```

---

# 💰 TEIL 2: SCHWEIZER STEUERN (Einzelunternehmer)

## Welche Steuern zahlst du?

Als **Einzelunternehmer in der Schweiz** zahlst du:

### 1. EINKOMMENSTEUER (Bund + Kanton + Gemeinde)

**Du zahlst auf deinen Geschäftsgewinn:**

```
Beispiel: Dataquard Umsatz CHF 50'000, Gewinn CHF 35'000

Steuersätze Basel-Landschaft (Beispiel):
├─ Bundessteuer: ~10% = CHF 3'500
├─ Kantonalsteuer: ~8% = CHF 2'800
├─ Gemeindesteuer (Reinach): ~10% = CHF 3'500
└─ TOTAL Einkommensteuer: ~28% = CHF 9'800

GEWINN NACH STEUERN: CHF 35'000 - CHF 9'800 = CHF 25'200
```

**Wichtig:** Steuersätze sind PROGRESSIV!
- Je höher Gewinn, desto höher %
- Bei CHF 35'000 ca. 25-28%
- Bei CHF 100'000 ca. 30-35%

### 2. AHV/IV/EO BEITRÄGE (Sozialversicherung)

Du als **Selbstständiger** zahlst Rentenbeiträge selbst:

```
AHV/IV Beitragssatz: ~9.4% (du zahlst 100%, nicht 50/50 wie Angestellt!)

Beispiel: Gewinn CHF 35'000
├─ Mindestbeitrag: CHF 500/Jahr (absolut minimum)
├─ Normalbeitrag: ~CHF 3'290 (9.4% von Gewinn)
└─ Du zahlst: ~CHF 3'290

WICHTIG: Diese sind von Steuern ABZUGSFÄHIG!
Deklariere sie in Steuererklärung.
```

### 3. MEHRWERTSTEUER (VAT/MWST)

```
Schaut auf Jahresumsatz:

< CHF 85'000/Jahr: 
├─ Du bist OPTIONELL bei MWST
├─ Du BRAUCHST keine MWST einreichen
├─ Berechne CHF 149 OHNE MWST
└─ EMPFEHLUNG: Nicht anmelden (zu komplex)

> CHF 85'000/Jahr:
├─ Du MUSST MWST anmelden
├─ Du brauchst MWST-Nummmer
├─ Berechne CHF 149 + 8.1% MWST = ~CHF 161
└─ Du musst vierteljährlich abrechnen

REALITÄT JAHR 1: Du wirst < CHF 85'000 sein
→ Keine MWST-Registrierung nötig!
```

---

## Steuererklärung (WICHTIG!)

### Wann & Wo einreichen?

**Jährlich im März/April** beim Kanton Basel-Landschaft

- Deadline: ~31. Mai jedes Jahr (für Vorjahr)
- Formular: "Steuererklärung Einkommen & Vermögen"
- Online: https://edeklaration.baselland.ch/

### Was du deklarierst

```
EINNAHMEN:
├─ Geschäftseinkommen aus Dataquard
├─ Alle CHF 149 Zahlungen
└─ Pro Kunde: 1 × CHF 149

AUSGABEN (ABZUGSFÄHIG!):
├─ Domain & Hosting: CHF 200/Jahr
├─ Google Ads: CHF 5'000 (wenn gemacht)
├─ Anwalt-Honorar: CHF 3'500 (einmalig)
├─ AHV/IV Beiträge: ~CHF 3'290
├─ Büromaterial, Internet: CHF 100-200
├─ Fahrten (wenn mit Auto): ~CHF 400-500
└─ TOTAL AUSGABEN: ~CHF 12'000-13'000

GEWINN = EINNAHMEN - AUSGABEN
```

### Beispiel Steuererklärung (Jahr 1)

```
Annahme: 200 Kunden in 2026
Umsatz: 200 × CHF 149 = CHF 29'800

Ausgaben:
├─ Hosting & Domain: CHF 200
├─ Google Ads: CHF 5'000
├─ Anwalt-Validierung: CHF 3'500
├─ AHV/IV: CHF 3'200
├─ Diverses: CHF 500
└─ TOTAL: CHF 12'400

STEUERBARER GEWINN: CHF 29'800 - CHF 12'400 = CHF 17'400

STEUERN (25% Durchschnitt):
├─ Bund: CHF 1'740
├─ Kanton: CHF 1'391
├─ Gemeinde: CHF 1'740
└─ TOTAL: ~CHF 4'870

NETTO GEWINN NACH STEUERN: CHF 17'400 - CHF 4'870 = CHF 12'530

DEIN VERDIENST (Jahr 1): CHF 12'530 💰
```

**→ Trotzdem positiv und tax-efficient!**

---

## STEUERN SPAREN: GmbH vs Einzelunternehmer

### Vergleich bei CHF 35'000 Gewinn

```
EINZELUNTERNEHMER:
├─ Gewinn: CHF 35'000
├─ Steuern: ~CHF 9'800 (28%)
├─ NETTO: CHF 25'200

GmbH:
├─ Unternehmenssteuer: 8-10% = CHF 2'800-3'500
├─ Dein Gehalt: CHF 20'000 (als Angestellter)
├─ Deine Angestellten-Steuern: ~CHF 2'400
├─ Reinvest: CHF 9'000-12'000
├─ TOTAL STEUERN: ~CHF 5'200
├─ NETTO (für dich): CHF 20'000 + (CHF 9'000-12'000 Reinvest)
└─ NETTO: CHF 29'000-32'000+

ERSPARNIS MIT GmbH: CHF 4'000-6'000/Jahr! 💰
```

**→ GmbH wird interessant ab CHF 30'000+ Gewinn**

---

# ⚖️ TEIL 3: RECHTSFORMEN NACH SCHWEIZER RECHT

## Option 1: EINZELUNTERNEHMEN (Unternehmung ohne Rechtsperson)

### Was ist das?

**Du selbst = dein Geschäft**
- Keine separate juristische Person
- Du haftest persönlich
- Simple Struktur

### Gründung

```
Zeitaufwand: 30 Minuten
Kosten: CHF 0-50
Anforderungen:
├─ Gewerbeanmeldung (Kanton)
├─ Handelsregister-Eintrag (optional, empfohlen CHF 200-400)
└─ Steuernummer beantragen
```

### Haftung

```
❌ PROBLEM: Du haftest UNBEGRENZT mit Privatvermögen!

Beispiel:
├─ Ein Kunde klagt: "Eure Datenschutz-Texte waren falsch"
├─ Kosten: CHF 50'000
├─ Du zahlst privat: CHF 50'000
└─ Danach: Privatkonkurs möglich!

→ RISIKO für Dataquard (Vertrauen ist alles!)
```

### Steuern

```
Einkommensteuer: 25-30%
AHV/IV: 9.4% (du selbst)
MWST: Optional (ab CHF 85'000)
```

### Wann sinnvoll

```
✅ PERFEKT für:
├─ Start (Wochen 1-3)
├─ Minimales Risiko
├─ Einfache Buchhaltung
└─ Schneller Start

❌ NICHT EMPFOHLEN:
├─ Langfristig (haftungsrisiko)
├─ Ab CHF 30'000 Gewinn (Steuern teuer)
└─ Bei Kunden-Verträgen (Haftung!)
```

### WICHTIG FÜR DATAQUARD

Als Einzelunternehmer kannst du vertraglich haften für deine "anwaltlich validierten" Texte!

**→ GmbH wird ab Monat 4 NOTWENDIG, nicht optional!**

---

## Option 2: GESELLSCHAFT MIT BESCHRÄNKTER HAFTUNG (GmbH)

### Was ist das?

**Separate juristische Person** mit:
- Eigenes Vermögen (Stammkapital)
- Begrenzte Haftung
- Geschäftsführer (du)
- Gesellschafterversammlung (du)

### Gründung (DETAILLIERT nach CH-Recht)

#### Schritt 1: NOTARIELLE GRÜNDUNG

**Notariat Basel-Landschaft**
- Adresse: z.B. Notariat Reinach (lokales)
- Termin vereinbaren: ~1-2 Wochen

**Dokumentation:**
```
☐ Gründungsprotokoll (vom Notar vorbereitet)
☐ Satzung/Statuten (2 Seiten Standard)
☐ Gesellschafterliste (du bist 100% Gesellschafter)
☐ Geschäftsadresse festlegen
☐ Geschäftsführer ernennen (du selbst)
☐ Handschrift-Unterschrift leisten
☐ Notar beglaubigt
```

**Kosten:**
```
Notargebühren: CHF 1'000-1'500
├─ Gründungsprotokoll: CHF 600-800
├─ Satzung: CHF 200-300
├─ Beglaubigung: CHF 200-400
└─ TOTAL: CHF 1'000-1'500
```

#### Schritt 2: STAMMKAPITAL EINZAHLEN

**Mindestbetrag:** CHF 20'000 (gesetzliches Minimum!)

```
Du brauchst aber NICHT das ganze Geld haben!

Schweizer Recht erlaubt:
├─ CHF 20'000 = gesetzliche Mindest-Stammkapital
├─ Einzahlung: Mindest 50% = CHF 10'000 (musst einzahlen!)
├─ Einzahlung: Rest CHF 10'000 = später möglich
└─ Rest wird in "Gründungsprotokoll" festgehalten

PRAKTISCH:
├─ Du zahlst CHF 10'000 auf GmbH-Konto
├─ Bank verlangt: Bestätigung von Notar
├─ Nach Eintrag: Geld bleibt auf GmbH-Konto
└─ Du kannst damit Kosten zahlen (Anwalt, etc.)
```

**SZENARIO für Dataquard:**
```
Gründung Monat 4:
├─ Profit bisher: CHF 20'000
├─ Du zahlst CHF 10'000 in GmbH
├─ Rest CHF 10'000 auf Privatkonten
└─ GmbH ist gegründet ✅
```

#### Schritt 3: HANDELSREGISTER-EINTRAG

**Beim Handelsregisteramt Basel-Landschaft**

```
Unterlagen vom Notar:
├─ Gründungsprotokoll (beglaubigt)
├─ Satzung (beglaubigt)
├─ Nachweis Stammkapital-Zahlung
├─ Unterschriftsbeglaubigung Geschäftsführer
└─ HR-Anmeldeformular

Kosten:
├─ Handelsregister-Eintrag: CHF 300-500
└─ Publikation SHAB: CHF 100-200

Dauer: 10-20 Arbeitstage nach Antrag
```

#### Schritt 4: STEUERNUMMER & MWST

```
Nach HR-Eintrag:
├─ Kanton erkennt GmbH automatisch
├─ Steuernummer erhältst du per Post
├─ MWST-Anmeldung (optional, ab CHF 85'000)
└─ Kontobescheinigung für Bank
```

### TOTAL KOSTEN GmbH-GRÜNDUNG

```
Notar: CHF 1'000-1'500
Handelsregister: CHF 300-500
SHAB-Publikation: CHF 100-200
Bank-Kontoführung (1. Jahr extra): CHF 0-200

TOTAL: CHF 1'400-2'400

+ Stammkapital: CHF 10'000 (aber dein Vermögen!)

EINMALIG: CHF 1'400-2'400 (aus Tasche)
```

### Haftung mit GmbH

```
✅ PERFEKT: Nur GmbH haftet!

Beispiel:
├─ Klage: "Eure Texte waren falsch"
├─ Kosten: CHF 50'000
├─ GmbH zahlt (aus Stammkapital & Vermögen)
├─ Dein Privatvermögen: SICHER! 🔒
└─ Deine Lebensversicherung: SICHER! 🔒

→ DAS IST DER PUNKT!
```

### Steuern mit GmbH

```
GEWINN CHF 35'000:

Unternehmenssteuer (Bund + Kanton):
├─ Kantonal: ~8-10% = CHF 2'800-3'500
└─ Bund: Gibt es nicht für juristische Personen!

Dein Privatvermögen:
├─ Du zahlst dir Gehalt: CHF 20'000
├─ Steuern auf Gehalt: ~CHF 2'400
└─ NETTO Gehalt: CHF 17'600

GmbH-Reingewinn: CHF 35'000 - CHF 2'800 - CHF 20'000 = CHF 12'200
├─ Du kannst Bonus zahlen (gleiche Steuern wie Gehalt)
├─ Oder Reingewinn sparen (für Jahr 2 wachsen)
└─ Effektive Steuerquote: ~20-25%

ERSPARNIS vs Einzelunternehmer: CHF 3'000-5'000/Jahr!
```

### Jahresabschluss (WICHTIG!)

```
Jedes Jahr (bis 31. Dezember) musst du einreichen:

☐ Jahresbilanz (2 Seiten)
├─ Aktiva/Passiva
├─ Stammkapital CHF 20'000
└─ Reingewinn/Verlust

☐ Erfolgsrechnung (1 Seite)
├─ Umsatz
├─ Kosten
└─ Gewinn/Verlust

☐ Jahresbericht (optional für kleine GmbH)

Kosten Buchhaltung:
├─ DIY (kostenlos, aber arbeitend): CHF 0
├─ Mit Accountant: CHF 500-1'000/Jahr
└─ Mit Anwalt: CHF 1'000-2'000/Jahr

TIMING: Muss bis ~31. März folgendes Jahr eingereicht sein
```

### Vorteile GmbH

```
✅ Haftungsschutz (WICHTIG!)
✅ Steuern sparen (CHF 3'000-5'000/Jahr)
✅ Professioneller (Vertrauen der Kunden)
✅ Kredite einfacher zu bekommen
✅ Skalierbar (Mitarbeiter anstellen)
✅ Internationale Anerkennung
```

### Nachteile GmbH

```
❌ CHF 1'400-2'400 Gründungskosten
❌ Etwas mehr Buchhaltung
❌ Jahresbilanz erforderlich
❌ Notariat + Handelsregister
```

### WANN sinnvoll für Dataquard

```
NICHT sofort! (zu teuer am Anfang)

ABER ab Monat 4 wenn:
├─ Umsatz > CHF 3'000 (positive Gewinne)
├─ Haftungsrisiko evident (Verträge mit Kunden)
└─ Steuervorteil >= CHF 1'500/Jahr

EMPFEHLUNG: Ende Monat 3 / Anfang Monat 4 gründen
```

---

## Option 3: AKTIENGESELLSCHAFT (AG) – SPÄTER

### Wann?

```
Nur wenn:
├─ Umsatz > CHF 100'000/Jahr
├─ Gewinn > CHF 50'000/Jahr
└─ Internationale Expansion geplant
```

### Gründung

```
Kosten: CHF 3'000-4'000
Stammkapital: CHF 100'000 (mindest)
Notariat: Erforderlich
Jahresbilanz: Komplexer als GmbH
```

### Steuern

```
Unternehmenssteuer: 6-9% (besser als GmbH)
Sinnvoll ab CHF 100'000 Gewinn
```

### NICHT EMPFOHLEN für Dataquard Jahr 1-2

---

## 🎯 ZUSAMMENFASSUNG RECHTSFORMEN SCHWEIZ

| Merkmal | Einzelunternehmen | GmbH | AG |
|---------|------------------|------|-----|
| **Gründungskosten** | CHF 0-50 | CHF 1'400-2'400 | CHF 3'000-4'000 |
| **Haftung** | ❌ Unbegrenzt | ✅ Begrenzt | ✅ Begrenzt |
| **Steuern** | ~28-30% | ~18-22% | ~15-18% |
| **Jahresabschluss** | Einfach | Mittel | Komplex |
| **Wann sinnvoll** | Monat 1-3 | Monat 4-12 | Jahr 2+ |

---

# 🚀 TEIL 4: DATENSCHUTZGESETZ (DSG) COMPLIANCE

## Das neue DSG (gültig seit 1. Sept 2023)

**Für dich als Dataquard-Anbieter relevant:**

### Was musst DU tun?

```
☐ Datenschutzerklärung auf www.dataquard.ch
   ├─ Wer du bist (Name, Adresse, UID)
   ├─ Was du tust (Datenschutz-Generator)
   ├─ Welche Daten du sammelst (Email, Name, Firma)
   ├─ Wie lange du speicherst
   ├─ Wer hat Zugang
   └─ Datenschutz-Rechte der User

☐ Cookie-Banner (wenn Google Analytics nutzt)
   ├─ Muss Zustimmung einholen
   ├─ "Akzeptieren" & "Ablehnen" Button
   └─ Keine Cookies ohne Zustimmung

☐ Impressum (Imprint)
   ├─ Dein Name (Richard Rickli)
   ├─ Geschäftsadresse
   ├─ UID-Nummer (ab Handelsregister-Eintrag)
   ├─ Email & Telefon
   └─ Gültig ab Gewerbeanmeldung

☐ AGB (Allgemeine Geschäftsbedingungen)
   ├─ Was der Kunde bekommt (Generator + 1 Jahr Updates)
   ├─ Zahlungsbedingungen
   ├─ Rückgaberecht (30 Tage Geld-zurück!)
   ├─ Haftungsbeschränkung
   └─ Gültig ab Tag 1

☐ KEINE Datenschutzbeauftragte nötig
   └─ (Nur für größere Unternehmen ab 250 Mitarbeiter)
```

### Wichtige Punkte

```
1. TRANSPARENZPFLICHT (Art. 19 DSG)
   ├─ Du musst Kunden informieren:
   │  ├─ Name & Kontakt von dir
   │  ├─ Welche Daten du sammelst (Email, Name, etc.)
   │  ├─ Zweck (Verwaltung Kunden, Marketing)
   │  └─ Speicherdauer (1 Jahr, dann Löschung)
   └─ Muss auf Website sichtbar sein

2. RECHT AUF ZUGANG (Art. 22 DSG)
   ├─ Kunde kann fragen: "Welche Daten hast du über mich?"
   ├─ Du musst antworten innerhalb 30 Tagen
   ├─ Kostenlos!
   └─ Kannst ablehnen nur wenn berechtigter Grund

3. RECHT AUF LÖSCHUNG (Art. 24 DSG)
   ├─ Kunde kann sagen: "Lösch meine Daten"
   ├─ Du löschst innerhalb 30 Tagen
   ├─ Kostenlos!
   └─ Keine Rückfragen

4. KEINE DATEN-WEITERGABE (STANDARD)
   ├─ Du gibst Kundendaten NICHT weiter (Stripe ausgenommen)
   ├─ Stripe: Zahlungsdienstleister (nötig!)
   ├─ Google Analytics: MUSS Zustimmung einholen
   └─ Keine anderen Third Parties!

5. SICHERHEIT (Art. 7 DSG - "Privacy by Design")
   ├─ Du must technische Sicherheit gewährleisten:
   │  ├─ HTTPS/SSL (dein Hosting hat das)
   │  ├─ Regelmäßige Backups
   │  ├─ Sichere Passwörter
   │  └─ NO unverschlüsselte Übertragung
   └─ Ist ok mit Standard-Hosting!
```

### Datenschutz-Dokumentation

```
Du musst führen:
☐ Verarbeitungsverzeichnis (einfache Liste)
   ├─ Welche Daten: Name, Email, Firma, Webseite
   ├─ Speicherdauer: 1 Jahr nach letztem Kontakt
   ├─ Zweck: Verwaltung Kundenbeziehung
   └─ Speicherort: Hostpoint Server

☐ Sicherheitsmassnahmen-Dokumentation
   ├─ SSL-Verschlüsselung: JA (Hostpoint)
   ├─ Zugangsschutz: Passwort-geschützt
   ├─ Backup: Täglich (Hostpoint)
   └─ Mitarbeiterschulung: Nur du (als alleiniger Mitarbeiter)

ABER: Kleine Unternehmen (KMU) sind BEFREIT von komplexer Dokumentation!
→ Einfache Liste reicht für dich!
```

### Bußgelder (WICHTIG!)

```
Verstöße gegen DSG haben STRAFEN:

Mildere Verstöße (z.B. keine Transparenz):
├─ Verwarnungen
├─ Geldstrafen bis CHF 5'000
└─ Kanton wird informiert

Schwere Verstöße (z.B. Datenlecks):
├─ Geldstrafen bis CHF 250'000
├─ Strafverfahren
└─ Möglicher Freiheitsentzug (in extremen Fällen)

ABER: Für dein Business gering!
├─ Du sammelst nur Email & Name
├─ Keine sensiblen Daten
├─ Einfache Sicherheit reicht

→ Einfach Datenschutzerklärung + Transparenz = OK
```

---

# 💰 TEIL 5: KAPITALBUDGET NACH SCHWEIZER RECHT

## Kosten-Übersicht (CHF)

```
PHASE 1: EINZELUNTERNEHMER (Monat 1-3)

Gewerbeanmeldung:           CHF 0-50
Handelsregister (optional): CHF 200-400
Steuernummer:               CHF 0
Domain dataquard.ch:        CHF 15 (Jahr 1)
Hostpoint Hosting:          CHF 160 (Jahr 1)
Email Setup:                CHF 0 (in Hosting)
Stripe Account:             CHF 0
Anwalt-Validierung:         CHF 2'500-4'000 ← WICHTIG!
Google Ads (optional):      CHF 2'500-5'000
Design (optional):          CHF 100-300

TOTAL PHASE 1:              CHF 5'475-9'950

GmbH-Gründung (Monat 4):
├─ Notariat: CHF 1'000-1'500
├─ Handelsregister: CHF 300-500
├─ SHAB-Publikation: CHF 100-200
├─ Stammkapital: CHF 10'000 (dein Geld!)
└─ TOTAL: CHF 11'400-12'200
```

## Detailliertes Budget

### Szenario A: MINIMAL (kein Marketing)

```
Gewerbeanmeldung: CHF 50
Handelsregister: CHF 400
Steuernummer: CHF 0
Domain: CHF 15
Hosting: CHF 160
Anwalt: CHF 3'500
Google Ads: CHF 0
TOTAL PHASE 1: CHF 4'125

GmbH (ab Monat 4):
Notariat: CHF 1'200
HR-Eintrag: CHF 400
Stammkapital: CHF 10'000
TOTAL GmbH: CHF 11'600

GESAMTTOTAL: CHF 15'725
DAVON: CHF 10'000 ist Stammkapital (dein Geld bleibt)
ECHTE KOSTEN: CHF 5'725
```

### Szenario B: EMPFOHLEN (mit lite Marketing)

```
Phase 1 (Monat 1-3):
├─ Gewerbeanmeldung: CHF 50
├─ Handelsregister: CHF 400
├─ Domain & Hosting: CHF 175
├─ Anwalt: CHF 3'500
├─ Google Ads: CHF 2'000
└─ Design: CHF 200
TOTAL PHASE 1: CHF 6'325

Phase 2 (ab Monat 4):
├─ GmbH-Gründung: CHF 1'600
├─ Stammkapital: CHF 10'000
└─ Weiteres Marketing: CHF 1'000
TOTAL PHASE 2: CHF 12'600

GESAMTTOTAL: CHF 18'925
DAVON: CHF 10'000 Stammkapital
ECHTE KOSTEN: CHF 8'925
```

### Szenario C: OPTIMAL (aggressives Marketing)

```
Phase 1 (Monat 1-3):
├─ Basics: CHF 625
├─ Anwalt: CHF 4'000
├─ Google Ads: CHF 4'000
├─ LinkedIn Ads: CHF 1'500
├─ Content Creator: CHF 800
└─ Design (professionell): CHF 500
TOTAL: CHF 11'425

Phase 2 (ab Monat 4):
├─ GmbH-Gründung: CHF 1'600
├─ Stammkapital: CHF 10'000
├─ Weiteres Marketing: CHF 2'500
└─ Accounting Software: CHF 200
TOTAL: CHF 14'300

GESAMTTOTAL: CHF 25'725
DAVON: CHF 10'000 Stammkapital
ECHTE KOSTEN: CHF 15'725
```

---

# 📊 TEIL 6: FINANZIELLE PROGNOSE (SCHWEIZ)

## Einnahmen Jahr 1

```
Annahme: 200-300 Kunden in 2026
├─ à CHF 149 pro Kunde (NETTO, keine MWST)
├─ = CHF 29'800 - CHF 44'700
└─ Realistische Prognose: CHF 40'000
```

## Ausgaben Jahr 1 (Einzelunternehmer)

```
Hosting & Domain:      CHF 175
Anwalt (einmalig):     CHF 3'500
Google Ads:            CHF 5'000
AHV/IV Beiträge:       CHF 3'200 (9.4% Selbständiger)
Diverses (Material):   CHF 500
TOTAL AUSGABEN:        CHF 12'375

BRUTTOGEWINN: CHF 40'000 - CHF 12'375 = CHF 27'625
```

## Steuern Jahr 1 (Schweiz)

```
Steuerbarer Gewinn: CHF 27'625

Steuersätze (Basel-Landschaft):
├─ Einkommensteuer Bund: ~10% = CHF 2'763
├─ Kantonalsteuer: ~8% = CHF 2'210
├─ Gemeindesteuer (Reinach): ~9% = CHF 2'486
└─ TOTAL STEUERN: ~CHF 7'459 (27% eff.)

NETTOGEWINN: CHF 27'625 - CHF 7'459 = CHF 20'166
```

## Mit GmbH ab Monat 4

```
Annahme: 300 Kunden im Jahr, davon 200 Monat 1-4, 100 Monat 5-12
= CHF (200 × 149) + (100 × 149) = CHF 44'700
= CHF 44'700 - CHF 12'375 Ausgaben = CHF 32'325 Gewinn

ALS GmbH (ab Monat 4):
├─ Unternehmenssteuer (für GmbH): 9% = CHF 2'909
├─ Dein Gehalt (als Angestellter): CHF 22'000
├─ Deine Angestellten-Steuern: ~CHF 2'640
├─ Reingewinn in GmbH: CHF 32'325 - CHF 2'909 - CHF 22'000 = CHF 7'416
└─ TOTAL EFFEKTIVE STEUERN: ~CHF 5'549 (12-13% Satz!)

NETTO (für dich): CHF 22'000 + CHF 7'416 = CHF 29'416

ERSPARNIS vs Einzelunternehmer:
├─ Mit Einzelunternehmer: CHF 20'166 Netto
├─ Mit GmbH: CHF 29'416 Netto
└─ GEWINN: +CHF 9'250/Jahr mit GmbH! 💰

Das bezahlt sich bereits in 2 Jahren! (GmbH-Kosten CHF 1'600)
```

---

# 📋 TEIL 7: RECHTLICHE VERTRÄGE

## Was du brauchst (ALLE auf Deutsch):

### 1. AGB (Allgemeine Geschäftsbedingungen)

**Punkte, die rein müssen:**

```
1. LEISTUNGSBESCHREIBUNG
   ├─ Was bekommt Kunde? (Generator-Texte)
   ├─ Welche Formate? (HTML, PDF, Text)
   └─ Wie lange Zugang? (Für immer)

2. ZAHLUNG
   ├─ Preis: CHF 149 (NETTO)
   ├─ Zahlungsart: Kreditkarte, PayPal, Überweisung
   ├─ Zeitpunkt: Sofort nach Bestellung
   └─ Währung: CHF

3. RÜCKGABERECHT
   ├─ Frist: 30 Tage (Schweizer Standard)
   ├─ Bedingung: Geld-zurück, keine Fragen
   └─ Verjährung: Nach 30 Tagen verfallen

4. HAFTUNGSBESCHRÄNKUNG
   ├─ Du haftest NUR für direkte Schäden
   ├─ Maximalhaftung: CHF 149 (Kaufpreis)
   ├─ KEINE Haftung für Folgeschäden
   └─ Wichtig für Datenschutz-Versprechen!

5. GEWÄHRLEISTUNG
   ├─ Die Texte sind "best effort" validiert
   ├─ Keine Garantie auf 100% Rechtssicherheit
   ├─ Kunde sollte eigenen Anwalt konsultieren
   └─ Wichtig: "No legal advice"!

6. DATENSCHUTZ
   ├─ Link zur Datenschutzerklärung
   ├─ Beschreibung Datenverwarbitung
   └─ Datenschutzrechte (Zugang, Löschung)

7. ÄNDERUNGSVORBEHALT
   ├─ Du kannst AGB ändern
   ├─ Mit angemessener Vorlaufzeit (30 Tage)
   └─ Kunden können kündigen bei Nichtakzeptanz

8. SCHLUSSBESTIMMUNGEN
   ├─ Anwendbares Recht: Schweiz
   ├─ Gerichtsstand: Kanton Basel-Landschaft
   └─ Geltungsdauer: Unbegrenzt bis zur Beendigung
```

### 2. DATENSCHUTZERKLÄRUNG (DSGVO-konform + DSG)

```
INHALTE (Schweizer DSG Art. 19):

1. VERANTWORTLICHER
   Name: Richard Rickli / Dataquard GmbH (später)
   Adresse: Deine Adresse
   Email: support@dataquard.ch
   UID: XXX-XXX-XXX (später bei HR-Eintrag)

2. ERHOBENE DATEN
   ├─ Name
   ├─ Email
   ├─ Unternehmensname
   ├─ Website-Adresse
   ├─ IP-Adresse (Google Analytics)
   ├─ Browser-Info (Google Analytics)
   └─ Payment-Daten (Stripe)

3. RECHTSGRUNDLAGE
   ├─ Vertragserfüllung (Generierung Texte)
   ├─ Legitimes Interesse (Marketing)
   └─ Einwilligung (Analytics)

4. SPEICHERDAUER
   ├─ Kundendaten: 1 Jahr nach letztem Kontakt
   ├─ Payment-Daten: 7 Jahre (Steuer-Anforderungen)
   └─ Analytics: 14 Monate (Google Standard)

5. WEITERGABE DRITTE
   ├─ Stripe (Zahlungsverarbeiter)
   ├─ Google Analytics (nur mit Zustimmung)
   ├─ Hostpoint (Hosting-Provider)
   └─ KEINE andere Weitergabe!

6. DATENÜBERTRAGUNG (WICHTIG!)
   Deine Daten werden in der Schweiz gespeichert:
   ├─ Server: Hostpoint (Basel)
   ├─ Backups: Schweiz
   └─ Kein USA-Transfer!

7. KUNDENPFLICHT
   Kunde ist selbst verantwortlich für:
   ├─ Rechtmäßigkeit seiner Datenverwertung
   ├─ Angestellten-Einwilligungen
   ├─ Kunden-Einwilligungen
   └─ Datenschutz auf seiner Website!

8. IHRE RECHTE (DSG Art. 22-25)
   ├─ Recht auf Zugang (Art. 22)
   ├─ Recht auf Berichtigung (Art. 23)
   ├─ Recht auf Löschung (Art. 24)
   ├─ Recht auf Datenportabilität
   └─ Alle kostenlos!

9. KONTAKT DATENSCHUTZ
   Email: datenschutz@dataquard.ch
   Antwortzeit: Innerhalb 30 Tagen (DSG-konform)
```

### 3. IMPRESSUM (IMPRINT)

```
PFLICHTANGABEN (nach Schweizer E-Commerce-Recht):

Verantwortlich:
Richard Rickli
Hauptstrasse 123
4153 Reinach, Schweiz

Kontakt:
Email: richard@dataquard.ch
Telefon: +41 76 761 51 31

UID-Nummer: [Nach Handelsregister-Eintrag] CHE-XXX-XXX-XXX
Handelsregister: Kanton Basel-Landschaft, Eintrag Nr. XXXXX

Rechtliche Hinweise:
Diese Website unterliegt Schweizer Recht.
Gerichtsstand: Kanton Basel-Landschaft

Haftungsausschluss:
Wir bemühen uns um Richtigkeit der Inhalte, übernehmen aber keine Haftung.
Die Verwendung der Texte erfolgt auf eigene Verantwortung des Nutzers.

Datenschutz:
Siehe unsere Datenschutzerklärung (Link)

Streitbeilegung:
Verbraucher können sich an zuständige Behörde wenden.
Wir nehmen nicht an ADR-Verfahren teil.
```

---

# 🚀 TEIL 8: SCHRITT-FÜR-SCHRITT GRÜNDUNGS-ROADMAP SCHWEIZ

## WOCHE 1: REGISTRIERUNGEN

```
☐ Tag 1-2: Online Gewerbeanmeldung (Kanton BL)
   └─ https://www.baselland.ch
   └─ Kosten: CHF 0-50
   └─ Dauer: 10 Min
   └─ Bestätigung: Per Email

☐ Tag 3-5: Steuernummer beantragen
   └─ https://edeklaration.baselland.ch
   └─ Kosten: CHF 0
   └─ Dauer: 10 Min
   └─ Eintrag: 1-2 Wochen

☐ Tag 5-7: Handelsregister-Anmeldung (optional, aber empfohlen)
   └─ https://www.shab.ch
   └─ Kosten: CHF 200-400
   └─ Dauer: Antrag 1 Stunde, Bearbeitung 2-3 Wochen
```

## WOCHE 2: WEBSITE & BANK

```
☐ Tag 8-10: Domain + Hosting kaufen
   └─ Hostpoint.ch
   └─ Kosten: CHF 200
   └─ Dauer: 10 Min
   └─ Live: Sofort

☐ Tag 10-14: Business-Bankkonto eröffnen
   └─ Postfinance, UBS, oder Kantonalbank
   └─ Kosten: CHF 0-50/Jahr
   └─ Unterlagen: Ausweiskopie + Gewerbeanmeldung
   └─ Dauer: 1-2 Wochen

☐ Tag 12-14: AGB & Datenschutzerklärung schreiben
   └─ Nutze Templates (Online verfügbar)
   └─ Kosten: CHF 0 (oder CHF 100-200 für Anwalt-Check)
   └─ Auf Website hochladen
```

## WOCHE 3-4: ANWALT & VALIDIERUNG

```
☐ Tag 15-18: Email an Anwalt schreiben (Daniela Fábián)
   └─ privacylegal.ch
   └─ Validierungs-Request senden
   └─ Kosten: CHF 2'500-4'000
   └─ Dauer bis Offerte: 2-3 Tage

☐ Tag 20-25: Offerte verhandeln & akzeptieren
   └─ Versuche auf CHF 2'500 zu drücken
   └─ Zahlungstermin: Bei Abrechnung

☐ Tag 25-28: Anwalt beginnt mit Validierung
   └─ Dauer: 2-4 Wochen
   └─ Du machst weiter mit Website/Marketing
```

## MONAT 2: MARKETING & KUNDEN

```
☐ Woche 5-6: Google Ads vorbereiten
   └─ Google Ads Account erstellen
   └─ Kampagnen aufsetzen
   └─ Budget: CHF 30-40/Tag (monatlich)

☐ Woche 6-8: Website live gehen & Anmelden
   └─ Auf Suchmaschinen anmelden
   └─ Google Search Console
   └─ Google Analytics

☐ Woche 7-8: Erste Kunden organisch gewinnen
   └─ Ohne Marketing oft 3-5 Kunden im Monat
   └─ Durch Netzwerk & Mund-zu-Mund
   └─ Breakeven: ~CHF 3'500 = 23 Kunden
```

## MONAT 3: VALIDIERUNG ABSCHLUSS

```
☐ Woche 9-12: Anwalt-Validierung erhalten
   └─ Landing Page updaten
   └─ "Anwaltlich validiert ✓" hinzufügen
   └─ Marketing intensivieren

☐ Woche 12: Google Ads starten
   └─ Budget: CHF 1'000/Monat
   └─ ROI sollte 3:1 sein
   └─ 20-30 Kunden/Monat
```

## MONAT 4: GmbH GRÜNDUNG

```
☐ Woche 13-14: Notariat-Termin buchen
   └─ Lokales Notariat Reinach/Basel-Landschaft
   └─ Kosten: CHF 1'000-1'500
   └─ Dauer Termin: 1-2 Stunden

☐ Woche 14-15: Stammkapital einzahlen
   └─ CHF 10'000 auf Geschäftskonto
   └─ Nachweis vom Notariat erhalten

☐ Woche 15-16: Handelsregister eintrag
   └─ Mit beglaubigten Dokumenten einreichen
   └─ Kosten: CHF 300-500
   └─ Dauer: 10-20 Arbeitstage

☐ Woche 16-20: Neue Steuernummer erhalten
   └─ Von Kanton automatisch
   └─ Bank-Eintrag update

☐ Woche 18-20: Business-Name ändern
   └─ Website update: "Dataquard GmbH"
   └─ Emails update
   └─ Verträge anpassen
```

---

# 💰 ZUSAMMENFASSUNG KAPITAL & STEUERN SCHWEIZ

## WAS DU ZAHLST

### Jahr 1 als Einzelunternehmer:

```
EINNAHMEN: CHF 40'000 (ca. 270 Kunden)

AUSGABEN (ABZUGSFÄHIG):
├─ Hosting: CHF 175
├─ Anwalt: CHF 3'500
├─ Google Ads: CHF 5'000
├─ AHV/IV: CHF 3'200
├─ Material: CHF 500
└─ TOTAL: CHF 12'375

STEUERBARER GEWINN: CHF 27'625

STEUERN (~27% in Basel-Landschaft):
├─ Bund: CHF 2'763
├─ Kanton: CHF 2'210
├─ Gemeinde: CHF 2'486
└─ TOTAL: CHF 7'459

NETTO GEWINN: CHF 20'166 💰

DANACH (ab Monat 4 mit GmbH):
├─ Effektive Steuerquote: ~12-13%
├─ NETTO: CHF 29'416 (statt CHF 20'166)
└─ ERSPARNIS: +CHF 9'250/Jahr!
```

## WICHTIGE SCHWEIZER STEUERTERMINS

```
Frühling (März-Mai):
├─ Steuererklärung einreichen (für 2025)
├─ Deadline: ~31. Mai 2025
├─ Unterlagen: Alle Rechnungen

Sommer (Juni-Juli):
├─ Steuerbescheid erhalten
├─ Zahlungsfrist: ~60 Tage
├─ Nachzahlungen möglich

Herbst (Sept-Okt):
├─ GmbH-Jahresbilanz einreichen (später)
├─ Deadline: ~31. Dezember (für Vorjahr)
└─ Finanzamt kontrolliert

Winter (Dez-Jan):
├─ Budget für nächstes Jahr planen
├─ Vorausrechnungen einzahlen (ab Jahr 2)
└─ Bilanz-Vorbereitungen
```

---

# ⚖️ TEIL 9: WEITERE SCHWEIZER RECHTLICHE ANFORDERUNGEN

## Arbeitsrecht (wenn du Mitarbeiter anstellst - SPÄTER!)

```
Nicht relevant im Jahr 1, ABER wichtig für später:

Bei Mitarbeiter-Anstellung:
├─ Arbeitsvertrag (schriftlich!)
├─ AHV-Anmeldung (für Mitarbeiter)
├─ Unfallversicherung (SUVA)
├─ Berufsunfallversicherung (obligatorisch)
├─ Arbeitslosenversicherung (ALV)
├─ Mindestlohn Schweiz: Ab CHF 3'200/Monat empfohlen
└─ 4-Wochen Kündigungsfrist (Minimum)

KOSTEN (ab 1 Mitarbeiter):
├─ Lohnbuchhaltung: CHF 50-100/Monat
├─ SUVA-Versicherung: ~1-2% Lohnsumme
├─ ALV-Beiträge: ~1.1% Lohnsumme
└─ TOTAL: ~CHF 150-200/Monat + Lohn
```

## Versicherungen (WICHTIG!)

```
NICHT ZWINGEND, aber EMPFOHLEN:

1. Haftpflicht-Versicherung (CHF 200-400/Jahr)
   ├─ Schützt dich bei Klagen
   ├─ "Deine Texte waren falsch"
   ├─ Wichtig mit anwaltlicher Validierung
   └─ Deckungssumme: CHF 100'000-500'000

2. Berufsunfähigkeits-Versicherung (BUV, CHF 100-300/Jahr)
   ├─ Wenn du 6+ Monate ausfällst
   ├─ Zahlt dein Gehalt weiter
   └─ WICHTIG für Einzelunternehmer!

3. Altersvorsorge (Säule 3a, freiwillig)
   ├─ Pensionskasse musst du selbst besparen
   ├─ Max CHF 7'056/Jahr (2024) abzugsföhig
   ├─ Empfohlen: Sparplan mit Bank
   └─ Für Altersvorsorge

TOTAL VERSICHERUNGEN: CHF 300-700/Jahr
```

## Obligationenrecht (Verträge)

```
Deine Verträge (AGB, Datenschutz) müssen nach OR sein:

Art. 2 OR: Verträge sind Zustimmung (Angebot + Annahme)
├─ Dein Angebot: "Generator für CHF 149"
├─ Kunden-Annahme: Kauf durchführen
└─ = Vertrag zustande gekommen!

Art. 8 OR: Schriftform (nicht immer notwendig)
├─ Online-Vertrag: Via Klick = gültig
├─ AGB: Vor Kauf verfügbar machen
└─ Email-Bestätigung: Gutes Beweise-Mittel

Art. 101-102 OR: Rückgaberecht
├─ Du KANNST 30 Tage Rückgabe anbieten (du)
├─ Nicht gesetzlich verpflichtet (aber gut für Vertrauen)
└─ Nutze Stripe's Dispute-System

Art. 107 ff OR: Gewährleistung
├─ Du garantierst "wie beschrieben"
├─ Aber NICHT perfekt oder "100% rechtssicher"
└─ Haftungsausschluss in AGB wichtig!
```

## Konsumentenschutz

```
Das "Konsumentengesetz" gibt es in der Schweiz NICHT als gesondertes Gesetz!

ABER: OR gelten auch für Konsumenten
├─ Preiswahrheit (CHF 149 = CHF 149)
├─ Keine versteckten Gebühren
├─ Keine Behauptungen die du nicht hältst
└─ "Anwaltlich validiert" = Muss wahr sein!

WICHTIG: Unwahre Aussagen können zu:
├─ Bußgeldern führen (CHF 5'000-10'000)
├─ UWG-Verstößen (Unlauterer Wettbewerb)
└─ Reputationsverlust

DEINE SICHERHEIT:
├─ Du lässt validieren = wahr!
├─ Du speicherst Validierungs-Zertifikat
├─ Du kannst es bei Dispute vorzeigen
└─ → KEIN PROBLEM!
```

---

# 🎯 FINALE CHECKLISTE SCHWEIZER RECHTSKONFORMITÄT

## VOR START (Woche 1)

- [ ] Gewerbeanmeldung online (Kanton BL)
- [ ] Steuernummer beantragen
- [ ] Handelsregister-Eintrag planen (optional)
- [ ] Privat-Bankkonto zu Business-Konto machen

## WEBSITE & VERTRÄGE (Woche 2-3)

- [ ] Domain + Hosting kaufen (Hostpoint)
- [ ] AGB schreiben (nach OR)
- [ ] Datenschutzerklärung (nach DSG Art. 19)
- [ ] Impressum (mit allen erforderlichen Daten)
- [ ] Rückgaberecht (30 Tage empfohlen)

## ANWALT & COMPLIANCE (Woche 3-8)

- [ ] Anwalt kontaktieren für Validierung
- [ ] Vertrag mit Anwalt (Preis + Timeline)
- [ ] Texte zur Validierung übermitteln
- [ ] Validierungs-Zertifikat erhalten & speichern
- [ ] "Anwaltlich validiert" auf Website hinzufügen

## ZAHLUNGEN & BUCHHALTUNG (Monat 1-2)

- [ ] Stripe/PayPal einrichten
- [ ] Erste Zahlungen testen
- [ ] Einfaches Buchhaltungs-Sheet (Excel ok!)
- [ ] Alle Rechnungen speichern

## GmbH-GRÜNDUNG (Monat 4)

- [ ] Notartermin vereinbaren
- [ ] Gründungsdokumente vorbereiten
- [ ] Stammkapital CHF 10'000 einzahlen
- [ ] Handelsregister-Eintrag (mit beglaubigten Dokumenten)
- [ ] Website & Verträge updaten (Name!)
- [ ] Neue Steuernummer erhalten

## STEUERN & ABRECHNUNG (Jährlich)

- [ ] Steuererklärung einreichen (bis Mai)
- [ ] Alle Belege sammeln & speichern
- [ ] Jahresbilanz (GmbH ab Jahr 2)
- [ ] Steuerzahlungen leisten

---

# 🚀 FINAL SUMMARY - DEIN START IN SCHWEIZER RECHT

```
RECHTSFORM TIMELINE:

Monat 1-3: EINZELUNTERNEHMER
├─ Kosten: CHF 0-50 (Gewerbeanmeldung)
├─ Gewerbezertifikat erhalten
├─ Steuernummer erhalten
├─ HR-Eintrag (optional): CHF 200-400
└─ LEGAL & EINFACH!

Monat 4: GmbH GRÜNDUNG
├─ Kosten: CHF 1'400-2'400
├─ Stammkapital: CHF 10'000
├─ Notariat + HR-Eintrag
├─ Neuer Name: "Dataquard GmbH"
└─ HAFTUNGSSCHUTZ ✓

STEUER-EFFIZIENZ:
├─ Einzelunternehmer: ~27% Steuern
├─ GmbH: ~12-13% Steuern
├─ ERSPARNIS: +CHF 9'000-10'000/Jahr! 💰
└─ Payback: GmbH zahlt sich nach 2 Jahren aus!

ANFANGSKAPITAL:
├─ Minimal: CHF 3'500 (nur Anwalt + Basics)
├─ Empfohlen: CHF 6'000-8'000 (mit leichtem Marketing)
├─ Optimal: CHF 12'000-15'000 (mit gutem Marketing)
└─ Davon CHF 10'000 = Stammkapital (bleibt dein Geld!)

FINANZIELLE PROGNOSE:
├─ Jahr 1 (Einzelunternehmer): CHF 20'166 Netto
├─ Jahr 1-2 (mit GmbH ab Monat 4): CHF 25'000-30'000 Netto
├─ Jahr 2 (GmbH): CHF 135'000-235'000 Gewinn
├─ Jahr 3+: CHF 450'000-950'000+ Umsatz
└─ ROI JAHR 1: +300-500%!

RECHTLICHE COMPLIANCE:
✓ Datenschutzerklärung (DSG Art. 19)
✓ AGB (Obligationenrecht)
✓ Impressum (mit allen Daten)
✓ Anwalt-Validierung (für Vertrauen)
✓ Buchhaltung (einfaches System)
✓ Steuererklärung (jährlich)

ALLES NACH SCHWEIZER RECHT! 🇨🇭
```

---

**DU BIST JETZT 100% SCHWEIZER-RECHTS-KONFORM BEREIT!**

Folge die Roadmap, halte dich an die Checkliste, und du hast:
- ✅ Legales Business
- ✅ Steuereffizient geplant
- ✅ Richtige Rechtsform zum richtigen Zeitpunkt
- ✅ Haftungsschutz (ab Monat 4)
- ✅ Vertrauen durch Validierung

**LOS GEHT'S!** 🚀🇨🇭
