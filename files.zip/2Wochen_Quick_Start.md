# 2-Wochen Quick-Start: CHF 3'000.– verdienen

## Die einfachste Idee: "Business Plan Schnell-Check"

### Das Konzept (Punkt!)
Gründer schreiben dir kurz ihre Geschäftsidee (200–300 Wörter) per Email/Formular.
Du nutzt Claude Cowork, um in 4–6 Stunden einen "Business Plan Schnell-Check" zu machen.
Du schreibst eine 3–5 seitige PDF zurück mit:
- Geschäftsidee zusammengefasst
- 3 Stärken
- 3 kritische Fragen
- 5 nächste Schritte
- Finanzierungsbedarf (grobe Schätzung)

**Preis: CHF 199.– pro Check**
**Ziel: 15–20 Kunden in 2 Wochen = CHF 2'985–3'980.–**

---

## Warum das funktioniert:

✓ **Null Investition** – Nur deine Zeit
✓ **Schnell** – Du brauchst nur 4–6 Stunden pro Plan
✓ **Keine Rechtsprobleme** – Du gibst "Feedback", nicht "Beratung"
✓ **Sofort Einnahmen** – Geld kommt nach 2 Wochen rein
✓ **Skalierbar** – Wenn's läuft, machst du mehr

---

## Konkrete 2-Wochen-Anleitung

### **TAG 1–2: Setup (2 Stunden)**

**1. Simple Website/Landingpage** (30 Minuten)
   - Google Sites oder Wix kostenlos nutzen
   - Titel: "Business Plan Schnell-Check"
   - 3 Sätze Beschreibung
   - CHF 199.– Button (zu Stripe/PayPal)
   - Email-Formular (Google Forms)

**2. Zahlungsgateway** (30 Minuten)
   - Stripe Account eröffnen (kostenlos, 2.9% Gebühr)
   - "Jetzt kaufen"-Button auf der Website

**3. Email-Vorlage schreiben** (1 Stunde)
   - Danke-Email (automat.)
   - "Bitte erzähle mir deine Geschäftsidee in 200 Wörter"
   - Deadline: "Check in 3 Tagen"

### **TAG 3–14: Marketing & Verkaufen (90 Minuten/Tag)**

**LinkedIn-Strategie (15 Minuten/Tag):**
- Poste jeden Morgen ein Startup-Tipps-Post
- Kommentiere auf Posts von Gründern
- DM schreiben: "Brauchst du Feedback zu deiner Geschäftsidee?"
- Link zu deiner Website in Bio

**Beispiel-Post:**
> "🚀 Gründer-Tipp: Deine Geschäftsidee braucht Struktur. 
> Wer kann dir sagen, ob es funktioniert?
> Ich mache einen 'Business Plan Schnell-Check' für CHF 199.–
> Link in Bio"

**Email an 30 Personen (30 Minuten/Tag):**
- Gründerzentren (BaselArea, Startup Bootcamp)
- Coworking Spaces in Basel
- Freunde & Bekannte mit Startup-Ambitionen
- Betreff: "Hilfst du mir? Ich teste einen neuen Service..."

**Pro Tag:** 15 min LinkedIn + 30 min Emails = 45 Minuten

**Pro Woche:** 7 × 45 = ~5 Stunden Marketing

### **Praktisches Beispiel (So funktioniert es):**

**Der Kunde schreibt:**
> "Ich will einen Online-Shop für handgemachte Ledergürtel starten. Ich habe 20'000 CHF Startkapital und 2 Jahre Erfahrung. Ich kenne 100 potenzielle Kunden."

**Du machst in 4–6 Stunden:**
1. Claude Cowork laufen lassen → Input analysieren
2. 5-seitige PDF schreiben mit:
   - Kurze Zusammenfassung
   - "Deine 3 Stärken: (1) Klare Kundenbasis, (2) Realistische Finanzierung, (3) Handwerk-Expertise"
   - "3 kritische Fragen: (1) Wie differenzierst du von Konkurrenz? (2) Wie hoch ist deine Gewinnmarge? (3) Wie skalierst du?"
   - "5 nächste Schritte: (1) Website bauen, (2) First Sales testen, (3) Google Ads Setup, (4) Lieferanten sichern, (5) Monatlicher Kassensturz"
   - "Geschätzter Kapitalbedarf: CHF 8'000 für Website + Marketing + Lagerbestand"

**Kunde ist happy:** Konkrete, ehrliche, nutzbare Antworten in 3 Tagen für CHF 199.–

---

## Zahlenspiel (Realistisch)

### Szenario: 15 Kunden in 2 Wochen

| Tag | Aktion | Neue Anfragen |
|-----|--------|--------------|
| 3 | LinkedIn starts | 1–2 |
| 5 | Email an 30 Personen | 3–4 |
| 7 | Erste Plans fertig, Mund-zu-Mund | 2–3 |
| 10 | LinkedIn-Momentum | 3–4 |
| 14 | Abschluss | 2–3 |
| **TOTAL** | | **15 Kunden** |

**Umsatz:** 15 × CHF 199.– = **CHF 2'985.–**
**Netto nach Stripe-Gebühren (2.9%):** CHF 2'898.–

---

## Die Claude Cowork Workflow (Pro Plan 4–6 Stunden)

```
Kunde schickt Geschäftsidee (200 Wörter)
         ↓
Claude Cowork analysieren:
  - Ist die Idee realistisch?
  - Finanzierungsbedarf schätzen
  - Konkurrenzumfeld prüfen
  - Risiken identifizieren
         ↓
Du schreibst 5-seitige PDF:
  - Executive Summary (1 Seite)
  - Stärken & Chancen (1 Seite)
  - Kritische Fragen & Risiken (1 Seite)
  - Roadmap / Nächste Schritte (1 Seite)
  - Finanzierungsübersicht (1 Seite)
         ↓
PDF an Kunde senden + Email mit persönlichem Feedback
         ↓
Fertig → Nächster Plan
```

---

## Was du konkret JETZT machen musst:

### **Diese Woche (Tag 1–7):**

- [ ] **Montag:** 
  - Google Sites Website erstellen (30 min)
  - Stripe Account eröffnen (30 min)
  - Erste Email-Vorlage schreiben (30 min)

- [ ] **Dienstag:**
  - LinkedIn-Profil optimieren + erste Posts (30 min)
  - Email an 30 Personen schreiben (60 min)

- [ ] **Mittwoch–Freitag:**
  - Täglich LinkedIn-Posts (15 min)
  - Täglich Emails schreiben (30 min)
  - Erste Anfragen bearbeiten (wenn kommen)

- [ ] **Wochenende:**
  - Erste Plans fertigstellen (4–6 Stunden)
  - Feedback von Kunden einholen

### **Nächste Woche (Tag 8–14):**
- [ ] Täglich Marketing (45 min)
- [ ] Plans fertigstellen (20–30 Stunden)
- [ ] Mund-zu-Mund nutzen ("Sag deinen Freunden!")

---

## Kurz-Checkliste (Drucken & abhaken!)

### Website (Tag 1)
- [ ] Google Sites oder Wix Account
- [ ] Domain (z.B. businessplanquick.ch oder businessplancheck.ch)
- [ ] Title: "Business Plan Schnell-Check – CHF 199.–"
- [ ] Stripe "Jetzt kaufen"-Button
- [ ] Google Forms Formular für Kundeninfo

### Marketing-Material (Tag 2)
- [ ] LinkedIn-Posts (3–5 Entwürfe)
- [ ] Email-Template (Danke, Bitte um Infos, Versand)
- [ ] Email-Liste mit 30 Kontakten

### Operations (Tag 3–14)
- [ ] Claude Cowork Workflow testen (1. Plan)
- [ ] PDF-Template (wie sieht der Plan aus?)
- [ ] Feedback-Prozess (wie fragen Kunden nach Änderungen?)
- [ ] Zahlungen tracken (Spreadsheet)

---

## Häufige Fragen:

**F: Ist das legal?**
Ja. Du gibst "Feedback" und "Analyse", nicht "Beratung". In der AGB: "Dies ist ein Schnell-Check, keine professionelle Beratung. Konsultiere einen Berater für komplexe Fragen."

**F: Wie viel Zeit pro Plan?**
4–6 Stunden (1–2 Stunden Claude Cowork laufen lassen, 3–4 Stunden schreiben & formatieren)

**F: Was wenn Kunden Änderungen wollen?**
"1 Überarbeitung inklusive, weitere CHF 50.– pro Revision"

**F: Wie viel Marketing brauchst du?**
30–45 Minuten/Tag reicht (LinkedIn + 5 Emails)

**F: Wann kommt das erste Geld?**
Tag 5–7 (erste Anfragen), Tag 10–14 (erste Plans fertig, Zahlungen rein)

---

## Der Realcheck:

**Optimistisch:** 20 Kunden × CHF 199.– = CHF 3'980.–
**Realistisch:** 15 Kunden × CHF 199.– = CHF 2'985.–
**Pessimistisch:** 10 Kunden × CHF 199.– = CHF 1'990.–

**Deine Zeit:** ~40–50 Stunden in 2 Wochen
**Stundenlohn:** CHF 50–75/Stunde (nicht schlecht für Start!)

---

## Nach den ersten 2 Wochen:

Wenn's funktioniert:
- ✓ Weitermachen, Plan auf CHF 299.– erhöhen
- ✓ Premium-Option hinzufügen (CHF 499.–, mit Call)
- ✓ Gründerzentren als Partner
- ✓ Eventuell einen Assistenten einstellen

Wenn's nicht funktioniert:
- ✗ Nichts verloren (war kostenlos)
- ✗ Du hast gelernt, was Gründer brauchen
- ✗ Nächste Idee: SchreiberAssistent oder PresentationMaker

---

**TL;DR:**
- Website (2h) + Marketing (5h/Woche) + 20 Plans à 4–6h = CHF 3'000.– in 2 Wochen
- Null Investition, maximale Flexibilität
- Anfangen: JETZT (wirklich, heute noch!)
