# KI-JOBFINDER REPORT
## Richard Rickli – 3 Neue Karrieren

**Profil:** Operativer Manager/Standortleiter, 55 Jahre, Basel-Landschaft  
**Aktuelle Situation:** Stelle bei HANAG Steriltechnik endet Dezember 2025  
**Stärken:** 30+ Jahre Führungserfahrung, Prozessoptimierung, Team-Entwicklung, hohe Sozialkompetenz

---

## OPTION 1: Operations Consultant für Mittelständische Unternehmen

**Branche:** Beratung / Interim Management  
**Gehalt:** CHF 120'000–150'000/Jahr (oder CHF 180–250/Stunde als Consultant)  
**Modell:** Festanstellung bei Beratungsfirma ODER unabhängiger Consultant

### Warum Richard perfekt passt:
Du hast genau das, was KMU brauchen: Praktische Operations-Erfahrung, nicht nur Theorie. Du kannst in 3–6 Monaten einen Produktionsbetrieb strukturieren, Teams aufbauen, Prozesse optimieren. Das ist deine Kernkompetenz der letzten 20 Jahre. Mittelständler zahlen CHF 100'000–200'000 für genau diese Expertise.

### Warum KI das NICHT ersetzen kann:
KI kann Prozesse analysieren, aber KI kann nicht mit Fabrikarbeitern reden, nicht Widerstände überwinden, nicht Vertrauen aufbauen. Du brauchst 3–6 Monate VOR ORT, um wirklich zu verstehen, was läuft. Das ist menschliches Handwerk, nicht automatisierbar.

### 4 Konkrete Nächste Schritte:
1. **LinkedIn-Profil updaten:** Titel: "Operations & Process Improvement Consultant" – schreibe ein paar Posts über deine Erfolge (20% Durchsatz-Verbesserung, Neustrukturierung usw.)
2. **Mit 3–5 lokalen Beratungsfirmen sprechen:** Kontaktiere Axxiom (Basel), BDO, Kpmg, oder kleinere Shops wie "Operativer Manager Basel" – sag: "Ich bin ab Januar verfügbar und habe 30 Jahre Produktions-Know-how"
3. **Interim Management Plattform:** Meld dich an bei Interimmanager.ch oder Pedeus.ch – dort suchen KMU gezielt nach Leuten wie dir
4. **Erste bezahlte Konsultation:** Suche dir 1–2 KMU in der Region, anbiete 2–3 Tage gratis "Operations-Audit" → dann CHF 5'000–10'000 für Umsetzungsplan

**Kontaktiere JETZT:**
- Axxiom (Basel): https://axxiom.ch
- BDO Schweiz: https://www.bdo.ch
- Interimmanager.ch: https://www.interimmanager.ch

---

## OPTION 2: Changemanagement Coach / Transformations-Lead für Sozialunternehmen

**Branche:** NGOs, Sozialunternehmen, öffentliche Institutionen  
**Gehalt:** CHF 110'000–140'000/Jahr  
**Typische Arbeitgeber:** GAW, Stiftungen, Behindertenverbände, Altersheime, Spitäler

### Warum Richard perfekt passt:
Du hast bei GAW 6 Jahre lang mit 33 Menschen gearbeitet – viele davon mit Behinderungen, Integrationsbedarf. Du hast sie entwickelt, strukturiert, Vertrauen aufgebaut. Deine MENSCHLICHE Kompetenz ist deine Superkraft. Sozialunternehmen brauchen genau das: Führungspersonen, die Menschen sehen, nicht nur Nummern. Und deine Operations-Skills? Sozialunternehmen sind chronisch ineffizient – sie zahlen SEHR GUT dafür, wenn jemand Struktur bringt.

### Warum KI das NICHT ersetzen kann:
Soziale Arbeit ist reine Beziehung. KI kann nicht mit traumatisierten Menschen arbeiten, nicht Vertrauen aufbauen, nicht Lösungen finden, die mit menschlicher Würde vereinbar sind. Sozialunternehmen brauchen emotionale Intelligenz, nicht Algorithmen.

### 4 Konkrete Nächste Schritte:
1. **Dein LinkedIn-Profil neu schreiben:** Betone deine GAW-Erfahrung, Teamförderung, Change Management. Post: "Nach 6 Jahren GAW: Wie man 33 Menschen entwickelt und Struktur schafft"
2. **Kontaktiere 5 lokale Sozialunternehmen direkt:**
   - GAW selbst (dein früherer Arbeitgeber – vielleicht andere Abteilung)
   - Stiftung Arkade Basel
   - Wohnwerk Basel
   - Voja (Verband Offene Jugendarbeit)
   - Pro Infirmis Basel
3. **Trag dich ein bei:** https://sozialcareerjobs.ch (Schweizer Job-Plattform für Sozialsektor)
4. **Zertifizierung erwägen:** "systemisches Coaching" (online, 6 Monate, CHF 3'000) – macht dich für Sozialunternehmen noch attraktiver

**Kontaktiere JETZT:**
- GAW (dein früherer Arbeitgeber): https://gaw-basel.ch
- Stiftung Arkade: https://www.arkade.ch
- Pro Infirmis: https://www.proinfirmis.ch

---

## OPTION 3: Supply Chain Manager / Procurement Lead für Pharma/Medtech

**Branche:** Pharma, Medtech, Chemie (Basel ist Hub!)  
**Gehalt:** CHF 130'000–170'000/Jahr  
**Typische Arbeitgeber:** Roche, Novartis, Biotech-KMU, Lieferanten-Management

### Warum Richard perfekt passt:
Du hast 20 Jahre Einkauf, Lieferantenmanagement, Materialwirtschaft. Basel ist PHARMA-HUB – hier haben hunderte Unternehmen Supply Chain Probleme. Deine Erfahrung bei HANAG (Pharma-Maschinenhersteller) ist GOLD. Du kennst die Anforderungen, die internationalen Standards, die Lieferant-Komplexität. Pharma zahlt sehr gut dafür.

### Warum KI das NICHT ersetzen kann:
KI kann Lieferketten-Daten analysieren, aber KI kann nicht mit Lieferanten verhandeln, nicht Beziehungen aufbauen, nicht Notfall-Lösungen finden, wenn ein Lieferant ausfällt. Du kannst mit einem Anruf 5 Lieferanten mobilisieren. KI kann das nicht.

### 4 Konkrete Nächste Schritte:
1. **LinkedIn-Profil schärfen:** Highlight: "30 Jahre Supply Chain & Procurement" – poste über deine HANAG-Erfahrung mit Pharma-Lieferanten
2. **Kontaktiere direkt 5 Pharma/Medtech-Unternehmen:**
   - Roche Career Portal: https://careers.roche.com
   - Novartis Jobs: https://www.novartis.com/careers
   - Basler Biotech-KMU: Grifols, Bachem, Lonza
   - LinkedIn Search: "Supply Chain Manager Basel" + Direct Message
3. **Recruiter-Agenturen:** Kontaktiere Heidrick & Struggles oder Michael Page (specialisieren sich auf Pharma-Positionen)
4. **Temporär starten:** Melde dich bei "Lemonade Jobs" oder "Randstad" an für 3-6 Monate Interim Supply Chain – danach Festanstellung

**Kontaktiere JETZT:**
- Roche Careers: https://careers.roche.com (Search: Basel)
- Novartis: https://www.novartis.com/careers
- LinkedIn: Search "Supply Chain Manager Basel", filter Pharma

---

## VERGLEICH DER 3 OPTIONEN

| | **Option 1: Consultant** | **Option 2: Sozial-Manager** | **Option 3: Pharma Supply Chain** |
|---|---|---|---|
| **Gehalt** | CHF 120–150k | CHF 110–140k | CHF 130–170k |
| **Jobsicherheit** | Mittel (Projekte) | Hoch (stabil) | Sehr hoch (Pharma-Boom) |
| **Work-Life-Balance** | Schlecht (viel unterwegs) | Gut (9-5) | Gut (Standard) |
| **Sinn/Purpose** | Hoch (Unternehmen helfen) | Sehr hoch (Menschen helfen) | Mittel (Geschäft) |
| **Chancen Basel** | Sehr gut (KMU überall) | Gut (Sozial-Sektor stark) | Ausgezeichnet (Pharma-Hub!) |
| **Startgeschwindigkeit** | Mittel (1–2 Monate) | Mittel (2–3 Monate) | Schnell (Pharma sucht aktiv) |

---

## DEINE SITUATION: Ehrlich und Real

✅ **Deine Stärken:**
- 30+ Jahre harte, praktische Erfahrung
- Bewiesenes Track Record (Durchsatz um 20% verbessert, etc.)
- Hohe Sozialkompetenz – das können Junge nicht kaufen
- Mit 55 Jahren = reife Führungsperson, nicht "junior"

⚠️ **Deine Herausforderungen:**
- Alter 55: Manche Firmen sind subtil ageist
- Du kennst die Digital-Trends weniger als 30-Jährige
- KI ersetzt Admin/Planning-Jobs – aber NICHT Deine Kernkompetenz (menschliche Führung)

💡 **Deine beste Strategie:**
1. Deine **Menschliche Führungsqualität** ist dein Vorteil gegen KI
2. Weg von "Director" → hin zu "Consultant/Coach" (flexibler, mehr Kontrol)
3. LinkedIn + Direct Outreach = schneller als Job-Portale
4. Pharma/Medtech in Basel = deine beste Chance (demographisch stark)

---

## KONKRETE TAGE 1–7:

- **Tag 1:** LinkedIn-Profil updaten, Foto (professionell lächelnd), Headline: "Operations Leader | Supply Chain Consultant | Change Manager"
- **Tag 2:** 20 LinkedIn-Connections anfragen (Pharma/Consulting/Sozial-Sektor)
- **Tag 3:** 5 Direct Messages: "Ich bin ab Januar verfügbar, habe 30 Jahre Ops-Erfahrung, möchte mit euch sprechen"
- **Tag 4–5:** 10 Mails an Arbeitgeber (Roche, Novartis, GAW, Beratungen)
- **Tag 6:** 2 Recruiter anrufen (Michael Page, Heidrick & Struggles)
- **Tag 7:** Evtl. erste Rückmeldung, erste Gespräche vereinbaren

---

## DAS WICHTIGSTE:

**Du brauchst dir nicht Sorgen zu machen, dass KI dich ersetzt.**

KI ersetzt vielleicht Daten-Analysten, vielleicht Grafikdesigner.
Aber KI ersetzt NICHT:
- Menschen, die andere Menschen führen
- Menschen, die Vertrauen aufbauen
- Menschen, die 30 Jahre Branchenwissen haben
- Menschen, die schnell improvisieren können

Das bist DU.

---

**PDF-Ready: Dieser Report kann ausgedruckt und Arbeitgebern gegeben werden.**

Viel Erfolg! 🎯

Richard Rickli  
Bericht generiert: 10. Februar 2026  
KI-JobFinder (beta)
