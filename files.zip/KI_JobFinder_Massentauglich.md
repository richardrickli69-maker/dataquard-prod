# KI-READY: Umschulung für den Job der Zukunft

## Die Realität
- Millionen Jobs verschwinden durch KI
- Menschen brauchen schnell neue Fähigkeiten
- Aber: Niemand kann sich 2-Jahres-Kurse leisten
- Lösung: Schnelle, günstige, praktische Umschulung

---

## Der Service: "KI-Ready in 4 Wochen"

### Was ist KI-Ready?

Ein **Online-Kurs + Coaching**, der Menschen in 4 Wochen fit macht für Jobs, die KI NICHT ersetzen kann:

1. **KI-Prompting Spezialist** (CHF 199.–)
   - Menschen lernen, Claude/ChatGPT richtig zu nutzen
   - Sie werden "KI-Flüsterer" in ihren Firmen
   - 4 Wochen, 2h/Woche
   - **Problem gelöst:** Statt KI fürchten → KI nutzen

2. **Human Touch Spezialisten** (CHF 199.–)
   - Customer Service, Coaching, Beratung
   - Jobs, die MENSCHLICHE Beziehungen brauchen
   - 4 Wochen Training + Vermittlung
   - **Problem gelöst:** Neue Fähigkeiten für Mensch-zu-Mensch Jobs

3. **Content Creator für KI-Zeitalter** (CHF 199.–)
   - Mit Claude/AI hochwertige Inhalte erstellen
   - Freelance-Arbeit als Fallback
   - Kurzes Einkommen verdienen
   - **Problem gelöst:** Von KI profitieren statt verlieren

4. **Daten-Manager für kleine Firmen** (CHF 199.–)
   - Firmen brauchen Menschen, die KI nutzen & Daten managen
   - Kleine Unternehmen zahlen CHF 3'000–5'000/Monat dafür
   - Training + Vermittlung
   - **Problem gelöst:** Job mit gutem Einkommen

---

## Aber: VIEL ZU KOMPLEX für "2 Wochen + CHF 3'000"

**Das ist noch nicht massentauglich genug.**

---

## Die ECHTE Lösung: "KI-Jobfinder"

### Konzept: Einfach & Direkt

**Menschen mit bedrohten Jobs laden ihre CV/Skills hoch.**
**Claude Cowork analysiert → Gibt ihnen 3 konkrete neue Job-Optionen, die KI NOT ersetzt.**

**Preis: CHF 29.–**
**Verdienst: 1'000 Kunden × CHF 29.– = CHF 29'000.– in 2 Wochen möglich**

### Wie funktioniert's:

**Kunde:**
- Lädt CV hoch (oder schreibt: "Ich bin Telefonist, 15 Jahre Erfahrung")
- Zahlt CHF 29.–
- Wartet 24 Stunden

**Du (mit Claude Cowork):**
- Analysiere: "Was kann dieser Mensch WIRKLICH?"
- Finde 3 Jobs, die KI nicht ersetzen kann
- Gebe konkrete nächste Schritte

**Beispiel:**
```
Input: "Ich bin Telefonist bei der Post, 15 Jahre. KI macht mich arbeitslos."

Output (Claude):
1. "Customer Happiness Manager" - Remote-Jobs bei Startups (Dezember starten)
   - Warum: Menschen wollen mit echten Menschen reden
   - Dein Vorteil: 15 Jahre Kundenerfahrung
   - Gehalt: CHF 4'500–6'000
   - Nächster Schritt: LinkedIn-Profil aktualisieren, 5 Startups kontaktieren

2. "Crisis Manager für Servicehotlines" - Banken, Versicherungen
   - Warum: Banken brauchen Menschen für komplexe Probleme
   - Dein Vorteil: Stressfestigkeit, Kommunikation
   - Gehalt: CHF 5'000–6'500
   - Nächster Schritt: auf LinkedIn nach "Service Manager" suchen

3. "Coach für Menschen in Übergängen" - Neuer Job in der Zukunft
   - Warum: Menschen brauchen Hilfe bei Karrierewechsel
   - Dein Vorteil: Du kennst das Problem selbst
   - Verdienst: CHF 50–100/Stunde
   - Nächster Schritt: Zertifizierung (online, 4 Wochen, CHF 800)
```

**Kunde ist happy:** Konkrete, hoffnungsvolle, actionable Optionen für CHF 29.–

---

## Warum das funktioniert:

✅ **MASSENTAUGLICH** – Betrifft MILLIONEN (nicht nur Gründer)
✅ **BILLIG** – CHF 29.– ist für jeden bezahlbar
✅ **SCHNELL** – 2h Arbeit pro "Job-Report"
✅ **VIRAL POTENZIAL** – Menschen erzählen Freunden ("Rettet meine Karriere!")
✅ **SKALIERBAR** – Je mehr Kunden, desto mehr verdienst du
✅ **KEINE RECHTSPROBLEME** – Du gibst "Ideen", keine "Beratung"

---

## Die Rechnung (2 Wochen):

**Realistisches Szenario:**

| Woche | Kunden | Umsatz |
|-------|--------|--------|
| 1 | 100 | CHF 2'900 |
| 2 | 200 | CHF 5'800 |
| **TOTAL** | **300** | **CHF 8'700** |

**Nach Stripe (2.9%):** ~CHF 8'400.–

**Deine Zeit:** 
- Woche 1: 100 Kunden × 2h = 200h (unmöglich allein)
- → Du brauchst Automatisierung!

---

## Wie du das automatisierst:

### Variante A: "Halb-automatisch"
- Kunde zahlt CHF 29.–
- Formular: CV hochladen + 5 Sätze über sich schreiben
- **Du lässt Claude Cowork laufen** (15 min pro Report)
- Claude erstellt 80% des Reports
- **Du editierst & verfeinert** (10 min)
- Total: 25 min pro Report × 100 Kunden = ~40 Stunden/Woche

### Variante B: "Vollautomatisch" (Zukunft)
- Kunde zahlt CHF 29.–
- CV hochladen
- Claude Cowork macht den GANZEN Report automatisch
- Kunde bekommt PDF sofort
- Du verdienst passiv

---

## 2-Wochen-Umsetzungsplan:

### **Tag 1–2: Website (3 Stunden)**
- [ ] Simple Website mit Google Sites
- [ ] Titel: "KI-Jobfinder – Finde deinen neuen Job"
- [ ] Beschreibung: "Dein Job wird durch KI ersetzt? Wir finden dir 3 konkrete Alternativen. CHF 29.–"
- [ ] Upload-Formular (Google Forms)
- [ ] Stripe "Jetzt kaufen"-Button

### **Tag 3–4: Marketing (4 Stunden)**
- [ ] LinkedIn-Posts über KI & Jobverlust
- [ ] Facebook-Gruppen ("Schweizer Arbeitslose", "Karriere-Umsteiger")
- [ ] Reddit: r/switzerland, r/jobs
- [ ] Google Ads: "Job durch KI ersetzt" → zu deiner Website
- [ ] Email an Arbeitsagenturen, Coachings, Umschulungszentren

### **Tag 5–14: Verkaufen & Liefern (80 Stunden)**
- [ ] Erste Kunden kommen → Reports machen
- [ ] Tägliches Marketing (30 min)
- [ ] Reports fertigstellen (2h pro Report)

---

## Marketing-Kopie (Zum direkt verwenden):

### Facebook/LinkedIn Post:
```
😰 Dein Job wird bald durch KI ersetzt?

Bankangestellte, Anwälte, Grafikdesigner, Support-Mitarbeiter...
Millionen Jobs verschwinden in den nächsten 2 Jahren.

Aber: Es gibt Jobs, die KI NICHT ersetzen kann.

Wir finden DIR diese Jobs.
→ Lade deine CV hoch
→ Zahle CHF 29.–
→ Bekomme 3 konkrete Job-Alternativen

🎯 Die beste Versicherung gegen KI-Arbeitslosigkeit.

Link in Profil 👆
```

### Google Ads Headline:
```
"Job durch KI bedroht?"
"Wir finden dir 3 neue Karrieren"
"CHF 29.– Job-Report"
```

---

## Claude Cowork Workflow (Pro Report 25 min):

```
Kunde lädt CV hoch + schreibt 5 Sätze
         ↓
Claude Cowork analysiert:
  - Aktuelle Skills
  - Erfahrung
  - Stärken
  - Was KI NICHT kann (Menschliche Skills)
         ↓
Claude generiert 3 Job-Optionen:
  - Job-Titel
  - Beschreibung
  - Warum Kunde passt
  - Gehalt/Verdienst
  - Nächste Schritte
         ↓
Du editierst & formatierst (10 min)
         ↓
PDF senden an Kunde
         ↓
Fertig → Nächster Customer
```

---

## Die brutale Rechnung (Realistische Szenarien):

### Optimistisch: Viral auf LinkedIn/Facebook
- 500 Kunden in 2 Wochen
- 500 × CHF 29.– = **CHF 14'500**
- Nach Gebühren: **CHF 14'000**
- Deine Zeit: 200 Stunden

### Realistisch: Gutes Marketing, No Viral
- 200 Kunden in 2 Wochen
- 200 × CHF 29.– = **CHF 5'800**
- Nach Gebühren: **CHF 5'600**
- Deine Zeit: 80 Stunden

### Pessimistisch: Langsamer Start
- 50 Kunden in 2 Wochen
- 50 × CHF 29.– = **CHF 1'450**
- Nach Gebühren: **CHF 1'400**
- Deine Zeit: 20 Stunden

---

## Das Geheimnis zum Erfolg:

**VIRALES MARKETING** – Menschen mit Jobangst erzählen ihren Freunden.

Wenn du 50 Kunden bekommst, erzählen sie es vielleicht 300 anderen.
Dann brauchst du fast nicht mehr zu werben.

---

## Kritische Fragen:

**F: Ist CHF 29.– nicht zu billig?**
Nein. Es geht um VOLUMEN. 500 × CHF 29.– ist mehr als 10 × CHF 500.–

**F: Was wenn Claude schlecht reports macht?**
Du testst mit 5 Reports selbst. Wenn gut → rollst aus. Wenn schlecht → Feedback geben, verbessern.

**F: Wie viel Marketing kostet?**
- Google Ads: CHF 500–1'000 für 2 Wochen (optional)
- Facebook/LinkedIn/Reddit: kostenlos
- **Total: CHF 0–1'000 Investition**

**F: Bin ich nicht "unfair" zu echten Coaches?**
Nein. Du gibst Menschen HOFFNUNG + konkrete OPTIONEN für CHF 29.–.
Echte Coaches kosten CHF 200–500/Stunde und brauchen Monate.
Du bist complementär, nicht konkurrierend.

---

## Nach 2 Wochen (Wenn es läuft):

✓ Preis auf CHF 49.– erhöhen
✓ Premium-Option: "Job-Report + 1h Coaching-Call" für CHF 99.–
✓ Partnerships mit Arbeitsagenturen
✓ Einen Assistenten einstellen (outsource Reports)
✓ Skalierung auf andere Länder (Deutschland, Österreich)

---

## TL;DR:

**KI-Jobfinder: CHF 29.– pro Job-Report**
- Millionen Menschen betroffen
- Billig, schnell, actionable
- Viral-Potenzial (Menschen teilen, weil existenziell)
- 2–14 Wochen möglich mit realistischem Verdienst
- Nach 2 Wochen: CHF 1'400–14'000
- Marketing: Kostenlos (+ optional CHF 500–1'000 Ads)

**Das ist massentauglich.**
```
