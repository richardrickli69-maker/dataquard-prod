# 🚀 Wie man das Dataquard Auto-Setup Script nutzt

**Zeitaufwand:** 5 Minuten zum Ausführen + 30 Minuten Installations-Zeit = 35 Minuten TOTAL!

---

## 📥 SCHRITT 1: Script herunterladen

### Option A: Direkt von hier (EMPFOHLEN)

```
1. Sie haben bereits diese Datei:
   → Dataquard_Auto_Setup.ps1

2. Speichern Sie die Datei auf Ihrem HP OmniBook:
   → Downloads Ordner ist ok

3. Merken Sie sich den Pfad!
   (z.B. C:\Users\Richard\Downloads\Dataquard_Auto_Setup.ps1)
```

---

## ⚙️ SCHRITT 2: PowerShell als Administrator öffnen

**Wichtig: Der Script BRAUCHT Administrator-Rechte!**

```
Methode 1 (SCHNELLSTE):
1. Drücken Sie: Win + X
2. Klicken Sie: "Windows PowerShell (Admin)"
   oder "Terminal (Admin)"

Methode 2 (Alternative):
1. Drücken Sie: Win + R
2. Geben Sie ein: powershell
3. Drücken Sie: Ctrl + Shift + Enter (nicht nur Enter!)

Methode 3 (Sicher):
1. Öffnen Sie "Startmenü"
2. Suchen Sie: "PowerShell"
3. Rechtsklick → "Als Administrator ausführen"

→ Sie wissen dass es Administrator-Rechte hat, wenn
   das Fenster BLAU ist und "Administrator" oben steht!
```

---

## ▶️ SCHRITT 3: Script ausführen

**In PowerShell (Administrator) geben Sie ein:**

```powershell
# Zuerst zur Downloads gehen (oder wo Sie das Script gespeichert haben):
cd Downloads

# Dann das Script ausführen:
.\Dataquard_Auto_Setup.ps1

# Falls Fehler "cannot be loaded because running scripts is disabled":
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
.\Dataquard_Auto_Setup.ps1
```

**Oder (NOCH EINFACHER) - kompletter Pfad:**

```powershell
C:\Users\[YourUsername]\Downloads\Dataquard_Auto_Setup.ps1
```

Ersetzen Sie `[YourUsername]` mit Ihrem Windows-Benutzernamen!

---

## 🔍 Was passiert jetzt?

Das Script wird Sie fragen:

```
1. Admin-Check ✓ (automatisch)

2. Chocolatey Installation ✓ (automatisch, erste Mal langsamer)

3. Tools Installation ✓ (automatisch):
   - Git
   - Node.js
   - Visual Studio Code
   - GitHub CLI
   - 7-Zip

4. Ordnerstruktur ✓ (automatisch):
   C:\Development\
   ├─ Projects\
   │  └─ dataquard\
   ├─ Tools\
   ├─ Resources\
   └─ Backups\

5. Git Konfiguration ❓ (Sie müssen eingeben):
   → Name: "Richard Rickli"
   → Email: "richard@dataquard.ch"

6. VS Code Extensions ✓ (automatisch)

7. VS Code Settings ✓ (automatisch)

8. .gitignore ✓ (automatisch)

9. .env.local Template ✓ (automatisch)

10. PowerShell Optimierung ✓ (automatisch)

11. Verifikation ✓ (automatisch - zeigt alle installierten Tools)
```

---

## ⏱️ Timeline während Ausführung

```
MINUTE 0-2:   Chocolatey installiert (wird nur einmal gemacht)
MINUTE 2-10:  Tools werden heruntergeladen & installiert
              (Git, Node.js, VS Code, etc.)
MINUTE 10-15: Sie tippen Namen/Email für Git
MINUTE 15-20: VS Code Extensions installieren
MINUTE 20-30: Finale Konfiguration & Verifikation
MINUTE 30:    ✅ FERTIG!
```

---

## ✅ Nach Abschluss: Was Sie sehen

Das Script zeigt am Ende:

```
🎉 ========================================
   SETUP ERFOLGREICH ABGESCHLOSSEN!
   ========================================

Überprüfe instalierte Tools:
  ✅ Git: git version 2.44.0.windows.1
  ✅ Node.js: v21.6.1
  ✅ npm: 10.2.4
  ✅ VS Code: 1.96.4

Ordnerstruktur:
  ✅ C:\Development
  ✅ C:\Development\Projects
  ✅ C:\Development\Projects\dataquard
  ✅ C:\Development\Tools
  ✅ C:\Development\Resources
  ✅ C:\Development\Backups
```

---

## 🔧 Wenn Fehler auftauchen

### Fehler 1: "cannot be loaded because running scripts is disabled"

```powershell
Lösung:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
.\Dataquard_Auto_Setup.ps1
```

---

### Fehler 2: "Chocolatey not found"

```powershell
Lösung:
1. Schließen Sie PowerShell
2. Öffnen Sie PowerShell als Administrator NEU
3. Versuchen Sie erneut
```

---

### Fehler 3: "Node.js/Git not found nach Script"

```powershell
Lösung:
1. Windows NEUSTART (sehr wichtig!)
2. Öffnen Sie PowerShell neu
3. Geben Sie ein: node --version
4. Sollte jetzt funktionieren
```

---

### Fehler 4: "VS Code Extensions Installation failed"

```
Kein Problem!
- Das Script installiert die wichtigsten Extensions
- Sie können später weitere manuell hinzufügen
- Nicht kritisch für die Entwicklung
```

---

## 📋 Nächste Schritte nach dem Script

### Schritt 1: WINDOWS NEUSTART (empfohlen!)

```
Warum?
- Alle PATH-Umgebungsvariablen werden aktualisiert
- Tools sind dann überall verfügbar
- PowerShell Profil wird geladen

Wie?
1. Speichern Sie alles was offen ist
2. Klick Start → Herunterfahren
3. Starten Sie Windows neu
4. Öffnen Sie PowerShell neu
```

---

### Schritt 2: Teste Setup

```powershell
Öffne PowerShell und geben Sie ein:

# Test 1: Git
git --version
# Sollte anzeigen: git version 2.xx.x

# Test 2: Node.js
node --version
# Sollte anzeigen: v21.x.x

# Test 3: npm
npm --version
# Sollte anzeigen: 10.x.x

# Test 4: VS Code
code --version
# Sollte anzeigen: Version nummern

# Test 5: Ordner-Navigation
dq
# Sollte Sie zu C:\Development\Projects\dataquard führen
```

---

### Schritt 3: GitHub konfigurieren

```powershell
Authentifiziere Dich mit GitHub:

gh auth login

Beantworte die Fragen:
1. "What is your preferred protocol for Git operations?"
   → https

2. "Authenticate Git with your GitHub credentials?"
   → Y

3. "How would you like to authenticate GitHub CLI?"
   → "Login with a web browser"

4. Browser öffnet sich → Genehmigen Sie
```

---

### Schritt 4: Supabase Konto erstellen

```
1. Gehen Sie zu https://supabase.com
2. Klick "Start your project"
3. Sign up mit GitHub
4. Neues Projekt erstellen:
   ├─ Name: "dataquard"
   ├─ Region: "Europe (Zurich)"
   └─ Password: [SICHER speichern!]

5. Kopieren Sie die Keys:
   ├─ NEXT_PUBLIC_SUPABASE_URL
   ├─ NEXT_PUBLIC_SUPABASE_ANON_KEY
   └─ SUPABASE_SERVICE_KEY

6. Speichern Sie in Datei:
   C:\Development\Projects\dataquard\.env.local
   
   Inhalt:
   NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=xxxxx
   SUPABASE_SERVICE_KEY=xxxxx
```

---

### Schritt 5: Stripe Konto erstellen

```
1. Gehen Sie zu https://stripe.com
2. Melden Sie sich an
3. Gehen Sie zu Developers → API Keys
4. Kopieren Sie:
   ├─ Publishable Key (pk_test_...)
   └─ Secret Key (sk_test_...)

5. Speichern Sie in .env.local:
   STRIPE_PUBLIC_KEY=pk_test_xxxxx
   STRIPE_SECRET_KEY=sk_test_xxxxx

WICHTIG: Verwenden Sie TEST Keys, nicht LIVE Keys!
```

---

### Schritt 6: Erste Next.js App starten

```powershell
cd dataquard

npx create-next-app@latest . --typescript --tailwind

Fragen:
- "Would you like to use ESLint?" → Yes
- "Would you like to use Tailwind CSS?" → Yes
- "Would you like your code inside a src/ dir?" → No
- "Would you like to use App Router?" → Yes
- "Would you like to use Turbopack for next dev?" → Yes

Dann:
npm run dev

→ Öffnet http://localhost:3000 🚀
```

---

## 📞 Wenn Sie trotzdem Probleme haben

1. **Screenshot des Fehlers machen**
2. **Schreiben Sie mir den Fehler-Text**
3. **Ich helfe Ihnen fixen!**

---

## 🎯 ZUSAMMENFASSUNG

| Schritt | Zeit | Was Sie tun |
|---------|------|-----------|
| 1. Script herunterladen | 1 Min | Speichern Sie Dataquard_Auto_Setup.ps1 |
| 2. PowerShell öffnen | 1 Min | Win + X → PowerShell Admin |
| 3. Script ausführen | <1 Min | `.\Dataquard_Auto_Setup.ps1` |
| 4. Script läuft | 30 Min | Sie tippen Name/Email für Git |
| 5. Windows Neustart | 5 Min | Neustart erforderlich |
| 6. Setup testen | 5 Min | `node --version`, `git --version` |
| 7. Supabase/Stripe | 10 Min | Konten erstellen, Keys eintragen |
| **TOTAL** | **52 Min** | **Sie sind ready!** |

---

## ✨ BENEFITS des Auto-Setup Scripts

```
✓ AUTOMATISIERT
  → Sie müssen nicht 20 Befehle einzeln eingeben

✓ SICHER
  → Script prüft Rechte & Abhängigkeiten

✓ DOKUMENTIERT
  → Sie sehen was installiert wird

✓ WIEDERHOLBAR
  → Falls was schiefgeht, können Sie es erneut laufen

✓ ZEITSPAREN
  → Von 2-3 Stunden auf 30-40 Minuten!

✓ FEHLERMINIMIERUNG
  → Viel weniger Tippfehler möglich
```

---

## 🎉 Sie sind fast ready!

Nach dem Auto-Setup Script:

```
✓ Windows ist aktualisiert
✓ Chocolatey installiert
✓ Git installiert & konfiguriert
✓ Node.js & npm installiert
✓ Visual Studio Code mit Extensions
✓ GitHub CLI installiert
✓ Ordnerstruktur erstellt
✓ PowerShell optimiert
✓ .env Templates vorhanden

→ Sie können SOFORT mit Phase 0 starten! 🚀
```

---

**Los geht's! Laden Sie das Script herunter und führen Sie es aus!**

**Falls Probleme: Schreiben Sie mir den Error-Text und ich helfe!** 💪
