# 💰 Dataquard – KORRIGIERTE Kostenkalkulation MIT RAV + ANWALT-VALIDIERUNG

**Version:** 3.0 (Vollständig & Korrekt)  
**Datum:** Februar 2026  
**Szenario:** Mit RAV-Finanzierung + Komplette Anwaltsvalidierung

---

## 🎯 Was kostet die KOMPLETTE Anwaltsvalidierung?

### **Phase 6: Rechtliche Validierung (Detailliert)**

| Posten | Zeit | Kosten | Beschreibung |
|--------|------|--------|-------------|
| **Haftungs-Disclaimer** | 1–2h | CHF 300–500 | "Dataquard ersetzt keine Rechtsberatung" |
| **AGB (Terms of Service)** | 2–3h | CHF 500–1.000 | Zahlungskonditionen, Haftung, Kündigung |
| **Text-Module-Validierung** | 10–15h | **CHF 3.500** | ⚠️ DAS HAB ICH VERGESSEN! |
| **AVV (Auftragsverarbeitung)** | 0h | CHF 0 | Supabase stellt aus (kostenlos) |
| **Datenschutzerklärung (dataquard.ch)** | 0.5h | CHF 0 | Mit eigenem Tool generiert |
| **SUBTOTAL** | **13–21h** | **CHF 4.300–5.000** | |

**Ich hatte ursprünglich nur CHF 1.200 eingerechnet!**

---

## 🔴 Was ist die "Text-Module-Validierung"? (CHF 3.500)

Der Anwalt muss prüfen:

```
✓ P1-P7 Module (Pflicht-Texte)
   └─ Sind sie rechtlich korrekt für nDSG + DSGVO?

✓ W1-W8 Module (Website-spezifisch)
   └─ Cookie-Banner, Kontaktformular, etc. konform?

✓ D1-D12 Module (Drittanbieter)
   └─ Google Analytics, Meta Pixel, YouTube - korrekt beschrieben?

✓ C1-C5 Module (Cookies)
   └─ Cookie-Kategorisierung rechtlich ok?

✓ Z1-Z3 Module (Zahlungen)
   └─ Stripe, PayPal, TWINT korrekt dokumentiert?

✓ HR1-HR5 Module (HR/Recruitment) ← EINZIGARTIG!
   └─ Bewerbungen, Talent-Pool, Mitarbeiterdaten korrekt?

✓ T1-T2 Module (Datenübertragungen)
   └─ EU vs. USA Transfers (SCHREMS II) dokumentiert?

KRITISCHE FRAGEN:
├─ Speicherdauern korrekt? (HR: 10 Jahre? Talent-Pool: 12 Monate?)
├─ Haftungsausschlüsse wasserdicht?
├─ Disclaimer klar genug?
└─ Alles DSGVO + nDSG konform?

→ Das braucht 10–15 Stunden Anwalts-Zeit!
```

---

## 💸 REVIDIERTE Kostenkalkulation (MIT RAV + VOLLSTÄNDIGER ANWALT)

### **SZENARIO A: Ohne RAV (Original)**

```
EINMALKOSTEN:
├─ Infrastruktur:           CHF 35
├─ Entwicklung (168h):      CHF 25.200
├─ Anwalt (komplett):       CHF 4.300–5.000 ← KORRIGIERT!
└─ TOTAL:                   CHF 29.535–30.235

LAUFENDE KOSTEN/MT:         CHF 3–75
BREAK-EVEN:                 Mt 7–8 (statt Mt 6)
YR 1 GEWINN:                CHF 103.000 (statt CHF 106.135)
```

---

### **SZENARIO B: MIT RAV (IHRE Situation)**

```
EINMALKOSTEN:
├─ Domain:                  CHF 15
├─ Infrastruktur:           CHF 20
├─ Entwicklung:             CHF 0 ← RAV BEZAHLT!
├─ Anwalt (komplett):       CHF 4.300–5.000 ← KORREKT!
└─ IHRE INVESTITION:        CHF 4.335–5.035

RAV BEZAHLT:
└─ Entwicklung (168h):      CHF 25.200

LAUFENDE KOSTEN/MT:         CHF 3–75
BREAK-EVEN:                 Mt 0 (sofort!)
YR 1 GEWINN:                CHF 151.535 (statt CHF 156.535)
```

---

## 📊 Vergleich: OHNE vs. MIT RAV (Korrekt)

### **Einmalkosten Vergleich:**

| Posten | Ohne RAV | Mit RAV | Differenz |
|--------|----------|---------|-----------|
| Domain | CHF 15 | CHF 15 | CHF 0 |
| Infrastruktur | CHF 20 | CHF 20 | CHF 0 |
| **Entwicklung** | **CHF 25.200** | **CHF 0** | **-CHF 25.200** |
| **Anwalt (KORREKT)** | **CHF 4.500** | **CHF 4.500** | **CHF 0** |
| **TOTAL IHRE KOSTEN** | **CHF 29.735** | **CHF 4.535** | **-CHF 25.200** |

---

### **Gewinn-Vergleich (Korrekt):**

| Metrik | Ohne RAV | Mit RAV | Vorteil RAV |
|--------|----------|---------|---------|
| Yr 1 Umsatz | CHF 138.095 | CHF 138.095 | CHF 0 |
| Stripe-Gebühren | -CHF 5.263 | -CHF 5.263 | CHF 0 |
| Fixkosten | -CHF 262 | -CHF 262 | CHF 0 |
| Netto-Umsatz | CHF 132.570 | CHF 132.570 | CHF 0 |
| **Ihre Investition** | **-CHF 29.735** | **-CHF 4.535** | **+CHF 25.200** |
| **Yr 1 Gewinn** | **CHF 102.835** | **CHF 128.035** | **+CHF 25.200** |
| **ROI** | **346%** | **2.820%** | **8x besser** |

---

## 📈 Detaillierte 12-Monats Prognose (Mit RAV + Anwalt)

### **Realistisches Szenario (50% Conversion)**

```
PHASE 0 (Woche 1-6):
├─ Sie arbeiten 5h/Tag
├─ RAV bezahlt: CHF 25.200
├─ Anwalt validiert Module: CHF 4.500
└─ Dataquard wird entwickelt & validiert

PHASE 1 (Mt 1-12):
│
Mt 1:  Umsatz CHF 1.490  - Kosten CHF 3      = CHF 1.487 PROFIT ✅
Mt 2:  Umsatz CHF 3.000  - Kosten CHF 3      = CHF 2.997 PROFIT
Mt 3:  Umsatz CHF 4.561  - Kosten CHF 3      = CHF 4.558 PROFIT
Mt 4:  Umsatz CHF 6.072  - Kosten CHF 3      = CHF 6.069 PROFIT
Mt 5:  Umsatz CHF 7.583  - Kosten CHF 3      = CHF 7.580 PROFIT
Mt 6:  Umsatz CHF 9.094  - Kosten CHF 36     = CHF 9.058 PROFIT
Mt 7:  Umsatz CHF 10.605 - Kosten CHF 36     = CHF 10.569 PROFIT
Mt 8:  Umsatz CHF 12.116 - Kosten CHF 36     = CHF 12.080 PROFIT
Mt 9:  Umsatz CHF 13.627 - Kosten CHF 36     = CHF 13.591 PROFIT
Mt 10: Umsatz CHF 15.138 - Kosten CHF 36     = CHF 15.102 PROFIT
Mt 11: Umsatz CHF 16.649 - Kosten CHF 36     = CHF 16.613 PROFIT
Mt 12: Umsatz CHF 18.160 - Kosten CHF 58     = CHF 18.102 PROFIT

JAHR 1 UMSATZ:             CHF 138.095
STRIPE-GEBÜHREN:          -CHF 5.263
FIXKOSTEN:                -CHF 262
NETTO-UMSATZ:             CHF 132.570

IHRE INVESTITION:         -CHF 4.535 (Domain + Anwalt)
RAV-BEZAHLUNG:            +CHF 25.200 (bereits bezahlt Mt 0)
                           ─────────────
YR 1 GEWINN:              CHF 153.235 🎉
```

---

## 🎯 ROI-Vergleich (KORREKT)

### **Ohne RAV:**

```
Investition:      CHF 29.735
Yr 1 Gewinn:      CHF 102.835
ROI:              (102.835 / 29.735) × 100 = 346%
Break-Even:       Mt 7
```

---

### **Mit RAV:**

```
Ihre Investition: CHF 4.535
Yr 1 Gewinn:      CHF 128.035
ROI:              (128.035 / 4.535) × 100 = 2.820%
Break-Even:       Mt 0 (sofort!)

VORTEIL:
├─ CHF 25.200 weniger Eigenkapital nötig
├─ Break-Even 7 Monate früher
├─ CHF 25.200 mehr Gewinn im Yr 1
└─ 8x besserer ROI!
```

---

## 💡 Was kostet der Anwalt wirklich?

### **Anwalts-Satz: CHF 250–350/Stunde**

| Task | Stunden | à CHF 350/h | Total |
|------|---------|----------|-------|
| Disclaimer formulieren | 1–2 | CHF 350–700 | CHF 500 |
| AGB schreiben/anpassen | 2–3 | CHF 700–1.050 | CHF 850 |
| **Module validieren** | **10–15** | **CHF 3.500–5.250** | **CHF 4.400** |
| Kleinere Korrektionen | 1 | CHF 350 | CHF 350 |
| **TOTAL** | **14–21h** | | **CHF 6.100** |

**Realistisch: CHF 4.500–5.000**

Ich habe ursprünglich CHF 1.200 genommen – das war zu niedrig!

---

## 📋 Neue Einmalkosten (Korrekt)

### **OHNE RAV:**

```
Domain:              CHF 15
Vercel/Supabase:     CHF 20
Entwicklung:         CHF 25.200
Anwalt:              CHF 4.500 ← AKTUALISIERT!
─────────────────────────────
TOTAL:               CHF 29.735
```

---

### **MIT RAV (IHRE Situation):**

```
Domain:              CHF 15
Infrastruktur:       CHF 20
Entwicklung:         CHF 0 (RAV bezahlt!)
Anwalt:              CHF 4.500
─────────────────────────────
IHRE INVESTITION:    CHF 4.535

RAV zahlt zusätzlich: CHF 25.200
TOTAL BUDGET:        CHF 29.735
```

---

## 🎯 Updated Timeline mit Anwalts-Validierung

```
WOCHE 0 (Vorbereitung):
├─ Anwalt kontaktieren
└─ Kosten-Schätzung: CHF 4.500

WOCHE 1-6 (Entwicklung + Validierung):
├─ Sie: 5h/Tag Entwicklung (RAV bezahlt: CHF 25.200)
├─ Anwalt: Module validieren (CHF 4.500, kann parallel laufen)
└─ Ergebnis: Vollständig validierte Dataquard

WOCHE 7 (Final Review):
├─ Anwalt gibt OK
├─ Domain bereits live
└─ Ready for Launch!

WOCHE 8 (Launch):
├─ Erste Customers
├─ Erste Einnahmen
└─ Profitabel ab Tag 1!
```

---

## 💰 Finanzielle Impact der Anwalts-Kosten

### **Mit vs. Ohne Anwalt:**

| Szenario | Investition | Yr 1 Gewinn | Break-Even |
|----------|----------|----------|----------|
| **Ohne Anwalt (riskant)** | CHF 4.535 | CHF 132.535 | Mt 0 |
| **Mit Anwalt (empfohlen)** | CHF 4.535 | CHF 128.035 | Mt 0 |
| **Differenz** | CHF 0 | -CHF 4.500 | CHF 0 |

**Fazit:** Der Anwalt kostet CHF 4.500, aber schützt Sie vor Millionen an Haftung!

---

## 🚨 Warum die Modul-Validierung CHF 3.500 kostet

Der Anwalt muss prüfen:

```
✓ Speicherdauern (HR: 10 Jahre, Talent-Pool: 12 Monate)
✓ Haftungsausschlüsse wasserdicht
✓ Disclaimer klar genug
✓ Cookies korrekt kategorisiert
✓ USA-Transfer (SCHREMS II) dokumentiert
✓ Alle Module nDSG + DSGVO konform
✓ Keine Rechtslücken

FEHLER KOSTEN MILLIONEN:
├─ Falsche Speicherdauer: Geldbuße CHF 10.000+
├─ Fehlender Disclaimer: Haftung unbegrenzt
├─ Cookies nicht kategorisiert: DSGVO-Verstoß
└─ USA-Transfer nicht dokumentiert: CHF 50.000+ Geldbuße
```

**CHF 4.500 Anwaltskosten sparen CHF 100.000+ Fehler-Kosten!**

---

## ✅ FINALE KOSTENKALKULATION (KORREKT)

### **OHNE RAV:**

| Item | Betrag |
|------|--------|
| Ihre Investition | CHF 29.735 |
| RAV-Bezahlung | CHF 0 |
| Yr 1 Umsatz | CHF 138.095 |
| Yr 1 Gewinn | CHF 102.835 |
| ROI | 346% |
| Break-Even | Mt 7 |

---

### **MIT RAV (EMPFOHLEN):**

| Item | Betrag |
|------|--------|
| Ihre Investition | CHF 4.535 |
| RAV-Bezahlung | CHF 25.200 |
| Yr 1 Umsatz | CHF 138.095 |
| Yr 1 Gewinn | CHF 128.035 |
| Effektive ROI | 2.820% |
| Break-Even | Mt 0 (sofort!) |

---

## 🎯 Zusammenfassung der Korrektur

| Was | Original | Korrekt | Differenz |
|-----|----------|---------|----------|
| Anwaltskosten | CHF 1.200 | CHF 4.500 | +CHF 3.300 |
| Yr 1 Gewinn (ohne RAV) | CHF 106.135 | CHF 102.835 | -CHF 3.300 |
| Yr 1 Gewinn (mit RAV) | CHF 156.535 | CHF 153.235 | -CHF 3.300 |
| Break-Even | Mt 6 | Mt 7 | +1 Monat |
| **Aber:** Risiko ist **viel niedriger** | | | ✅ |

---

## ✨ WICHTIG!

**Der Anwalt ist NICHT optional!**

Ohne Anwalt:
- ❌ Haftungsrisiko unbegrenzt
- ❌ DSGVO-Verstöße wahrscheinlich
- ❌ Mögliche Geldbuße CHF 50.000+

Mit Anwalt (CHF 4.500):
- ✅ Vollständig validiert
- ✅ Juridisch wasserdicht
- ✅ Haftung begrenzt

**Die CHF 4.500 sind die beste Investition überhaupt!**

---

## 📋 Nächste Schritte (KORRIGIERT)

```
1. ☑ RAV-Antrag einreichen
   "Ich entwickle Dataquard während Vorbereitung"
   Kosten: CHF 25.200 (RAV zahlt!)

2. ☑ Anwalt kontaktieren
   "Ich brauche Module-Validierung für DSGVO-Tool"
   Kosten: CHF 4.500 (Sie zahlen)

3. ☑ Domain kaufen
   Kosten: CHF 15 (Sie zahlen)

4. ☑ Infrastruktur (Free Plans)
   Kosten: CHF 20 (Sie zahlen)

GESAMT IHRE INVESTITION: CHF 4.535
RAV INVESTITION: CHF 25.200
TOTAL BUDGET: CHF 29.735
```

---

**Danke für die Korrektur!** 👏 Sie haben Recht – die Anwaltsvalidierung kostet CHF 4.500, nicht CHF 1.200!

Mit der korrekten Berechnung:
- **Mit RAV: CHF 4.535 Investition → CHF 153.235 Yr 1 Gewinn**
- **Immer noch 2.820% ROI** 🚀
- **Break-Even Mt 0** ✅
