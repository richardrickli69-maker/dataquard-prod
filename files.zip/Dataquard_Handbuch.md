# 📖 Dataquard Landing Page – Benutzerhandbuch

**Version:** 1.0  
**Datum:** Februar 2026  
**Sprache:** Deutsch  
**Status:** Produktionsbereit

---

## 📋 Inhaltsverzeichnis

1. [Überblick](#überblick)
2. [Erste Schritte](#erste-schritte)
3. [Dateistruktur](#dateistruktur)
4. [Technische Konfiguration](#technische-konfiguration)
5. [Inhalt & Texte anpassen](#inhalt--texte-anpassen)
6. [Sprachen-Management](#sprachen-management)
7. [Logo & Design](#logo--design)
8. [Stripe-Integration](#stripe-integration)
9. [Deployment & Hosting](#deployment--hosting)
10. [Troubleshooting](#troubleshooting)
11. [FAQ](#faq)

---

## 📊 Überblick

Die **Dataquard Landing Page** ist eine professionelle, mehrsprachige Marketingwebseite für Ihr DSGVO-Compliance-Tool. Sie wurde mit modernen Web-Technologien entwickelt und ist produktionsbereit.

### Hauptmerkmale

✅ **Responsive Design** – Funktioniert auf Desktop, Tablet und Mobilgeräten  
✅ **Mehrsprachig** – Deutsch, Französisch, Italienisch, Englisch  
✅ **Stripe-Integration** – Sichere Payment-Verarbeitung  
✅ **SEO-optimiert** – Meta-Tags für Suchmaschinen  
✅ **Schnell** – Optimiert für Performance  
✅ **Barrierefrei** – WCAG 2.1 konform  

### Browser-Kompatibilität

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile Safari (iOS 12+)
- Chrome Android

---

## 🚀 Erste Schritte

### 1. Datei öffnen

Die Landing Page liegt als **HTML-Datei** vor:
```
dataquard-landing-page.html
```

Öffnen Sie diese Datei in einem Webbrowser, um sie anzuzeigen:
- Lokal: Doppelklick auf die Datei
- Server: Über Ihren Webserver (Hostpoint, Infomaniak, etc.)

### 2. Schnelle Tests durchführen

1. **Sprachen testen**: Klicken Sie oben rechts auf DE/FR/IT/EN
2. **Navigation testen**: Scrollen Sie durch alle Abschnitte
3. **Links testen**: Alle Buttons sollten funktionieren
4. **Mobilversion testen**: Öffnen Sie in Browser-DevTools (F12) im Responsive Mode

### 3. Produktionsbereitschaft prüfen

Bevor Sie online gehen, überprüfen Sie diese Checkliste:

- ☐ Stripe-API-Key aktualisiert
- ☐ Logo-Image hochgeladen
- ☐ Alle Kontakt-Email-Adressen korrekt
- ☐ SSL-Zertifikat auf dem Server
- ☐ Domain/Hosting eingerichtet
- ☐ Analytics eingebunden (z.B. Google Analytics)
- ☐ Privacy Policy verlinkt
- ☐ Impressum verlinkt

---

## 📁 Dateistruktur

```
dataquard/
├── dataquard-landing-page.html       # ← Hauptdatei (öffnen Sie diese!)
├── assets/
│   ├── dataquard-logo.png            # Logo-Image (Sie müssen hochladen)
│   ├── favicon.ico                   # Website-Icon
│   └── styles.css                    # (in HTML eingebettet)
└── scripts/
    └── main.js                       # (in HTML eingebettet)
```

**Hinweis:** CSS und JavaScript sind in der HTML-Datei eingebettet. Sie müssen diese **nicht** separat herunterladen.

---

## ⚙️ Technische Konfiguration

### Schritt 1: Logo einbinden

Das Logo ist derzeit als Placeholder eingebunden. So fügen Sie Ihr echtes Logo ein:

**Option A: Online-Bild (empfohlen)**

1. Laden Sie Ihr Logo-Image auf einen Server hoch (z.B. Ihren Hosting-Provider)
2. Öffnen Sie `dataquard-landing-page.html` mit einem Text-Editor
3. Suchen Sie nach dieser Zeile (ca. Zeile 650):
```html
logoImg.src = 'data:image/svg+xml;base64,...';
```

4. Ersetzen Sie mit:
```html
logoImg.src = 'https://ihre-domain.ch/images/dataquard-logo.png';
```

**Option B: Base64-encoded Bild (lokal)**

1. Konvertieren Sie Ihr PNG zu Base64: https://www.base64encode.org/
2. Ersetzen Sie den `data:image/svg+xml;base64,...` Teil mit Ihrem Base64-Code

**Option C: Direkt im HTML-Ordner**

Speichern Sie das Logo im selben Ordner wie die HTML-Datei und verwenden Sie:
```html
logoImg.src = './dataquard-logo.png';
```

### Schritt 2: Stripe-API-Key eintragen

**WICHTIG:** Dies ist erforderlich für die Zahlungsabwicklung!

1. Gehen Sie zu https://dashboard.stripe.com/apikeys
2. Kopieren Sie Ihren **Public Key** (beginnt mit `pk_`)
3. Öffnen Sie die HTML-Datei und suchen Sie Zeile ~640:
```javascript
const stripe = Stripe('pk_test_your_key_here');
```

4. Ersetzen Sie mit Ihrem echten Key:
```javascript
const stripe = Stripe('pk_live_xxxxxxxxxxxxxxxxxx');
```

⚠️ **Sicherheit:**
- Verwenden Sie in Produktion **immer** `pk_live_...` (nicht `pk_test_`)
- Der Public Key ist öffentlich sichtbar – das ist normal und sicher
- Der Private Key darf **niemals** in der HTML-Datei stehen!

### Schritt 3: Backend-Zahlungshandler einrichten

Die HTML-Datei sendet Zahlungstokens an Ihren Server. Sie müssen einen Backend-Endpoint einrichten:

**Beispiel in Node.js/Express:**

```javascript
const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const app = express();

app.post('/api/process-payment', async (req, res) => {
  try {
    const { token, amount, email, name } = req.body;
    
    // Zahlung verarbeiten
    const charge = await stripe.charges.create({
      amount: 14900, // CHF 149.00 in Rappen
      currency: 'chf',
      source: token,
      description: `Dataquard für ${name}`,
      receipt_email: email
    });
    
    // Datenschutzerklärung generieren
    const privacyDoc = generatePrivacyDeclaration(req.body);
    
    // Email mit Download-Link senden
    sendEmail({
      to: email,
      subject: 'Ihre Dataquard Datenschutzerklärung',
      html: `Vielen Dank für Ihren Kauf! Hier ist Ihre Datenschutzerklärung...`,
      attachments: [privacyDoc]
    });
    
    res.json({ success: true, chargeId: charge.id });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.listen(3000);
```

---

## ✏️ Inhalt & Texte anpassen

### Texte ändern

Alle Texte sind in der HTML-Datei mit `data-text` Attributen gekennzeichnet:

```html
<h1 data-text="de">DSGVO-Konformität in 2 Minuten</h1>
<h1 data-text="fr" class="hidden">Conformité RGPD en 2 minutes</h1>
<h1 data-text="it" class="hidden">Conformità GDPR in 2 minuti</h1>
<h1 data-text="en" class="hidden">GDPR Compliance in 2 Minutes</h1>
```

**So ändern Sie einen Text:**

1. Suchen Sie nach `data-text="de"` (für deutsche Texte)
2. Ändern Sie den Textinhalt
3. Speichern Sie die Datei
4. Laden Sie die Seite im Browser neu

### Beispiel: "CHF 149" ändern zu "CHF 199"

Suchen Sie alle Vorkommen und ändern Sie:
```html
<!-- ALT: -->
<button class="btn btn-primary" onclick="openCheckout()" data-text="de">Jetzt für CHF 149 kaufen</button>

<!-- NEU: -->
<button class="btn btn-primary" onclick="openCheckout()" data-text="de">Jetzt für CHF 199 kaufen</button>
```

### Neue Abschnitte hinzufügen

Beispiel: Ein neuer Feature-Card:

```html
<div class="feature-card">
    <div class="icon">🎯</div>
    <h3 data-text="de">Neue Funktion</h3>
    <h3 class="hidden" data-text="fr">Nouvelle fonction</h3>
    <h3 class="hidden" data-text="it">Nuova funzione</h3>
    <h3 class="hidden" data-text="en">New Feature</h3>
    <p data-text="de">Beschreibung auf Deutsch...</p>
    <p class="hidden" data-text="fr">Description en français...</p>
    <p class="hidden" data-text="it">Descrizione in italiano...</p>
    <p class="hidden" data-text="en">Description in English...</p>
</div>
```

---

## 🌐 Sprachen-Management

### Unterstützte Sprachen

| Code | Sprache | Status |
|------|---------|--------|
| de | Deutsch | Vollständig |
| fr | Französisch | Vollständig |
| it | Italienisch | Vollständig |
| en | Englisch | Vollständig |

### Sprache hinzufügen (z.B. Spanisch)

1. Fügen Sie einen neuen Language-Button hinzu:
```html
<button class="lang-btn" data-lang="es">ES</button>
```

2. Duplizieren Sie alle `data-text` Attribute und übersetzen Sie:
```html
<h1 data-text="de">DSGVO-Konformität in 2 Minuten</h1>
<h1 data-text="fr" class="hidden">Conformité RGPD en 2 minutes</h1>
<h1 data-text="it" class="hidden">Conformità GDPR in 2 minuti</h1>
<h1 data-text="en" class="hidden">GDPR Compliance in 2 Minutes</h1>
<h1 data-text="es" class="hidden">Cumplimiento de GDPR en 2 minutos</h1>
```

3. Speichern und testen.

### Übersetzungshinweise

**Sorgfältig übersetzen Sie diese Abschnitte:**

1. **Hero-Text** – Das erste, was Besucher sehen
2. **Pricing-Sektion** – Klar und verständlich für Käufer
3. **Feature-Beschreibungen** – Präzise und fachlich
4. **CTA-Buttons** – Handlungsorientiert und überzeugend
5. **FAQ** – Hilfreich und vollständig beantwortet

**Tools für Übersetzungen:**
- Google Translate (für schnelle Übersichten)
- DeepL (für bessere Qualität)
- Professionelle Übersetzer (für juristische Texte!)

---

## 🎨 Logo & Design

### Logo-Position & Größe

Das Logo wird angezeigt in:
1. **Navigation** (oben links) – 45×45px
2. **Favicon** – 32×32px (optional)

### Logo-Format

Empfohlen:
- **PNG** mit transparentem Hintergrund
- **Größe:** Mindestens 512×512px
- **Größe:** Max. 200KB

### Design-Farben

```
Primärfarbe (Dunkelblau): #003d82 oder #001d3d
Akzentfarbe (Gold):       #fbbf24 oder #f59e0b
Hintergrund (Weiß):       #ffffff
Text (Dunkelgrau):        #1f2937
```

Diese Farben sind im CSS definiert und können angepasst werden (Zeile ~30-100).

### CSS anpassen

Wenn Sie Farben ändern möchten, bearbeiten Sie die CSS-Variablen:

```css
:root {
  --primary-dark: #003d82;
  --primary-light: #001d3d;
  --accent-gold: #fbbf24;
  --accent-yellow: #f59e0b;
}
```

---

## 💳 Stripe-Integration

### Wie die Zahlung funktioniert

1. **Kunde klickt** auf "Jetzt kaufen"
2. **Modal öffnet** mit Zahlungsformular
3. **Kunde gibt** Email und Kartendaten ein
4. **JavaScript** sendet Token an Stripe
5. **Backend** verarbeitet Zahlung
6. **Email** mit Datenschutzerklärung wird gesendet

### Stripe-Konto erstellen

1. Gehen Sie zu https://stripe.com (oder https://stripe.com/ch für Schweiz)
2. Registrieren Sie sich
3. Verifizieren Sie Ihre E-Mail
4. Bestätigen Sie Ihre Adresse
5. Aktivieren Sie Ihr Konto

### Test-Modus aktivieren

Für Tests verwenden Sie diese Kartendaten:

| Feld | Wert |
|------|------|
| Kartennummer | 4242 4242 4242 4242 |
| Ablaufdatum | 12/25 |
| CVC | 123 |
| Name | Test |

Diese Kartennummer funktioniert **nur** im Stripe Test-Modus!

### Live-Modus aktivieren

Wenn Sie bereit sind:

1. Gehen Sie zu https://dashboard.stripe.com/settings/account
2. Bestätigen Sie Ihre Geschäftsinformationen
3. Aktivieren Sie den "Live Mode"
4. Kopieren Sie Ihren **Live Public Key** (`pk_live_...`)
5. Ersetzen Sie den Test-Key in der HTML-Datei

### Sicherheit

- ✅ Alle Kartendaten werden direkt an Stripe gesendet (nie auf Ihrem Server!)
- ✅ SSL/TLS-Verschlüsselung ist erforderlich
- ✅ PCI-DSS-konform
- ✅ SCA/3D Secure für Sicherheit

---

## 🌍 Deployment & Hosting

### Anforderungen

- **HTTPS/SSL** (erforderlich für Stripe!)
- **PHP 7.2+** oder **Node.js** (für Backend-Payments)
- **Mindestens 100MB** Speicherplatz
- **E-Mail-Versand** (SMTP)

### Empfohlene Hosting-Provider (Schweiz)

1. **Hostpoint** – https://www.hostpoint.ch
   - Gutes Preis-Leistungs-Verhältnis
   - Schweizer Support
   - SSL inklusive

2. **Infomaniak** – https://www.infomaniak.com
   - Hohe Zuverlässigkeit
   - Guter Support
   - Swiss-hosted

3. **Cyon** – https://www.cyon.ch
   - Premium-Qualität
   - Schweizer Unternehmen
   - Gutes Support

### FTP Upload

1. Öffnen Sie einen FTP-Client (z.B. FileZilla)
2. Verbinden Sie sich mit Ihrem Hosting-Provider:
   - **Host:** ftp.ihre-domain.ch
   - **Benutzer:** Ihr Benutzername
   - **Passwort:** Ihr Passwort
3. Navigieren Sie zum `/public_html` Ordner
4. Laden Sie `dataquard-landing-page.html` hoch
5. Laden Sie `/assets` Ordner hoch

### Domain konfigurieren

1. Gehen Sie zu https://www.dataquard.ch
2. Während des Setups: `.ch` Domain-Registrierung
3. Setzen Sie die Nameserver auf Ihren Hosting-Provider
4. Warten Sie 24-48 Stunden für DNS-Propagation

### SSL-Zertifikat

Die meisten Schweizer Hosting-Provider bieten kostenlose SSL-Zertifikate an (Let's Encrypt).

Überprüfen Sie:
```bash
# Command-Line (Terminal)
curl -I https://dataquard.ch
# Sollte "HTTP/2 200" anzeigen
```

### CDN (optional)

Für bessere Performance können Sie Cloudflare verwenden:

1. Gehen Sie zu https://cloudflare.com
2. Registrieren Sie Ihre Domain
3. Ändern Sie Ihre Nameserver (im Registrar)
4. Aktivieren Sie Caching & Minification

---

## 🔧 Troubleshooting

### Problem: Sprache wechselt nicht

**Lösung:**
1. Öffnen Sie Browser-Konsole (F12)
2. Prüfen Sie auf JavaScript-Fehler
3. Überprüfen Sie, ob `data-text` Attribute korrekt sind
4. Versuchen Sie einen anderen Browser

### Problem: Stripe-Modal öffnet sich nicht

**Lösung:**
1. Überprüfen Sie die Stripe-API-Key
2. Öffnen Sie Browser-Konsole (F12)
3. Suchen Sie nach Fehlern wie "Stripe is not defined"
4. Stellen Sie sicher, dass `https://js.stripe.com/v3/` erreichbar ist

### Problem: Zahlungen werden nicht verarbeitet

**Lösung:**
1. Überprüfen Sie Ihre Backend-Implementation
2. Prüfen Sie Stripe-Dashboard auf Fehler (https://dashboard.stripe.com/logs)
3. Überprüfen Sie Server-Logs
4. Stellen Sie sicher, dass HTTPS korrekt konfiguriert ist

### Problem: Logo wird nicht angezeigt

**Lösung:**
1. Überprüfen Sie die URL/Pfad zum Logo
2. Stellen Sie sicher, dass die Datei existiert
3. Überprüfen Sie Dateiberechtigungen (644 für Dateien)
4. Öffnen Sie Browser-Konsole (F12) → Network → Suchen Sie nach dem Bild

### Problem: Mobile Version sieht verzerrt aus

**Lösung:**
1. Überprüfen Sie `<meta name="viewport">`
2. Testen Sie in echtem Mobilgerät (nicht nur Browser-Emulation)
3. Leeren Sie Browser-Cache (Ctrl+Shift+Del)
4. Überprüfen Sie CSS Media-Queries

### Browser-Konsole öffnen

- **Chrome/Edge:** F12 oder Ctrl+Shift+I
- **Firefox:** F12 oder Ctrl+Shift+K
- **Safari:** Cmd+Option+I

---

## ❓ FAQ

### F: Kann ich die Landing Page offline verwenden?
**A:** Ja, die HTML-Datei funktioniert lokal. Aber Stripe braucht HTTPS und Internet.

### F: Kann ich die Seite vor dem Launch testen?
**A:** Ja, verwenden Sie Stripe's Test-Mode mit den Beispielkartendaten.

### F: Wie lange dauert ein DNS-Update?
**A:** Normalerweise 5 Minuten bis 48 Stunden. Google's DNS ist oft schneller: `8.8.8.8`

### F: Kann ich Google Analytics hinzufügen?
**A:** Ja, fügen Sie den Google Analytics Code vor `</head>` ein:
```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### F: Wie kann ich die E-Mail-Benachrichtigungen personalisieren?
**A:** Bearbeiten Sie die Backend-Email-Template (siehe Stripe-Integration Abschnitt).

### F: Kann ich mehrere Zahlungsoptionen anbieten?
**A:** Ja, Stripe unterstützt:
- Kredit-/Debitkarten
- TWINT (Schweiz)
- PayPal
- Apple Pay/Google Pay

### F: Ist die Seite DSGVO-konform?
**A:** Die Seite selbst hat:
- ✅ SSL/TLS-Verschlüsselung
- ✅ Datenschutzerklärung (Link im Footer)
- ✅ Impressum (Link im Footer)
- ✅ Cookie-Banner (optional, hinzufügen)

Sie sollten diese Links einrichten!

### F: Wie oft sollte ich Updates durchführen?
**A:** 
- Überprüfen Sie monatlich auf Stripe API-Updates
- Aktualisieren Sie Inhalte nach Bedarf
- Testen Sie Links und Funktionen monatlich

### F: Kann ich die Seite mehrsprachig machen?
**A:** Ja! Sie ist bereits 4-sprachig. Weitere Sprachen können hinzugefügt werden (siehe Sprachen-Management).

### F: Welche Browser-Versionen werden unterstützt?
**A:** 
- Chrome 90+
- Firefox 88+
- Safari 14+ (macOS) / iOS 12+
- Edge 90+

Ältere Browser werden nicht unterstützt.

### F: Kann ich ein Backup erstellen?
**A:** Ja, speichern Sie die HTML-Datei mehrmals:
- Lokal auf Ihrem Computer
- In Cloud-Storage (Google Drive, OneDrive)
- Mit Ihrem Hosting-Provider (Backup-System)

---

## 📞 Support & Kontakt

Wenn Sie Fragen haben:

**Email:** hello@dataquard.ch  
**Website:** https://dataquard.ch  
**Chat:** Kontaktformular auf der Webseite  

---

## 📝 Lizenz & Rechtliches

Diese Landing Page wird bereitgestellt "wie besehen" ohne Gewährleistung. Sie sind verantwortlich für:

- Rechtliche Compliance (Datenschutz, Impressum, AGB)
- Zahlungsabwicklung (Stripe-Konto & -Bedingungen)
- Hosting & Domain
- Kundensupport

---

**Letzte Aktualisierung:** Februar 2026  
**Handbuch-Version:** 1.0  
**Status:** Aktiv & Produktionsbereit ✅

Viel Erfolg mit Ihrer Dataquard Landing Page! 🚀
