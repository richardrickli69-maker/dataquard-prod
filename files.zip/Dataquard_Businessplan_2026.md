# 📋 DATAQUARD – VOLLSTÄNDIGER BUSINESSPLAN 2026
## Kapital, Kosten, Rechtsform & Finanzielle Prognose

---

## 🎯 EXECUTIVE SUMMARY

**Geschäftsidee:** Dataquard – Automatisierter DSGVO/DSG-Generator für Schweizer KMU

**Zielmarkt:** 600'000 KMU in der Schweiz (Deutschland später)

**Geschäftsmodell:** One-time payment CHF 149 (keine Subscription)

**Marktpotenzial Jahr 1:** CHF 45'000 - CHF 75'000
**Marktpotenzial Jahr 3:** CHF 300'000+

**Benötigtes Startkapital:** CHF 5'000 - CHF 15'000

---

# 📊 TEIL 1: KAPITALBUDGET & INVESTITIONEN

## Phase 1: BOOTSTRAP (Wochen 1-4) – CHF 2'000-3'000

### Was du kaufst/einrichtest:

| Ausgabe | Kosten | Notwendig | Status |
|---------|--------|-----------|---------|
| **Domain (dataquard.ch)** | CHF 5 | ✅ MUSS | Jahr 1 |
| **Hostpoint Webhosting** | CHF 160 | ✅ MUSS | Jahr 1 |
| **Email (Cloud Office Plus)** | CHF 36 | ✅ MUSS | Jahr 1 |
| **Stripe Account Setup** | CHF 0 | ✅ MUSS | Kostenlos |
| **Anwalt-Validierung** | CHF 2'500-4'000 | ✅ MUSS | Woche 3-4 |
| **Logo/Design (Fiverr)** | CHF 100-300 | ⚠️ OPTIONAL | Nice-to-Have |
| **TOTAL PHASE 1** | **CHF 2'801 - CHF 4'541** | | |

**→ PHASE 1 IST KRITISCH: OHNE ANWALT-VALIDIERUNG KEIN START!**

---

## Phase 2: MARKETING LAUNCH (Wochen 5-8) – CHF 1'500-3'000

### Marketing-Budget zur Kundenakquisition:

| Ausgabe | Kosten | Zweck | ROI |
|---------|--------|-------|-----|
| **Google Ads (SEM)** | CHF 800-1'200 | Lead-Gen | 3:1 |
| **LinkedIn Ads (optional)** | CHF 300-500 | Branding | 2:1 |
| **Content (Blog Posts)** | CHF 200-400 | SEO | 5:1+ |
| **Email-Liste Bootstrap** | CHF 0 | Organisch | ∞ |
| **TOTAL PHASE 2** | **CHF 1'300 - CHF 2'100** | | |

**→ MARKETING IST OPTIONAL STARTEN, ABER MASSIV WICHTIG FÜR GROWTH!**

---

## TOTAL STARTUP-KAPITAL

```
Szenario A (MINIMAL - nur Bootstrap):
├─ Phase 1 (Webseite + Anwalt): CHF 2'800
├─ Phase 2 (Marketing): CHF 0
└─ TOTAL: CHF 2'800

Szenario B (EMPFOHLEN - Bootstrap + Lite Marketing):
├─ Phase 1: CHF 3'500
├─ Phase 2: CHF 1'500
└─ TOTAL: CHF 5'000

Szenario C (OPTIMAL - Bootstrap + Aggressives Marketing):
├─ Phase 1: CHF 4'000
├─ Phase 2: CHF 3'000
└─ TOTAL: CHF 7'000

Szenario D (PREMIUM - Alle Features):
├─ Phase 1: CHF 4'500
├─ Phase 2: CHF 5'000
├─ Zusatz (Designer, Video): CHF 3'000-5'000
└─ TOTAL: CHF 12'500 - CHF 14'500
```

---

## 💰 DETAILLIERTES BUDGET BREAKDOWN

### Anwalt-Validierung (CHF 2'500-4'000) – WICHTIGSTER POSTEN!

**Warum investieren:**
- ✅ Ohne Anwalt: Du kannst nicht "anwaltlich validiert" werben
- ✅ Mit Anwalt: +30-50% Conversion Rate
- ✅ ROI: 1 extra Kunde = CHF 149 > CHF 3'000 Investment (breakeven bei 20 Kunden!)

**Wer du kontaktierst:**
1. **Daniela Fábián (Privacy Legal)** – BEST OPTION
   - Preis: CHF 2'500-3'500
   - Spezialisation: Privacy/Datenschutz
   - Speed: 2-3 Wochen

2. **Balthasar Legal**
   - Preis: CHF 3'000-4'000
   - Spezialisation: Data Protection
   - Speed: 2-4 Wochen

3. **Lokale Anwälte** (als Fallback)
   - Preis: CHF 2'000-3'000 (verhandeln!)
   - Spezialisation: Variabel
   - Speed: 1-3 Wochen

---

### Hosting & Domain (CHF 200) – Pro Jahr!

```
Hostpoint Jahres-Kosten:
├─ Domain (dataquard.ch): CHF 15
├─ Smart Webhosting: CHF 118.80
├─ E-Mail Cloud Plus: CHF 36
└─ TOTAL/JAHR: CHF 169.80

Monatlich: ~CHF 14/Monat! 💪
```

**→ Super günstig! Nach 1 Kunde (CHF 149) hast du es wieder herein!**

---

### Google Ads Budget (CHF 800-1'200 Monat 1)

```
Kampagne-Strategie:
├─ Keywords: "DSGVO Website Schweiz", "Datenschutz Tool", "Cookie Banner"
├─ Budget: CHF 30-40/Tag (CHF 800-1'200/Monat)
├─ Target CPC: CHF 1-3 pro Klick
├─ Expected CTR: 300-500 Klicks/Monat
├─ Expected Conversions: 20-30 (5-7% Konversion)
└─ Revenue: CHF 3'000-4'500

ROI: (CHF 3'750 - CHF 1'000) = +CHF 2'750 profit im 1. Monat! 📈
```

---

# 📋 TEIL 2: RECHTSFORM-STRATEGIE

## 🎯 DIE ENTSCHEIDUNG: WANN BRAUCHST DU EINE RECHTSFORM?

### Timeline für Gründung:

```
WOCHE 1-4:
│
├─ Status: 🚀 SOLOPRENEUR (keine Rechtsform nötig!)
├─ Du: Richard Rickli (Privatperson)
├─ Website: dataquard.ch (Privatadresse ok für Start)
├─ Steuern: Gewerbeeinkommen 2026 (Veranlagung 2027)
└─ Kosten: CHF 0 für Rechtsform
   (Nur Website + Anwalt + Google Ads)

WOCHE 5-12 (nach 1. Erfolgen):
│
├─ Status: ⚠️ MUSST DU HANDELN
├─ Grund: Dein Umsatz wird sichtbar
├─ Grund: Kunden brauchen Impressum
├─ Grund: Steuerbehörden informieren
└─ Aktion: Gewerbeanmeldung machen

MONAT 3-4 (bei CHF 5'000+ Umsatz):
│
├─ Status: 🚀 GmbH/AG WIRD INTERESSANT
├─ Grund: Haftungsschutz (Versprechen: "anwaltlich validiert")
├─ Grund: Vertrauenssignal für Kunden
├─ Grund: Steuern sparen (15-20%)
└─ Aktion: GmbH gründen (CHF 2'000-3'000)

MONAT 6+ (bei CHF 10'000+ Umsatz):
│
├─ Status: ✅ AG OPTIMIERTER (wenn stark wachsend)
├─ Grund: Bessere Steuern
├─ Grund: Professional Image
└─ Kosten: CHF 3'000-4'000 für Gründung
```

---

## DETAILLIERTE RECHTSFORM-OPTIONEN

### Option 1: **SOLOPRENEUR (Einzelunternehmer) – START** ⭐

**Wann:** Von Tag 1 bis ca. Monat 3-4

**Was ist das:**
- Du arbeitest unter deinem Namen (Richard Rickli)
- Keine separate Rechtsperson
- Deine Privatadresse = Geschäftsadresse (ok für Start)

**Gründungskosten:**
- CHF 0 (komplett kostenlos!)
- Gewerbeanmeldung: CHF 0 (online beim Kanton)
- Handsdelregister-Eintrag: OPTIONAL (CHF 200-400)

**Steuern:**
```
Umsatz CHF 50'000:
├─ Einkommensteuer: 15-20% (bei dir persönlich)
├─ AHV/IV: ~9-10% Selbständigenbeitrag
└─ Gewinn: CHF 30'000-35'000 netto
```

**Haftung:**
- ❌ PROBLEM: Du haftest persönlich mit Privatvermögen
- ⚠️ Risiko: Bei Rechtsstreit (z.B. "Datenschutz-Texte waren falsch") → Privatvermögen weg!

**Vorteile:**
- ✅ CHF 0 Gründungskosten
- ✅ Sofort starten
- ✅ Einfache Buchhaltung
- ✅ Keine Formalitäten

**Nachteile:**
- ❌ Haftung unbegrenzt
- ❌ Weniger vertrauenswürdig (kein "Unternehmen")
- ❌ Später umständlich umzuwandeln

**→ BEST FOR:** Start-Phase (Wochen 1-12) wenn Risiko gering

---

### Option 2: **GESELLSCHAFT MIT BESCHRÄNKTER HAFTUNG (GmbH) – EMPFOHLEN** ⭐⭐⭐

**Wann:** Ab ca. Monat 3-4 (bei CHF 3'000-5'000 Umsatz)

**Was ist das:**
- Du gründest eine Kapitalgesellschaft (separate juristische Person)
- Dein Privatvermögen ist geschützt
- "Dataquard GmbH" ist das Unternehmen (nicht du persönlich)

**Gründungskosten:**
```
Notariat: CHF 1'000-1'500
Handelsregister-Eintrag: CHF 500-700
Stammkapital (Mindest): CHF 20'000 (musst aber nicht alles einzahlen!)
Buchhaltung/Consulting: CHF 500-1'000 Start

TOTAL GRÜNDUNG: CHF 2'000-3'200
```

**Stammkapital:**
- Mindest: CHF 20'000 (nur 50% müssen eingezahlt werden = CHF 10'000)
- Du brauchst das Geld NICHT! (Dein Geschäftskonto reicht)

**Steuern:**
```
Umsatz CHF 50'000, Gewinn CHF 35'000:
├─ Unternehmenssteuer: 8-10% (CHF 2'800-3'500)
├─ Deine Gehalt: CHF 20'000 (Angestellter)
├─ Angestelltensteuern: 10-12% (CHF 2'000-2'400)
├─ Gewinn reinvestiert: CHF 10'000-12'000
└─ TOTAL Steuern: CHF 5'000-6'000 (~14% eff.)

BESSER als Solopreneur! Sparst CHF 2'000-3'000/Jahr!
```

**Haftung:**
- ✅ PERFEKT: Nur die GmbH haftet (bis zu Stammkapital)
- ✅ Dein Privatvermögen bleibt sicher
- ✅ Customer sues GmbH, nicht dich

**Vorteile:**
- ✅ Haftung begrenzt ← WICHTIG!
- ✅ Professioneller
- ✅ Steuern sparen (~15-20% des Gewinns)
- ✅ Kredite leichter zu bekommen
- ✅ Skalierbar (Mitarbeiter einstellen)

**Nachteile:**
- ❌ CHF 2'000-3'000 Gründung
- ❌ Etwas mehr Buchhaltung
- ❌ Jahresbilanz nötig
- ❌ Notariat notwendig

**→ BEST FOR:** Ab Monat 3-4 wenn Umsatz sichtbar

---

### Option 3: **AKTIENGESELLSCHAFT (AG) – SPÄTER**

**Wann:** Ab CHF 100'000+ Jahresumsatz (Jahr 2-3)

**Gründungskosten:**
- CHF 3'000-4'000 (ähnlich GmbH)
- Stammkapital: CHF 100'000 (mindest)

**Steuern:**
- Unternehmenssteuer: 6-9% (besser als GmbH)
- Personalsteuern: 10-12%
- ← Besser ab großen Gewinnen

**Haftung:**
- ✅ Haftung begrenzt

**Vorteile:**
- ✅ Beste Steuern ab CHF 100'000+
- ✅ International anerkannt
- ✅ Geldaufnahme leichter (Aktien)
- ✅ Maximum Vertrauenssignal

**Nachteile:**
- ❌ Hohe Gründungskosten
- ❌ Viel Buchhaltung
- ❌ Komplexer (Aktionärsversammlung, Vorstand, etc.)
- ❌ Nur bei großem Umsatz sinnvoll

**→ BEST FOR:** Später (Jahr 2-3) bei starkem Growth

---

## 🎯 EMPFOHLENE RECHTSFORM-ROADMAP

```
MONAT 0-2: SOLOPRENEUR (Richard Rickli, Einzelunternehmer)
│
├─ Was du machst:
│  ├─ Website live
│  ├─ Anwalt-Validierung
│  ├─ Google Ads starten
│  └─ Erste Kunden gewinnen (5-10)
│
├─ Gründungskosten: CHF 0
├─ Umsatz: CHF 1'000-3'000
└─ Status: 🚀 STARTEN

MONAT 3-4: SOLOPRENEUR → GmbH GRÜNDEN
│
├─ Wenn Umsatz: CHF 3'000-5'000
├─ Action: 
│  ├─ Notariat-Termin (CHF 1'200)
│  ├─ Handelsregister-Eintrag (CHF 600)
│  ├─ GmbH-Gründung (legal + tax berater)
│  └─ Total: CHF 2'200-3'200
│
├─ Name: "Dataquard GmbH"
├─ Geschäftsadresse: Deine Adresse (ok für KMU)
└─ Status: ✅ PROFESSIONELL

MONAT 6+: GmbH LÄUFT
│
├─ Umsatz: CHF 5'000-15'000
├─ Gewinn: CHF 3'000-10'000
├─ Steuern: Sparsam (8-10%)
├─ Kunden: 30-100
└─ Status: 📈 WACHSTUM

JAHR 2 (OPTIONAL): GmbH → AG
│
├─ Wenn Umsatz: CHF 50'000+
├─ Grund: Steuern sparen (6-9%)
├─ Kosten: CHF 3'000-4'000
└─ Status: 🚀 SKALIERUNG
```

---

## 📋 GEWERBEANMELDUNG (KOSTENLOS!)

**Wann:** Sofort (vor Website-Launch empfohlen)

**Wo:** Kanton Baselland, Amt für Wirtschaft
- Online: https://www.baselland.ch/

**Was du brauchst:**
- Personalausweis
- Geschäftstätigkeit: "Softwareentwicklung & Online-Services"
- Geschäftsadresse: Deine Adresse ist ok

**Kosten:** CHF 0-50 (je nach Kanton)

**Dauer:** 5-10 Minuten (online)

**Benefit:** Sofort registriert, legal am Markt

---

## 🏛️ STEUERBEHÖRDE ANMELDEN (KOSTENLOS)

**Wann:** Parallel zur Gewerbeanmeldung

**Wo:** Kantonales Steueramt Baselland

**Was du anmeldest:**
- Geschäftseinkommen CHF 0-10'000 (Prognose für 2026)
- Betrieb: Einzelunternehmen (später GmbH)

**Kosten:** CHF 0

**Benefit:** Vor Steuerbehörde registriert, legal

---

# 📊 TEIL 3: FINANZIELLE PROGNOSE

## JAHR 1 (2026) – BOOTSTRAP PHASE

### Szenario: KONSERVATIV (pessimistisch)

```
Monat 1-2: Launch Phase
├─ Kunden: 5-10
├─ Umsatz: CHF 750-1'500
└─ Status: Test

Monat 3-4: Momentum
├─ Kunden: 15-25
├─ Umsatz: CHF 2'250-3'750
└─ Status: Erste Gewinne

Monat 5-6: Growth
├─ Kunden: 25-40
├─ Umsatz: CHF 3'750-6'000
└─ Status: Positiv

Monat 7-12: Scaling
├─ Kunden: 40-80
├─ Umsatz: CHF 6'000-12'000
└─ Status: Momentum

JAHR 1 TOTAL:
├─ Kunden: 100-180
├─ Umsatz: CHF 15'000-27'000
├─ Kosten: CHF 5'000
├─ GEWINN: CHF 10'000-22'000
└─ ROI: +200-400%
```

---

### Szenario: OPTIMISTISCH (realistisch mit Marketing)

```
Monat 1-2: Launch Phase
├─ Kunden: 10-15
├─ Umsatz: CHF 1'500-2'250
└─ + Google Ads Start (CHF 800)

Monat 3-4: Momentum
├─ Kunden: 30-50
├─ Umsatz: CHF 4'500-7'500
├─ Google Ads: CHF 1'000/Monat
└─ ROI: +3:1

Monat 5-6: Growth
├─ Kunden: 50-80
├─ Umsatz: CHF 7'500-12'000
├─ Google Ads: CHF 1'200/Monat
└─ SEO startet zu ranken

Monat 7-12: Scaling
├─ Kunden: 80-150
├─ Umsatz: CHF 12'000-22'500
├─ Google Ads: CHF 1'000/Monat (ROI wird besser)
└─ Mund-zu-Mund wirkt

JAHR 1 TOTAL:
├─ Kunden: 200-350
├─ Umsatz: CHF 30'000-52'500
├─ Kosten: CHF 10'000 (Anwalt + Hosting + Ads)
├─ GEWINN: CHF 20'000-42'500
└─ ROI: +300-500%!
```

---

### Szenario: AGGRESSIV (mit all-in Marketing)

```
Monat 1-2: Launch
├─ Kunden: 15-20
├─ Umsatz: CHF 2'250-3'000
├─ Ads Budget: CHF 1'200
└─ Facebook/LinkedIn: CHF 500

Monat 3-4: Momentum
├─ Kunden: 50-80
├─ Umsatz: CHF 7'500-12'000
├─ Ads Budget: CHF 1'500
└─ Content Marketing: CHF 400

Monat 5-6: Growth
├─ Kunden: 80-120
├─ Umsatz: CHF 12'000-18'000
├─ Ads Budget: CHF 1'500
├─ PR/Partnerships: CHF 300
└─ Influencer-Outreach: CHF 200

Monat 7-12: Scaling
├─ Kunden: 120-250
├─ Umsatz: CHF 18'000-37'500
├─ Ads Budget: CHF 1'200 (ROI wird besser)
├─ SEO dominiert (kostenlos)
└─ Mund-zu-Mund explosiv

JAHR 1 TOTAL:
├─ Kunden: 350-600
├─ Umsatz: CHF 52'500-90'000
├─ Kosten: CHF 15'000 (Anwalt + Hosting + Aggressive Marketing)
├─ GEWINN: CHF 37'500-75'000
└─ ROI: +400-600%!!!
```

---

## JAHR 2 (2027) – GROWTH PHASE

```
Annahmen:
├─ Baseline: Jahresende 2026 = CHF 50'000 Umsatz annualisiert
├─ Growth: 200-300% YoY (normal für SaaS in Jahr 2)
├─ Marketing: Effizienter (ROI: 4:1 vs 3:1 Jahr 1)
└─ Mund-zu-Mund: Wird dominant

PROGNOSE:
├─ Jahresumsatz: CHF 150'000-250'000
├─ Kunden: 1'000-1'700
├─ Kosten: CHF 15'000 (stabiler)
├─ GEWINN: CHF 135'000-235'000
├─ Marge: 90%! (Digitales Produkt!)
└─ Status: 🚀 PROFESSIONEL
```

---

## JAHR 3+ (2028+) – SKALING PHASE

```
Annahmen:
├─ Baseline: CHF 200'000 Umsatz
├─ Growth: 150-200% YoY (Reifere Phase)
├─ Expansion: Deutschland, Österreich starten
├─ Features: Premium-Package, Updates, Support

PROGNOSE:
├─ Jahresumsatz: CHF 500'000-1'000'000+
├─ Kunden: 3'000-6'000+
├─ Kosten: CHF 30'000-50'000 (Team-Expansion)
├─ GEWINN: CHF 450'000-950'000+
├─ Status: 🚀 SKALIERTES UNTERNEHMEN
```

---

# 💼 TEIL 4: DETAILLIERTER AUSGABENPLAN JAHR 1

## MONATLICHE FIXKOSTEN (ZU 100% PLAN)

```
Hostpoint Webhosting:          CHF 13.32/Monat
Dataquard Domain:              CHF 1.25/Monat (CHF 15/Jahr)
Stripe (1.5% + CHF 0.30/Trans): ~CHF 50-200/Monat
Accounting Software (optional): CHF 0-30/Monat

TOTAL FIXKOSTEN/MONAT: CHF 65-245
TOTAL FIXKOSTEN/JAHR:  CHF 780-2'940
```

**→ MEGA GÜNSTIG! Nach 1 Kunde (CHF 149) sind Fixkosten gedeckt!**

---

## VARIABLE KOSTEN (WENN DU MARKETING MACHST)

```
Google Ads:       CHF 800-1'500/Monat
LinkedIn Ads:     CHF 300-500/Monat
Content Creator:  CHF 200-400/Monat
Email Automation: CHF 0-50/Monat

TOTAL VARIABLE:   CHF 1'300-2'450/Monat
JAHR 1 (mit Ads): CHF 10'000-15'000
```

---

## EINMALIGE KOSTEN JAHR 1

```
Anwalt-Validierung:           CHF 2'500-4'000 (MUSS!)
GmbH-Gründung (ab Monat 4):   CHF 2'000-3'000 (SOLLTE)
Logo Design (Fiverr):         CHF 100-300 (OPTIONAL)
Professional Email Setup:     CHF 0 (in Hostpoint)

TOTAL EINMALIG: CHF 4'600-7'300
```

---

# 📋 TEIL 5: BREAK-EVEN ANALYSE

## WANN IST DU PROFITABEL?

### Szenario 1: MINIMAL (nur Anwalt + Hosting, kein Marketing)

```
Kosten Monat 1-3:
├─ Anwalt-Validierung: CHF 3'000 (Monat 3)
├─ Hosting (3 Monate): CHF 40
└─ TOTAL: CHF 3'040

Kosten Monat 4-6:
├─ Hosting (3 Monate): CHF 40
└─ TOTAL: CHF 40

BREAKEVEN:
├─ Kunden nötig: 3'040 / CHF 149 = ~20 Kunden
├─ Bei 1 Kunde/Woche: 5 Monate bis Breakeven
├─ Bei 1 Kunde/Tag (organisch): 1 Monat bis Breakeven! 🚀

REALITÄT: Wahrscheinlich 2-3 Monate
```

---

### Szenario 2: MIT MARKETING (Google Ads + Anwalt)

```
Kosten Monat 1-3:
├─ Anwalt: CHF 3'000
├─ Google Ads (CHF 1'000/Monat × 3): CHF 3'000
├─ Hosting: CHF 40
└─ TOTAL: CHF 6'040

Kunden in Monat 1-3:
├─ Monat 1: 5 Kunden (CHF 745)
├─ Monat 2: 12 Kunden (CHF 1'788)
├─ Monat 3: 20 Kunden (CHF 2'980)
└─ TOTAL: 37 Kunden (CHF 5'513)

RESULT: Noch nicht breakeven (CHF 5'513 < CHF 6'040)

Monat 4:
├─ Kosten: CHF 1'000 (nur Google Ads)
├─ Kunden: 30 (CHF 4'470)
└─ PROFIT: CHF 3'470! 💰

BREAKEVEN: Monat 4 (nach 3.5 Monaten)
```

---

# 💰 KAPITAL-ZUSAMMENFASSUNG

## WIEVIEL BRAUCHST DU ZUM STARTEN?

### Option A: MINIMAL (NICHT EMPFOHLEN)

```
Nur Anwalt + Hosting (kein Marketing):
├─ Anwalt: CHF 3'000
├─ Hosting Jahr 1: CHF 200
├─ Puffer (3 Monate Lebenshaltung): CHF 0 (nicht gerechnet)
└─ TOTAL: CHF 3'200

Problem: Wirst du vermutlich nie Kunden finden!
Lösung: Muss organisch/Mund-zu-Mund funktionieren
```

---

### Option B: EMPFOHLEN (SMART)

```
Anwalt + Hosting + Marketing (lite):
├─ Anwalt: CHF 3'500
├─ Hosting Jahr 1: CHF 200
├─ Google Ads Monat 1-3: CHF 2'500
├─ Puffer: CHF 0 (aber solltest haben)
└─ TOTAL: CHF 6'200

ROI: Nach 4 Monaten Breakeven, dann Profit!
EMPFOHLEN: Wenn du Ersparnis von CHF 6'000-10'000 hast
```

---

### Option C: OPTIMAL (AGGRESSIV)

```
Anwalt + Hosting + Marketing (aggressiv):
├─ Anwalt: CHF 4'000
├─ Hosting Jahr 1: CHF 200
├─ Google Ads Monat 1-6: CHF 6'000
├─ Content/Design: CHF 1'500
├─ GmbH-Gründung (ab Monat 4): CHF 2'500
└─ TOTAL: CHF 14'200

ROI: Nach 4-5 Monaten positiv!
Jahr 1 Umsatz: CHF 60'000-90'000
EMPFOHLEN: Wenn du CHF 15'000-20'000 investieren kannst
```

---

## 🎯 MEINE EMPFEHLUNG

**Starte mit Option B (EMPFOHLEN): CHF 6'000-8'000**

### Warum:
- ✅ Kostet nicht zu viel
- ✅ Reicht für Marketing
- ✅ Breakeven in 4 Monaten
- ✅ Jahr 1 Profit: CHF 20'000-40'000

### Wie du das Geld beschaffst:

1. **Eigene Ersparnisse:** CHF 6'000 (ideal!)
2. **Freund/Familie:** "Stilles Darlehen" (optional)
3. **Bootstrapped:** Wenn du monatliches Einkommen hast, monatlich investieren

---

# 📋 TEIL 6: DETAILLIERTE GRÜNDUNGS-CHECKLISTE

## SCHRITT 1-2: SOLOPRENEUR STARTEN (WOCHE 1-2)

- [ ] Gewerbeanmeldung online (Kanton Baselland)
- [ ] Steueranmeldung online (Kanton)
- [ ] Domain dataquard.ch kaufen bei Hostpoint
- [ ] Hosting aktivieren (Smart Webhosting)
- [ ] Email einrichten (support@dataquard.ch)
- [ ] Website hochladen
- [ ] Stripe Account erstellen
- [ ] Google Search Console einrichten
- [ ] Google Analytics einrichten

**Kosten:** CHF 200 (Domain + Hosting Jahr 1)

---

## SCHRITT 3-4: ANWALT KONTAKTIEREN (WOCHE 2-3)

- [ ] Email an Daniela Fábián schreiben (privacylegal.ch)
- [ ] Angebot erhalten und verhandeln (CHF 2'500-3'500)
- [ ] Validierungs-Request schreiben (Template vorhanden!)
- [ ] Anwalt sendet dir validierte Texte zurück

**Kosten:** CHF 2'500-4'000

**Timeline:** 3-4 Wochen

---

## SCHRITT 5-6: MARKETING STARTEN (WOCHE 4-5)

- [ ] Google Ads Account erstellen
- [ ] Ads-Kampagne aufsetzen (DSGVO, Datenschutz Keywords)
- [ ] Budget: CHF 30/Tag starten
- [ ] LinkedIn Ads Account (optional)
- [ ] Email-Liste Bootstrap (MailChimp kostenlos)

**Kosten:** CHF 800-1'200 Monat 1

---

## SCHRITT 7-8: GmbH GRÜNDEN (MONAT 3-4)

- [ ] Notartermin vereinbaren
- [ ] GmbH-Gründungsdokumente ausfüllen
- [ ] Stammkapital: CHF 10'000 (50% einzahlen)
- [ ] Handelsregister-Eintrag
- [ ] Neue Steuernummer beantragen
- [ ] Business-Adresse eventuell anpassen

**Kosten:** CHF 2'000-3'200

**Timeline:** 2-3 Wochen

---

# 🎉 ZUSAMMENFASSUNG

## KAPITAL BENÖTIGT

```
Minimum zum Starten:    CHF 3'500
Empfohlen:              CHF 6'000-8'000
Optimal (mit Marketing): CHF 12'000-15'000
```

## RECHTSFORM TIMELINE

```
Woche 1:      Gewerbeanmeldung (kostenlos)
Monat 1-3:    Solopreneur (no Kosten)
Monat 4-6:    GmbH gründen (CHF 2'500)
Später:       AG wenn >CHF 100'000 Umsatz
```

## FINANZIELLE PROGNOSE

```
Jahr 1: CHF 20'000-75'000 Gewinn (abhängig von Marketing)
Jahr 2: CHF 135'000-235'000 Gewinn
Jahr 3: CHF 450'000-950'000+ Gewinn
```

## ROI JAHR 1

```
Investition: CHF 6'000-10'000
Umsatz: CHF 30'000-90'000
Gewinn: CHF 20'000-75'000
ROI: +300-700%! 🚀
```

---

## 🚀 DEIN NÄCHSTER SCHRITT

**DIESE WOCHE:**
1. ✅ Gewerbeanmeldung machen (online, 5 Min)
2. ✅ Domain + Hosting kaufen (CHF 200, 10 Min)
3. ✅ Email an Anwalt schreiben (5 Min)
4. ✅ Google Ads Account erstellen (vorbereiten)

**NÄCHSTE WOCHE:**
1. ✅ Website live gehen
2. ✅ Mit Anwalt warten (validierung läuft)
3. ✅ Erste Kunden organisch gewinnen
4. ✅ Google Ads starten (monatlich CHF 1'000)

**MONAT 2-3:**
1. ✅ Anwalt-Validierung erhalten
2. ✅ Landing Page updaten
3. ✅ Werbung skalieren
4. ✅ Erste CHF 5'000 Umsatz erreichen

**MONAT 4:**
1. ✅ GmbH gründen
2. ✅ Professioneller auftreten
3. ✅ Mehr Marketing investieren
4. ✅ Breakeven erreicht! 💰

---

**DU SCHAFFST DAS!** 💪🚀

Minimal CHF 6'000 und du hast ein Geschäft das dir CHF 200'000+ in Jahr 2-3 bringt!
