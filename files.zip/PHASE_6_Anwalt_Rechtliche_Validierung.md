# ⚖️ PHASE 6: Anwalt & Rechtliche Validierung

**Version:** 1.0 (Detailliert & Vollständig)  
**Zeitaufwand:** 4–6 Wochen (parallel zu Phase 4–5)  
**Kosten:** CHF 4.300–5.000 (einmalig)  
**Kritikalität:** 🔴 ESSENTIELL!

---

## 📑 Inhaltsverzeichnis

1. [Übersicht Phase 6](#übersicht-phase-6)
2. [Was validiert der Anwalt?](#was-validiert-der-anwalt)
3. [Die 40+ Text-Module im Detail](#die-40-text-module-im-detail)
4. [Validierungs-Prozess Schritt-für-Schritt](#validierungs-prozess-schritt-für-schritt)
5. [Anwalt finden & beauftragen](#anwalt-finden--beauftragen)
6. [Disclaimer schreiben & prüfen](#disclaimer-schreiben--prüfen)
7. [AGB schreiben & prüfen](#agb-schreiben--prüfen)
8. [Modul-by-Modul Validierung](#modul-by-modul-validierung)
9. [Häufige Fehler & wie man sie vermeidet](#häufige-fehler--wie-man-sie-vermeidet)
10. [Checklisten & Timelines](#checklisten--timelines)
11. [FAQ für Anwälte](#faq-für-anwälte)

---

## 🎯 Übersicht Phase 6

### **Ziel:**
Dataquard ist **vollständig anwaltlich validiert** und Sie können mit Vertrauen sagen:
```
✓ "Anwaltlich geprüft und validiert"
✓ "DSGVO & nDSG konform"
✓ "Von [Anwalt-Name] validiert"
```

### **Was passiert in Phase 6:**

| Schritt | Zeit | Kosten | Wer? |
|---------|------|--------|------|
| **6.1: Anwalt finden** | 1–2 Wo | CHF 0 | Sie |
| **6.2: Disclaimer schreiben** | 1–2 Wo | CHF 300–500 | Anwalt |
| **6.3: AGB schreiben** | 2–3 Wo | CHF 500–1.000 | Anwalt |
| **6.4: Module validieren** | 3–4 Wo | CHF 3.500 | Anwalt |
| **6.5: Eigene Datenschutzerklärung** | 1 Tag | CHF 0 | Sie (mit Dataquard!) |
| **6.6: Finale Checks** | 1–2 Wo | CHF 0 | Beide |
| **TOTAL** | **4–6 Wo** | **CHF 4.300–5.000** | |

---

## 🔍 Was validiert der Anwalt?

### **Die 3 Hauptkomponenten:**

```
┌─────────────────────────────────────────────────────┐
│ KOMPONENTE 1: DISCLAIMER (CHF 300–500)             │
├─────────────────────────────────────────────────────┤
│ Prüft: Haftungsausschluss wasserdicht?             │
│ Frage: "Ersetzt Dataquard Rechtsberatung?"         │
│ Sicherung: Wer haftet bei Fehlern?                 │
│ Zeit: 1–2 Stunden                                   │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ KOMPONENTE 2: AGB (CHF 500–1.000)                  │
├─────────────────────────────────────────────────────┤
│ Prüft: Geschäftsbedingungen konform?               │
│ Frage: Kündigung, Zahlungen, Haftung klar?         │
│ Sicherung: Rechtlich wasserdicht?                   │
│ Zeit: 2–3 Stunden                                   │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ KOMPONENTE 3: MODULE (CHF 3.500) ← WICHTIGSTE!    │
├─────────────────────────────────────────────────────┤
│ Prüft: Alle 40+ Text-Module rechtlich korrekt?     │
│ Frage: nDSG + DSGVO konform?                       │
│ Sicherung: Keine versteckten Fehler?               │
│ Zeit: 10–15 Stunden (detaillierte Prüfung)         │
└─────────────────────────────────────────────────────┘
```

---

## 📋 Die 40+ Text-Module im Detail

### **SEKTION 1: PFLICHT-MODULE (P1–P7)**

Diese müssen in JEDER Datenschutzerklärung sein:

```
P1: VERANTWORTLICHE STELLE
├─ Name, Adresse, Kontakt
├─ Datenschutzbeauftragter (falls nötig)
└─ Anwalt prüft: Sind alle Kontakte korrekt?

P2: ALLGEMEINE HINWEISE
├─ "Diese Erklärung gilt für: [Dataquard.ch, ...]"
├─ "Gültig ab: [Datum]"
└─ Anwalt prüft: Scope klar definiert?

P3: RECHTSGRUNDLAGEN
├─ DSGVO Art. 6 (Rechtmässigkeit)
├─ nDSG Art. 5 (Zweckbindung)
├─ Z.B. "Art. 6 Abs. 1 f) DSGVO (berechtigtes Interesse)"
└─ Anwalt prüft: Begründung ausreichend?

P4: BETROFFENENRECHTE
├─ Recht auf Auskunft (Art. 15 DSGVO)
├─ Recht auf Löschung (Art. 17 DSGVO)
├─ Recht auf Widerspruch (Art. 21 DSGVO)
└─ Anwalt prüft: Alle Rechte erwähnt? Kontakt korrekt?

P5: SPEICHERDAUER
├─ "Server-Logs: 30 Tage"
├─ "Kundendaten: Während Vertrag + 3 Jahre"
├─ "HR-Daten: 10 Jahre nach Ausscheiden"
└─ Anwalt prüft: Dauer angemessen? Gesetzlich ok?

P6: DATENSICHERHEIT
├─ SSL/TLS Verschlüsselung
├─ Zugangsschutz
├─ Regelmässige Backups
└─ Anwalt prüft: Massnahmen ausreichend?

P7: ÄNDERUNGEN DIESER ERKLÄRUNG
├─ "Wir können diese Erklärung jederzeit ändern"
├─ "Benachrichtigung mindestens 30 Tage vorher"
└─ Anwalt prüft: Änderungsprozess klar?
```

---

### **SEKTION 2: WEBSITE-MODULE (W1–W8)**

Spezifisch für Websites:

```
W1: SERVER LOGS & HOSTING
├─ Webserver (Vercel/Vercel Infra)
├─ IP-Adressen geloggt? (Ja, automatisch)
├─ Speicherdauer: 30 Tage
└─ Anwalt prüft: Hosting-Provider dokumentiert?

W2: SSL/TLS VERSCHLÜSSELUNG
├─ "Verbindung ist verschlüsselt"
├─ "HTTPS aktiviert"
└─ Anwalt prüft: Alle URLs https?

W3: KONTAKTFORMULAR
├─ "Daten werden zu unserem E-Mail-Server gesendet"
├─ Speicherdauer: "Nach Beantwortung gelöscht"
└─ Anwalt prüft: E-Mail-Provider dokumentiert?

W4: NEWSLETTER & MAILING-LIST
├─ Mailchimp oder Resend
├─ Opt-In oder Opt-Out?
├─ Speicherdauer: Während Abo + 1 Jahr
└─ Anwalt prüft: Consent-Prozess dokumentiert?

W5: COOKIE-BANNER
├─ "Technisch notwendige Cookies (immer aktiv)"
├─ "Analyse-Cookies (opt-in)"
├─ "Marketing-Cookies (opt-in)"
└─ Anwalt prüft: Banner-Text DSGVO konform?

W6: E-COMMERCE & ONLINE-SHOP
├─ Produkt-Daten
├─ Bestellhistorie
├─ Rechnungs-Adressen
└─ Anwalt prüft: Speicherdauer angemessen?

W7: BESTELLPROZESS & ZAHLUNGEN
├─ "Zahlungsdaten werden an Stripe übertragen"
├─ "Stripe speichert nach PCI-DSS Standard"
└─ Anwalt prüft: Stripe-Vertrag dokumentiert?

W8: ONLINE-BUCHUNGSSYSTEM
├─ Calendly Integration
├─ "Kalender-Daten werden zu Calendly übertragen"
└─ Anwalt prüft: Datenübertragung dokumentiert?
```

---

### **SEKTION 3: DRITTANBIETER-MODULE (D1–D12)**

Die kritischsten Module! Hier passieren die meisten Fehler.

```
D1: GOOGLE ANALYTICS
├─ "Google Analytics trackt Besucher-Verhalten"
├─ "Daten werden in die USA übertragen"
├─ "SCHREMS II: [Erklärung der Schutzmassnahmen]"
├─ "Speicherdauer: 26 Monate (Google Standard)"
└─ Anwalt prüft: ⚠️ SCHREMS II dokumentiert?

D2: META PIXEL (Facebook Conversion Tracking)
├─ "Facebook erhält Daten über Website-Besucher"
├─ "USA-Transfer: [Schutzmassnahmen]"
├─ "Cookies: _fbp, _fbc"
└─ Anwalt prüft: Opt-In vor Tracking?

D3: YOUTUBE EMBEDS
├─ "YouTube-Videos setzen Cookies"
├─ "google-analytics.com Cookies"
├─ Alternative: "youtube-nocookie.com"
└─ Anwalt prüft: Opt-In vor Embedding?

D4: GOOGLE MAPS
├─ "Karten-Integration von Google"
├─ "Speichert Nutzer-Verhalten"
├─ "USA-Transfer"
└─ Anwalt prüft: Opt-In vorhanden?

D5: GOOGLE FONTS
├─ "Fonts werden von Google geladen"
├─ "USA-Transfer (minimal)"
├─ "Speicherdauer: bis Session endet"
└─ Anwalt prüft: OK (niedrig-Risiko)

D6: MAILCHIMP / NEWSLETTER
├─ "E-Mail-Adressen werden zu Mailchimp übertragen"
├─ "Mailchimp ist USA-basiert"
├─ "Double-Opt-In empfohlen"
└─ Anwalt prüft: Consent dokumentiert?

D7: CALENDLY / TERMINBUCHUNG
├─ "Kalender-Integration von Calendly"
├─ "USA-Transfer"
├─ "Speichert Terminbuchungen"
└─ Anwalt prüft: Alternativen erwähnt?

D8: GOOGLE TAG MANAGER
├─ "GTM ist ein Tagging-System"
├─ "Verwaltet Google Analytics, Pixel, etc."
└─ Anwalt prüft: Alle integrierten Tools aufgelistet?

D9: HOTJAR / SESSION RECORDING
├─ "Hotjar zeichnet Website-Sessions auf"
├─ "Sehr datenschutzkritisch!"
├─ "EU-basiert (Niedrig-Risiko)"
└─ Anwalt prüft: ⚠️ Sehr kritisch! Opt-In Pflicht?

D10: LINKEDIN PIXEL
├─ "LinkedIn trackt Besucher"
├─ "USA-Transfer"
└─ Anwalt prüft: Consent dokumentiert?

D11: INTERCOM / CHATBOT
├─ "Chatbot sammelt Besucherdaten"
├─ "USA-basiert"
└─ Anwalt prüft: Datenschutzerklärung complete?

D12: SONSTIGE EXTERNE SERVICES
├─ "Weitere Dienste: [Liste]"
└─ Anwalt prüft: Alle Services aufgelistet?
```

---

### **SEKTION 4: COOKIE-MODULE (C1–C5)**

Detailliert für jede Cookie-Kategorie:

```
C1: ALLGEMEINE COOKIE-INFO
├─ "Was sind Cookies?"
├─ "Warum verwenden wir sie?"
└─ Anwalt prüft: Erklärung ausreichend klar?

C2: TECHNISCH NOTWENDIGE COOKIES
├─ Session-ID, CSRF-Token, Sprach-Präferenz
├─ "Diese Cookies sind zwingend erforderlich"
├─ "Können nicht deaktiviert werden"
└─ Anwalt prüft: Nur echte notwendige Cookies?

C3: ANALYSE-COOKIES
├─ Google Analytics (_ga, _gid, _gat)
├─ "Diese Cookies sind optional"
├─ "Nutzer können ablehnen"
└─ Anwalt prüft: Ablehnung möglich?

C4: MARKETING-COOKIES
├─ Meta Pixel, LinkedIn Pixel, etc.
├─ "Für Werbung und Retargeting"
├─ "Opt-In erforderlich"
└─ Anwalt prüft: Klare Opt-In vor Tracking?

C5: COOKIE-BANNER TEXT
├─ "Wir verwenden Cookies..."
├─ "Akzeptieren" vs "Ablehnen" Buttons
├─ "Einstellungen speichern"
└─ Anwalt prüft: DSGVO-konform formuliert?
```

---

### **SEKTION 5: ZAHLUNGS-MODULE (Z1–Z3)**

Für Zahlungsabwicklung:

```
Z1: STRIPE ZAHLUNGSABWICKLUNG
├─ "Stripe verarbeitet Zahlungen"
├─ "Stripe ist USA-basiert"
├─ "PCI-DSS Level 1 (höchste Sicherheit)"
├─ "Speicherdauer: Für Rechnungs-Zwecke"
└─ Anwalt prüft: Stripe-Vertrag dokumentiert?

Z2: PAYPAL
├─ "PayPal verarbeitet Zahlungen"
├─ "USA-basiert"
└─ Anwalt prüft: Wenn PayPal verwendet?

Z3: TWINT / LOKALE ZAHLUNGEN
├─ "TWINT-Integration"
├─ "Schweiz-basiert (Niedrig-Risiko)"
└─ Anwalt prüft: Wenn TWINT verwendet?
```

---

### **SEKTION 6: HR & RECRUITMENT-MODULE (HR1–HR5) ← EINZIGARTIG!**

Das ist Dataquards Killer-Feature! Aber auch HOCHKRITISCH!

```
HR1: BEWERBUNGEN ÜBER WEBSITE
├─ "Bewerbungen können online eingereicht werden"
├─ "Name, Email, CV hochladen"
├─ "Speicherdauer: 1 Jahr (dann löschen)"
└─ Anwalt prüft: ⚠️ Speicherdauer angemessen?

HR2: BEWERBUNGEN PER E-MAIL
├─ "Bewerbungen per E-Mail zu [email]"
├─ "Speichern Sie Bewerbungen lokal?"
├─ "Speicherdauer: 1 Jahr nach Absage"
└─ Anwalt prüft: Datenschutzerklärung korrekt?

HR3: RECRUITING-PLATTFORMEN
├─ "Wir nutzen [Indeed, LinkedIn Recruiter, etc.]"
├─ "Kandidaten-Daten werden zu [Platform] übertragen"
├─ "USA-Transfer (falls relevant)"
└─ Anwalt prüft: AVV mit Recruiting-Platform?

HR4: TALENT-POOL & CANDIDATEN-MANAGEMENT
├─ "Wir speichern potenzielle Kandidaten"
├─ ⚠️ "Speicherdauer: 12 Monate (WICHTIG!)"
├─ "Kategorisierung: Welche Daten speichern wir?"
└─ Anwalt prüft: ⚠️ 12 Monate ist GRENZFALL! Ok?

HR5: MITARBEITERDATEN & PERSONALDATEI
├─ "Während Beschäftigung + 3 Jahre danach"
├─ "Gehalt, Adresse, Telefon, SSN speichern"
├─ "Accès-Kontrolle nur für HR"
└─ Anwalt prüft: ⚠️ 3 Jahre korrekt? Zugriff dokumentiert?
```

---

### **SEKTION 7: DATENÜBERTRAGUNGEN (T1–T2)**

Besonders kritisch für SCHREMS II:

```
T1: EU/EEA DATENÜBERTRAGUNG
├─ "Daten bleiben in EU/EEA"
├─ "Niedrig-Risiko"
└─ Anwalt prüft: OK

T2: USA DATENÜBERTRAGUNG (SCHREMS II) ⚠️⚠️⚠️
├─ "Daten werden in die USA übertragen"
├─ "Google Analytics, Meta Pixel, Stripe, etc."
├─ SCHREMS II DOKUMENTATION (KRITISCH!):
│  ├─ "Standard Contractual Clauses (SCCs)"
│  ├─ "Transfer Impact Assessment durchgeführt"
│  ├─ "Supplementary Measures implementiert"
│  └─ "Nutzzer können Transfers ablehnen"
└─ Anwalt prüft: ⚠️⚠️⚠️ SEHR KRITISCH! SCHREMS II ok?
```

---

## 🔄 Validierungs-Prozess Schritt-für-Schritt

### **Woche 1: Vorbereitung**

```
Tag 1-2: Anwalt finden
├─ IT-/Datenschutz-Spezialist suchen
├─ Erste Kontaktaufnahme
└─ Termin vereinbaren

Tag 3-5: Material vorbereiten
├─ Alle 40+ Module sammeln
├─ Landing Page + Generator zeigen
├─ Geschäftsmodell erklären
└─ "Das ist ein SaaS-Produkt, das DSGVO-Tools generiert"

Tag 6-7: Kickoff-Meeting mit Anwalt
├─ "Hier sind unsere Module"
├─ "Wir brauchen 3 Dinge: Disclaimer, AGB, Validierung"
├─ "Was prüfst du, was kostet es?"
└─ Budget klären: CHF 4.300–5.000
```

---

### **Woche 2-3: Disclaimer & AGB**

```
Parallel arbeiten:

ANWALT:
├─ Schreibt Disclaimer (1–2h)
├─ Schreibt AGB (2–3h)
└─ Sendet zur Review

SIE:
├─ Zeigen Dataquard-Screenshots
├─ Erklären den Generator
├─ Vorbereiten der Module für Validierung
```

---

### **Woche 4-6: Modul-Validierung (HAUPTARBEIT)**

```
Der Anwalt prüft ALLE 40+ Module:

Täglich:
├─ Anwalt liest 5–10 Module
├─ Markiert Fehler/Fragen
├─ Sendet Feedback
└─ SIE: Korrigieren & resubmit

Typische Fehler die der Anwalt findet:
├─ ❌ "SCHREMS II ist nicht dokumentiert!"
├─ ❌ "Speicherdauer zu lang (sollte 6 Mt sein, nicht 12)"
├─ ❌ "Google Analytics ohne Consent?"
├─ ❌ "HR-Daten 10 Jahre? Gesetz sagt max 3 Jahre!"
├─ ❌ "Disclaimer nicht wasserdicht"
└─ ✓ Sie korrigieren, resubmit, Anwalt genehmigt

ITERATIONEN:
├─ Runde 1: "Hier sind Mängel"
├─ Runde 2: Sie korrigieren
├─ Runde 3: Anwalt re-checked
├─ Runde 4: Final approval!
```

---

### **Woche 7: Final Approval & Signoff**

```
Anwalt sendet:
├─ "Alles validiert & approved!"
├─ Unterschriebene Bestätigung
├─ "Sie können sagen: ✓ Anwaltlich geprüft"
└─ Rechnung: CHF 4.500

SIE:
├─ Zahlen Rechnung
├─ Speichern Validierungs-Bestätigung
├─ Können jetzt mit Vertrauen launchen
```

---

## 💼 Anwalt finden & beauftragen

### **Welchen Anwalt Sie brauchen:**

```
IDEAL:
├─ IT-/Datenschutz Spezialist
├─ 5+ Jahre Erfahrung mit DSGVO
├─ Arbeitet mit Startups/SaaS
├─ Versteht die Schweizer Spezifika (nDSG)
└─ Schnelle Turnaround-Time

NICHT:
├─ ❌ Ein Generalist (zu langsam)
├─ ❌ Ein Notariat (für andere Dinge)
└─ ❌ Ein großes Büro (zu teuer CHF 15.000+)
```

---

### **Wo Sie Anwälte finden:**

```
1. ONLINE-KANZLEIEN (Günstiger, schneller):
   ├─ SwissLegalTech-Plattformen
   ├─ LawTech Startups
   └─ Kosten: CHF 3.000–5.000

2. MITTELSTÄNDISCHE KANZLEIEN:
   ├─ Zürich, Basel, Bern
   ├─ IT-/Datenschutz Abteilung
   └─ Kosten: CHF 4.000–6.000

3. NETZWERK:
   ├─ Fragen Sie Geschäftsfreunde
   ├─ Andere Startups
   └─ Referrals sind oft günstiger
```

---

### **Erste Anfrage an Anwalt (Copy-Paste):**

```
Sehr geehrte Frau/Herr [Anwalt-Name],

ich entwickle "Dataquard" – ein SaaS-Tool, das automatisierte 
Datenschutzerklärungen für Schweizer KMU generiert.

Ich brauche eine KOMPLETTE rechtliche Validierung:

1. Haftungs-Disclaimer (dass Dataquard keine Rechtsberatung ist)
2. Allgemeine Geschäftsbedingungen (AGB)
3. VALIDIERUNG ALLER TEXT-MODULE (ca. 40+ Module für:
   - Basis-Sektion (P1-P7)
   - Website-Sektion (W1-W8)
   - Drittanbieter (D1-D12)
   - Cookies (C1-C5)
   - Zahlungen (Z1-Z3)
   - HR/Recruitment (HR1-HR5) ← Einzigartig!
   - Datenübertragungen (T1-T2)
   
4. Besondere Aufmerksamkeit auf:
   - SCHREMS II Dokumentation
   - USA-Datenübertragungen
   - Speicherdauern (nDSG konform)
   - HR-Module (Bewerbungen, Talent-Pool)

Kosten-Budget: CHF 4.000–5.000 (einmalig)
Timeline: 4–6 Wochen

Können Sie das machen? Und was kostet es konkret?

Beste Grüsse,
[Ihr Name]
```

---

## ✏️ Disclaimer schreiben & prüfen

### **Muster-Disclaimer (vom Anwalt zu prüfen):**

```
DISCLAIMER:

Dataquard generiert automatisch Datenschutzerklärungen basierend 
auf Module und Eingaben. Dataquard ist NICHT als Rechtsberatung 
gedacht und ersetzt diese nicht.

WICHTIG:
- Sie als Nutzer sind selbst verantwortlich dafür, dass die 
  generierten Texte für Ihre Website, Ihr Geschäft und Ihre 
  Datenpraktiken zutreffen.
  
- Die generierten Texte stellen NICHT sicher, dass Sie vollständig 
  DSGVO- oder nDSG-konform sind.
  
- Wir empfehlen, die generierten Texte von einem Datenschutz-
  Anwalt überprüfen zu lassen.
  
- Dataquard haftet NICHT für:
  ✗ Fehler in den generierten Texten
  ✗ Bussgelder oder Strafen wegen nicht-konformer Policies
  ✗ Datenschutzverletzungen auf Ihrer Website
  ✗ Schäden durch Nutzung von Dataquard
  
- Ihre Haftung als Website-Betreiber bleibt unabhängig davon 
  gültig.

Bei Fragen: kontaktieren Sie einen Datenschutz-Anwalt!
```

**Der Anwalt wird das rewriting & testen.**

---

## 📋 AGB schreiben & prüfen

### **Was die AGB enthalten müssen:**

```
1. VERTRAGSPARTEIEN & GELTUNGSBEREICH
   - "Diese AGB regeln die Nutzung von dataquard.ch"

2. LEISTUNGSUMFANG
   - "Dataquard generiert Datenschutzerklärungen"
   - "Funktionen: Scanner, Module, PDF-Export"

3. ZAHLUNGSKONDITIONEN
   - "PROFESSIONAL: CHF 149 einmalig"
   - "ESSENTIAL: CHF 59/Jahr"
   - "Zahlungsarten: Stripe (Kreditkarte)"

4. ABOS & KÜNDIGUNG
   - "ESSENTIAL-Abos laufen bis gekündigt"
   - "Kündigung: 30 Tage vorher, via E-Mail"
   - "Rückerstattung: Nein (einmalige/wiederkehrende Zahlung)"

5. HAFTUNGSBESCHRÄNKUNG (KRITISCH!)
   - "Dataquard haftet NICHT für Fehler in generierten Texten"
   - "Max. Haftung = gezahlter Betrag"
   - "Keine Haftung für indirekte Schäden"

6. DATEN & DATENSCHUTZ
   - "Ihre Daten werden in Supabase (Zürich) gespeichert"
   - "Siehe unsere Datenschutzerklärung: dataquard.ch/privacy"

7. GERICHTSSTAND & ANWENDBARES RECHT
   - "Gerichtsstand: Zürich"
   - "Anwendbares Recht: Schweizer Recht"

8. ÄNDERUNGEN AN DEN AGB
   - "Wir können AGB ändern mit 30 Tagen Vorankündigung"
   - "Weiternutzung = Akzeptanz neuer AGB"

9. KONTAKT & SUPPORT
   - "support@dataquard.ch"
```

**Der Anwalt wird das prüfen & anpassen.**

---

## 🔐 Modul-by-Modul Validierung (Detailliert)

### **Wie der Anwalt jedes Modul prüft:**

Beispiel: **Google Analytics (D1 Modul)**

```
MODUL-TEXT (Beispiel):
"Wir verwenden Google Analytics zur Analyse von 
Website-Verhalten. Daten werden an Google LLC (USA) 
übertragen. Speicherdauer: 26 Monate."

ANWALT PRÜFT:
├─ ✓ Ist die Grundinfo korrekt? (Ja, GA ist Analyse-Tool)
├─ ❌ Fehler 1: "SCHREMS II nicht dokumentiert!"
│  └─ FIX: "Daten werden gemäss SCHREMS II mit 
│     Standardverträgen und Schutzmassnahmen in die USA 
│     übertragen. Nutzer können Consent verweigern."
│
├─ ✓ Ist 26 Monate die richtige Speicherdauer? (Ja)
│
├─ ❌ Fehler 2: "Wird Consent vor Tracking eingeholt?"
│  └─ FIX: "Vor Google Analytics muss ein Cookie-Consent 
│     Banner angezeigt werden."
│
└─ ❌ Fehler 3: "Ist der AVV mit Google dokumentiert?"
   └─ FIX: "Nutzer sollten wissen: Google ist 
      Datenverarbeiter, Sie sind Datenverantwortlicher"
```

---

### **Typische Fehler die der Anwalt findet:**

```
FEHLER-TYP 1: SCHREMS II NICHT DOKUMENTIERT
├─ Wo: D1 (Google Analytics), D2 (Meta Pixel), etc.
├─ Problem: USA-Transfer ohne Schutzmassnahmen
├─ Fix: "Dokumentieren Sie Standard Contractual Clauses"
└─ Impact: CHF 50.000+ GELDBUSSE möglich!

FEHLER-TYP 2: SPEICHERDAUER ZU LANG
├─ Wo: HR4 (Talent-Pool), HR5 (Mitarbeiterdaten)
├─ Problem: "12 Monate Speicherung ist zu lang"
├─ Fix: "Max 6 Monate, dann anonymisieren"
└─ Impact: Verstoss gegen nDSG Art. 5 (Datensparsamkeit)

FEHLER-TYP 3: CONSENT NICHT EINGEHOLT
├─ Wo: D1, D2, D3 (Tracking Services)
├─ Problem: "Nutzer müssen OPT-IN vor Tracking"
├─ Fix: "Cookie-Banner mit explizitem Consent"
└─ Impact: DSGVO Verstoß, Geldbusse CHF 10.000+

FEHLER-TYP 4: COOKIES NICHT KATEGORISIERT
├─ Wo: C1–C5 (Cookie-Module)
├─ Problem: "Welche sind notwendig, welche optional?"
├─ Fix: "Kategorisieren: notwendig/analyse/marketing"
└─ Impact: Cookie-Banner nicht konform

FEHLER-TYP 5: DISCLAIMER NICHT WASSERDICHT
├─ Wo: Allgemeiner Disclaimer
├─ Problem: "Haftungsschutz zu schwach"
├─ Fix: "Stärkere Haftungsausschlüsse formulieren"
└─ Impact: Haftung für Fehler bleibt bestehen
```

---

## ⚠️ Häufige Fehler & wie man sie vermeidet

### **Fehler #1: SCHREMS II Ignorieren**

```
❌ FALSCH:
"Wir nutzen Google Analytics. Daten werden in die USA übertragen."

✓ RICHTIG:
"Wir nutzen Google Analytics. Daten werden in die USA übertragen.
Zur Compliance mit SCHREMS II haben wir folgende Schutzmassnahmen
implementiert:
1. Standard Contractual Clauses (SCCs) mit Google
2. Transfer Impact Assessment durchgeführt
3. Supplementary Measures: Nutzers können Consent verweigern
4. Verschlüsselte Übertragung"

→ Der Anwalt wird SCHREMS II-Fehler definitiv finden!
```

---

### **Fehler #2: Speicherdauer zu lange**

```
❌ FALSCH:
HR4: "Talent-Pool: Speichern wir potenzielle Kandidaten für 3 Jahre"

✓ RICHTIG:
HR4: "Talent-Pool: Speichern wir potenzielle Kandidaten für 12 Monate.
Nach 12 Monaten werden Daten automatisch gelöscht, es sei denn,
Kandidat hat aktiv Interesse signalisiert."

→ Zu lange Speicherdauer = Datensparsamkeitsverstoss!
```

---

### **Fehler #3: Kein Consent vor Tracking**

```
❌ FALSCH:
"Wir nutzen Google Analytics zur Besucheranalyse."
(Keine Erwähnung von Cookie-Banner/Consent)

✓ RICHTIG:
"Wir nutzen Google Analytics zur Besucheranalyse.
WICHTIG: Vor dem Tracking wird ein Cookie-Consent-Banner angezeigt.
Besucher können Analytics ablehnen."

→ Tracking ohne Consent = DSGVO-Verstoß!
```

---

### **Fehler #4: Zu schwacher Disclaimer**

```
❌ FALSCH:
"Dataquard generiert Datenschutzerklärungen.
Wir sind nicht verantwortlich für Fehler."

✓ RICHTIG:
"Dataquard generiert automatisch Datenschutzerklärungen basierend
auf Ihren Eingaben. Dataquard ist NICHT als Rechtsberatung gedacht.
Sie sind selbst verantwortlich für die Richtigkeit und Vollständigkeit
der generierten Texte. Dataquard haftet NICHT für:
- Fehler in den Texten
- Geldbusse oder Strafen
- Datenschutzverletzungen
- Irgendwelche indirekten Schäden

Ihre Haftung als Website-Betreiber bleibt unabhängig gültig."

→ Stärkere Haftungsausschlüsse = Besserer Schutz!
```

---

## 📋 Checklisten & Timelines

### **PRE-ANWALT CHECKLISTE (Was SIE vorbereiten):**

```
□ Alle 40+ Module gesammelt & organisiert
□ Landing Page fertig (zum Zeigen)
□ Generator funktioniert (zum Demonstrieren)
□ Geschäftsmodell dokumentiert
□ Alle verwendeten Drittanbieter aufgelistet:
  ├─ Google Analytics?
  ├─ Meta Pixel?
  ├─ Stripe?
  ├─ Supabase?
  ├─ Resend?
  └─ Andere?
□ Speicherdauern dokumentiert
□ SCHREMS II Dokumentation (falls USA-Transfer)
□ Budget: CHF 4.300–5.000 eingeplant
```

---

### **WÄHREND ANWALT-ENGAGEMENT (Was der Anwalt macht):**

```
WOCHE 1-2:
□ Disclaimer entwerfen
□ AGB entwerfen
□ Anfangs-Feedback zu Modulen

WOCHE 3-4:
□ Modul-Validierung Runde 1 (intensive Prüfung)
□ Feedback-Liste mit Fehlern
□ SIE: Korrigieren

WOCHE 5:
□ Modul-Validierung Runde 2 (Re-Check nach Fixes)
□ Final comments
□ SIE: Weitere Korrektionen

WOCHE 6:
□ Final Approval
□ Unterschriebene Bestätigung
□ Rechnung: CHF 4.500
```

---

### **POST-ANWALT CHECKLIST (Was SIE danach tun):**

```
□ Rechnung bezahlen (CHF 4.500)
□ Validierungs-Bestätigung speichern
□ "✓ Anwaltlich geprüft" auf Website hinzufügen
□ Alle korrigierten Module in Dataquard eintragen
□ Datum der Validierung dokumentieren
□ Kontakt zum Anwalt für zukünftige Updates speichern
□ Ggf. jährliche Überprüfung vereinbaren (CHF 500–1.000/Jahr)
```

---

## 🤔 FAQ für Anwälte

**"Ich bin Anwalt und soll Dataquard validieren. Was muss ich wissen?"**

```
HINTERGRUND:
├─ Dataquard ist ein SaaS-Tool für DSGVO-Policies
├─ Generiert automatisch Text-Module
├─ Nutzer: Schweizer KMU, Vereine, Privatpersonen
└─ Sie validieren die Module selbst (nicht die generierten Policies der Kunden)

WAS VALIDIEREN SIE:
├─ P1-P7: Sind die Basis-Module rechtlich korrekt?
├─ W1-W8: Sind Website-Module DSGVO-konform?
├─ D1-D12: Sind Drittanbieter korrekt dokumentiert?
├─ C1-C5: Sind Cookies richtig kategorisiert?
├─ Z1-Z3: Sind Zahlungs-Prozesse dokumentiert?
├─ HR1-HR5: Sind HR-Speicherdauern legal?
└─ T1-T2: Ist SCHREMS II dokumentiert?

HÄUFIGE FEHLER (auf die Sie achten):
├─ SCHREMS II nicht dokumentiert (USA-Transfer)
├─ Speicherdauern zu lang (bes. HR-Module)
├─ Consent nicht vor Tracking eingeholt
├─ Disclaimer nicht wasserdicht
└─ Fehlende Kategorisierung von Cookies

TIMELINE:
├─ 10–15 Stunden Arbeit (CHF 3.500)
├─ 4–6 Wochen insgesamt
├─ 2–3 Iterationen mit Feedback/Korrektionen

KOSTEN:
├─ CHF 4.300–5.000 gesamt
├─ Oder: CHF 250–350/Stunde (ca. 12–15h Arbeit)
```

---

## 🎯 ZUSAMMENFASSUNG PHASE 6

```
ZIEL:        Vollständig rechtlich validiert & ready for launch
ZEIT:        4–6 Wochen (parallel zu Phase 4–5)
KOSTEN:      CHF 4.300–5.000 (einmalig)
ANWALT:      IT-/Datenschutz-Spezialist (5+ Jahre Erfahrung)
KRITIKALITÄT: 🔴 ESSENTIELL!

KOMPONENTEN:
1. Disclaimer (CHF 300–500)        - Haftungsausschluss
2. AGB (CHF 500–1.000)             - Geschäftsbedingungen
3. Module (CHF 3.500)              - 40+ Text-Module validiert

RESULTAT:
✓ "Anwaltlich geprüft und validiert"
✓ Vollständig DSGVO + nDSG konform
✓ SCHREMS II dokumentiert
✓ Haftung begrenzt
✓ Rechtsicherheit für Kunden
```

---

**Phase 6 ist NICHT optional – es ist die Grundlage für Vertrauen & Glaubwürdigkeit!** ✅
