# 💻 Laptop-Setup Guide: HP OmniBook für Dataquard-Entwicklung

**Zielgerät:** HP OmniBook X FlipNGAI (14", Intel Core Ultra 7, 32GB RAM, 1TB SSD)  
**Betriebssystem:** Windows 11 Pro (vermutlich)  
**Ziel:** Alles installieren & konfigurieren für Dataquard Phase 0-7 Entwicklung  
**Zeitaufwand:** 2–3 Stunden (erste Installations)

---

## 📑 Inhaltsverzeichnis

1. [Windows-Grundsetup](#windows-grundsetup)
2. [Essenzielle Developer-Tools](#essenzielle-developer-tools)
3. [Programmierumgebung (VS Code)](#programmierumgebung-vs-code)
4. [Node.js & npm](#nodejs--npm)
5. [Git & GitHub](#git--github)
6. [Supabase-Zugang](#supabase-zugang)
7. [Terminal/PowerShell Optimieren](#terminalpowershell-optimieren)
8. [Chrome DevTools & Browser](#chrome-devtools--browser)
9. [Sicherheit & Backups](#sicherheit--backups)
10. [Performance-Tipps](#performance-tipps)
11. [Checklisten](#checklisten)

---

## 🪟 Windows-Grundsetup

### **Schritt 1: Windows Updates**

```
1. Öffnen Sie Einstellungen (Win + I)
2. Gehen Sie zu "Update & Sicherheit"
3. Klicken Sie "Auf Updates überprüfen"
4. Installieren Sie ALLE Updates
5. Neustart (falls nötig)
```

**Warum:** Neueste Sicherheits-Patches + Performance-Verbesserungen

---

### **Schritt 2: Windows Features aktivieren**

```
1. Öffnen Sie PowerShell als Administrator
   (Win + X → Windows PowerShell (Admin))

2. Führen Sie aus:
   dism.exe /online /enable-feature /featurename:Microsoft-Windows-Subsystem-Linux /all

3. Neustart!
```

**Warum:** Ermöglicht WSL2 (Windows Subsystem for Linux) – optional aber empfohlen

---

### **Schritt 3: Ordnerstruktur erstellen**

```
Öffnen Sie Datei-Explorer und erstellen Sie:

C:\Development\
├─ Projects\
│  └─ dataquard\  ← Hier wird Ihr Code sein!
├─ Tools\
├─ Resources\
└─ Backups\

So funktioniert es:
1. Rechtsklick auf "C:\"
2. "Neuer Ordner"
3. "Development" eingeben
4. Doppelklick "Development" öffnen
5. Repeat für Unterordner
```

---

## 🛠️ Essenzielle Developer-Tools

### **1. Visual Studio Code (Code-Editor)**

**Download:** https://code.visualstudio.com

```
Installation:
1. Gehen Sie zu https://code.visualstudio.com
2. Klicken Sie "Download for Windows"
3. Öffnen Sie die .exe Datei
4. Installieren Sie mit Standard-Einstellungen
5. "Finish" klicken

Wichtig: Aktivieren Sie diese Optionen während Installation:
☑ Add to PATH (damit Sie 'code' im Terminal eingeben können)
☑ Register Code as an editor for supported file types
```

**Nach Installation: VS Code Extensions installieren**

```
Öffnen Sie VS Code und gehen Sie zu Extensions (Ctrl + Shift + X):

MUST-HAVE Extensions:
1. "ES7+ React/Redux/React-Native snippets"
   └─ Suchen nach: "ES7+"
   └─ Von: dsznajder.es7-react-js-snippets
   └─ Klick "Install"

2. "TypeScript Vue Plugin (Volar)"
   └─ Suchen nach: "Volar"
   └─ Von: Vue
   └─ Klick "Install"

3. "Prettier - Code formatter"
   └─ Suchen nach: "Prettier"
   └─ Von: Prettier
   └─ Klick "Install"

4. "ESLint"
   └─ Suchen nach: "ESLint"
   └─ Von: Microsoft
   └─ Klick "Install"

5. "GitHub Copilot" (Optional, aber cool!)
   └─ Suchen nach: "Copilot"
   └─ Von: GitHub
   └─ Klick "Install"
   └─ Sign in mit GitHub
```

---

### **2. Git (Versionskontrolle)**

**Download:** https://git-scm.com/download/win

```
Installation:
1. Gehen Sie zu https://git-scm.com/download/win
2. Klick "Click here to download"
3. Öffnen Sie die .exe
4. Installieren Sie mit Standard-Einstellungen
5. "Finish"

Konfiguration:
Öffnen Sie PowerShell (Win + X → PowerShell) und führen aus:

git config --global user.name "Ihr Name"
git config --global user.email "ihre@email.ch"

Beispiel:
git config --global user.name "Richard Rickli"
git config --global user.email "richard@dataquard.ch"
```

---

### **3. Node.js (JavaScript Runtime)**

**Download:** https://nodejs.org

```
Installation:
1. Gehen Sie zu https://nodejs.org
2. Klick "LTS" (Long Term Support)
3. Download .msi für Windows
4. Öffnen Sie die .msi
5. Installieren Sie mit Standard-Einstellungen
6. Neustart!

Verifikation:
Öffnen Sie PowerShell und geben Sie ein:

node --version
npm --version

Output sollte sein:
v21.x.x (oder höher)
10.x.x (oder höher)

Wenn Fehler: Neustart Windows!
```

---

### **4. GitHub Desktop (Optional, aber empfohlen)**

**Download:** https://desktop.github.com

```
Installation:
1. Gehen Sie zu https://desktop.github.com
2. Klick "Download for Windows"
3. Öffnen Sie die .exe
4. Installieren Sie
5. "Launch" wenn fertig

Sign in:
1. GitHub Desktop öffnen
2. File → Options
3. Sign in mit Ihrem GitHub Account
4. Autorisieren
```

---

## 💻 Programmierumgebung (VS Code)

### **Settings Optimieren**

```
Öffnen Sie VS Code:
1. Datei → Einstellungen → Einstellungen (Ctrl + ,)
2. Suchen Sie nach:

EMPFOHLEN:
├─ "Format On Save" → Aktivieren ✓
├─ "Tab Size" → 2 (statt 4)
├─ "Minimap" → Deaktivieren (mehr Platz im Code!)
├─ "Auto Save" → "onFocusChange"
└─ "Word Wrap" → "on"

THEME (Optional):
├─ Datei → Einstellungen → Theme
├─ "Dark+" ist gut
└─ Oder "One Dark Pro" installieren
```

---

## 📦 Node.js & npm

### **Projekt-Setup**

```
Öffnen Sie PowerShell und navigieren Sie:

cd C:\Development\Projects

Dann:
npx create-next-app@latest dataquard --typescript --tailwind

Die Fragen beantworten Sie mit:
- "Would you like to use ESLint?" → Yes
- "Would you like to use Tailwind CSS?" → Yes
- "Would you like your code inside a `src/` dir?" → No
- "Would you like to use App Router?" → Yes
- "Would you like to use Turbopack for next dev?" → Yes (schneller!)

Nach Installation:
cd dataquard
npm run dev

Das öffnet http://localhost:3000 mit Next.js!
```

---

## 🔀 Git & GitHub

### **GitHub Repo erstellen**

```
1. Gehen Sie zu https://github.com
2. Melden Sie sich an
3. Klick "+" (oben rechts) → "New repository"
4. Repository Name: "dataquard"
5. Beschreibung: "DSGVO/nDSG Compliance Tool für KMU"
6. Wählen Sie "Public" (für Sichtbarkeit)
7. Klick "Create repository"

Mit GitHub Desktop verbinden:
1. GitHub Desktop öffnen
2. File → Clone Repository
3. Geben Sie ein: "yourname/dataquard"
4. Klick "Clone"

Ihr Code ist jetzt mit GitHub verbunden!
```

---

## 🗄️ Supabase-Zugang

### **Supabase Projekt erstellen**

```
1. Gehen Sie zu https://supabase.com
2. Klick "Start your project"
3. Sign up mit GitHub (empfohlen)
4. Neues Projekt erstellen:
   ├─ Name: "dataquard"
   ├─ Region: "Europe (Zurich)"
   └─ Password: [Sicheres Passwort speichern!]

5. Database schreiben Sie auf:
   - PROJECT URL: [speichern!]
   - API KEY (anon): [speichern!]
   - API KEY (service_role): [speichern!]

WICHTIG: Diese Keys in .env.local speichern
(Nicht im GitHub!):

.env.local Datei erstellen:
NEXT_PUBLIC_SUPABASE_URL=https://xxxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=xxxxx
SUPABASE_SERVICE_KEY=xxxxx
```

---

## 🖥️ Terminal/PowerShell Optimieren

### **Windows Terminal installieren (Optional, aber empfohlen)**

```
1. Microsoft Store öffnen
2. Suchen Sie nach "Windows Terminal"
3. Klick "Installieren"

Nach Installation:
- Öffnen Sie Windows Terminal
- Settings (Ctrl + ,)
- Default profile: "PowerShell"
- Appearance: "Dark" Theme
- Font: "Cascadia Code"
```

---

### **PowerShell Profile konfigurieren**

```
Öffnen Sie PowerShell als Administrator und führen aus:

New-Item -Path $PROFILE -Type File -Force

Dann öffnen Sie:
notepad $PROFILE

Und schreiben Sie:

Set-Alias -Name code -Value 'C:\Users\[YourUsername]\AppData\Local\Programs\Microsoft VS Code\Code.exe'
Set-Alias -Name node -Value 'C:\Program Files\nodejs\node.exe'

# Navigation
Set-Location C:\Development\Projects

Speichern und schließen!
Neustart PowerShell!

Jetzt können Sie:
- "code ." (öffnet VS Code im aktuellen Ordner)
- "node --version" (überall funktionieren)
```

---

## 🌐 Chrome DevTools & Browser

### **Google Chrome installieren**

```
1. Gehen Sie zu https://www.google.com/chrome
2. Klick "Download Chrome"
3. Öffnen Sie die .exe
4. Installieren Sie

Wichtig: Chrome Extensions für Entwicklung
1. Chrome öffnen
2. Gehen Sie zu chrome://extensions
3. Installieren Sie:
   ├─ React Developer Tools
   ├─ Vue.js devtools
   └─ Postman (für API Testing)
```

---

## 🔒 Sicherheit & Backups

### **1. Antivirus & Firewall**

```
Windows Defender ist bereits aktiviert!
(Das reicht für den Anfang)

Überprüfung:
Windows Einstellungen → Sicherheit und Schutz → 
Sicherheit auf einen Blick
```

---

### **2. Backup-Strategie**

```
EMPFOHLEN: Google Drive Sync

1. Google Drive installieren:
   https://www.google.com/drive/download/

2. Einrichten:
   ├─ Melden Sie sich mit Ihrer Email an
   ├─ Wählen Sie: "C:\Development\Projects"
   └─ Klick "Start sync"

RESULTAT: Automatisch alles in Google Drive gesichert!

ZUSÄTZLICH: GitHub ist auch Backup
├─ Alle Commits sind in GitHub
├─ Sie können jederzeit clone
└─ Sicher!
```

---

### **3. .gitignore Datei**

```
Erstellen Sie eine Datei ".gitignore" in Ihrem Projekt:

C:\Development\Projects\dataquard\.gitignore

Inhalt:
# Dependencies
node_modules/
.pnp
.pnp.js

# Environment
.env
.env.local
.env.*.local

# Builds
.next/
out/
build/

# Misc
.DS_Store
*.pem

# Debug
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# IDE
.vscode/
.idea/

Speichern!

Jetzt werden sensitive Dateien NICHT in GitHub hochgeladen!
```

---

## ⚡ Performance-Tipps

### **1. Laptop für langes Coding optimieren**

```
POWER SETTINGS:
├─ Einstellungen → System → Energiesparen
├─ Energiesparmodus: "Best performance"
└─ Bildschirm-Timeout: "Nach 30 Min ausschalten"

FAN NOISE:
├─ Control Center öffnen (F5 oder Fn-Tasten)
├─ Performance Mode aktivieren
└─ Das HP OmniBook ist very quiet!
```

---

### **2. SSD pflegen**

```
Regelmäßig (monatlich):
1. Öffnen Sie Datei-Explorer
2. Rechtsklick auf "C:\"
3. "Properties"
4. "Disk Cleanup"
5. Alles auswählen & "OK"

Das löscht temporäre Dateien & spart Platz!
```

---

### **3. RAM optimal nutzen**

```
Mit 32 GB RAM können Sie parallel laufen lassen:
├─ VS Code (4 GB)
├─ Chrome mit 10 Tabs (5 GB)
├─ Node.js dev server (2 GB)
├─ Supabase Client (1 GB)
├─ Windows 11 (6 GB)
└─ Reserve (14 GB)

→ KEIN Problem!

Wenn langsam:
1. Task Manager öffnen (Ctrl + Shift + Esc)
2. Schauen Sie "Memory" Tab
3. Wenn >90%: Schließen Sie ungenutztes
```

---

## ✅ Checklisten

### **VOR Phase 0 (Diesen Woche)**

```
INSTALLATION:
☐ Windows aktualisiert
☐ Visual Studio Code installiert
☐ VS Code Extensions installiert (5 wichtigste)
☐ Git installiert & konfiguriert
☐ Node.js installiert & verifiziert
☐ GitHub Desktop installiert
☐ Google Drive installiert & synct
☐ Chrome mit DevTools Extensions

KONFIGURATION:
☐ Ordnerstruktur erstellt (C:\Development\Projects\)
☐ VS Code Settings optimiert
☐ PowerShell Profile konfiguriert
☐ GitHub Repo erstellt
☐ Supabase Projekt erstellt

VORBEREITUNG:
☐ Alle Passwörter in 1Password/LastPass gespeichert
☐ API Keys in .env.local datei (LOKAL, nicht in Git!)
☐ Backup-Strategie aktiviert (Google Drive)
```

---

### **PHASE 0 (Wenn RAV genehmigt)**

```
READY:
☐ Alle Tools installiert & funktionieren
☐ Terminal öffnen: "node --version" & "git --version" funktioniert
☐ VS Code öffnet sich schnell
☐ GitHub verbunden
☐ Supabase Projekt funktionstüchtig
☐ 5 Stunden/Tag freigeplant

DANN:
→ Schreiben Sie mir: "Phase 0 bereit!"
→ Ich gebe Ihnen Phase 0 Checkliste
→ Wir starten Entwicklung! 🚀
```

---

## 🎯 ZUSAMMENFASSUNG

### **Ihr HP OmniBook ist PERFEKT für Dataquard:**

```
✓ 32 GB RAM = Alles läuft smooth
✓ Core Ultra 7 = Schnell kompiliert
✓ 1 TB SSD = Viel Platz für Code & Datenbanken
✓ 14" = Perfekte Balance zwischen mobil & desktop
✓ Touchscreen = Modern & flexibel

NACH DIESEM SETUP:
→ Sie können Phase 0–7 durchziehen
→ 5 Stunden/Tag Entwicklung (kein Lag!)
→ Nach 6 Wochen: Dataquard live! 🚀
```

---

## 📞 Wenn Probleme:

```
Problem bei Installation?
1. Google Fehler-Message
2. Schreiben Sie mir Details
3. Ich helfe Ihnen fixen!

Beispiel Problem:
"npm: command not found"
→ Node.js neuinstallieren oder Neustart

"Git nicht erkannt"
→ Git zu PATH hinzufügen

Alles machbar - keine Panik!
```

---

**Viel Erfolg mit dem Setup! Wenn alles installiert ist, schreiben Sie mir!** 🚀
